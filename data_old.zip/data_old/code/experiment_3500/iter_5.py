import numpy as np

class GaussianMutation:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def mutate(self, population, lb, ub):
        # Generate a random matrix of mutation rates for each candidate and dimension
        mutation_matrix = np.random.rand(population.shape[0], population.shape[1])
        # Mutate the population by adding a small noise vector to each candidate
        candidates = np.clip(population + np.random.normal(0, 0.1, size=population.shape), lb, ub)
        return candidates

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize the best solution to a random point
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        
        local_search = LocalSearch()

        # Perform local search with local mutation until budget is exhausted
        while evaluations <= budget:
            evaluations += 1
            # Generate a candidate population
            candidates = GaussianMutation().mutate(np.full((10, len(best_x)), float('inf')), lb, ub)
            # Evaluate each candidate in batches to count them correctly
            for x in np.array_split(candidates, 2):
                k_evals = [problem(x_i) for x_i in x]
                score = float(np.mean(k_evals))  # Robust estimate using a single sample
                evaluations += len(k_evals)
                # Update best solution if a better one is found
                if score < best_y:
                    best_x = x[0]  # Use the first candidate from the batch as it's closest to the mean
                    best_y = score

        return best_x, float(best_y)

class LocalSearch:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, best_x, budget):
        evaluations = 1
        while evaluations <= budget:
            # Generate a population of candidates using mutation
            candidates = GaussianMutation().mutate(np.full((10, len(best_x)), float('inf')), problem.lower_bound, problem.upper_bound)
            # Evaluate each candidate in batches to count them correctly
            for x in np.array_split(candidates, 2):
                k_evals = [problem(x_i) for x_i in x]
                score = float(np.mean(k_evals))  # Robust estimate using a single sample
                evaluations += len(k_evals)
                # Update best solution if a better one is found
                if score < best_y:
                    best_x = x[0]  # Use the first candidate from the batch as it's closest to the mean
                    best_y = score

# Example usage
optimizer = MyOptimizer()
best_x, best_y = optimizer(problem_instance, budget=1_000_000)