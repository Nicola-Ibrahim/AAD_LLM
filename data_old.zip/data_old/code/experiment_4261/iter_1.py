import numpy as np

class DifferentialEvolution:
    def __init__(self):
        self.scale = 0.8  # Scaling factor for mutation step size
        self.cr = 0.9     # Crossover probability

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10 * dim  # Population size, arbitrary large enough to explore the space effectively
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        best_x = None
        best_y = float('inf')
        evaluations = 0

        while evaluations < budget:
            new_population = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = population[a] + self.scale * (population[b] - population[c])
                
                # Crossover
                mask = np.random.rand(*mutant.shape) < self.cr
                trial = np.where(mask, mutant, np.random.uniform(lb, ub, size=dim))
                
                # Evaluate the candidate solution
                y_trial = float(problem(trial))
                evaluations += 1
                
                # Update if better than current best
                if y_trial < best_y:
                    best_x, best_y = trial, y_trial
                    population[i] = trial
            
            self.scale *= 0.995  # Decrease step size gradually as evaluations increase
        
        return (best_x, float(best_y))