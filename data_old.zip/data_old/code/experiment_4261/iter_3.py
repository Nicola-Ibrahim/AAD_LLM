import numpy as np

class AdaptiveDifferentialEvolutionPlus:
    def __init__(self):
        self.scale = 0.8  # Initial scaling factor for mutation step size
        self.min_scale = 0.1  # Minimum scale value to avoid premature convergence
        self.max_scale = 2.0  # Maximum scale value to allow exploration
        self.reduction_interval = 50  # Interval for checking if a reduction in scale is needed
        self.no_improvement_threshold = 100  # Number of iterations without improvement before considering reducing scale
        self.no_improvement_count = 0  # Counter for consecutive iterations without improvement
        self.initial_pop_size = 20  # Initial population size
        self.population_size = self.initial_pop_size
        self.mutation_factor = 0.7  # Factor to control the mutation strength
        self.crossover_rate = 0.9  # Crossover probability

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 2))

        population = np.random.uniform(lb, ub, size=(self.population_size, dim))
        best_x = None
        best_y = float('inf')
        evaluations = 0

        while evaluations < budget:
            new_population = []
            for i in range(self.population_size):
                # Mutation step
                a, b, c = np.random.randint(0, self.population_size, size=3)
                mutant = population[a] + self.scale * (population[b] - population[c])
                
                # Crossover
                mask = np.random.rand(*mutant.shape) < self.crossover_rate
                trial = np.where(mask, mutant, np.random.uniform(lb, ub, size=dim))
                
                # Evaluate the candidate solution
                y_trial = float(problem(trial))
                evaluations += 1
                
                # Update if better than current best
                if y_trial < best_y:
                    best_x, best_y = trial, y_trial
                    population[i] = trial
                    self.no_improvement_count = 0  # Reset count since we found a better solution
                else:
                    self.no_improvement_count += 1
                
                # Check if we should reduce the scale due to no improvement
                if self.no_improvement_count > self.no_improvement_threshold:
                    self.scale = max(self.min_scale, self.scale * 0.9)
                    self.population_size //= 2  # Halve the population size
                    self.no_improvement_count = 0
                
                new_population.append(trial)
            
            # Update population only if we have a better solution in this round
            if best_y < float('inf'):
                population = np.array(new_population)
            
            # Gradually reduce scale to allow more exploration as evaluations increase
            if evaluations % self.reduction_interval == 0:
                self.scale *= 0.95
        
        return (best_x, float(best_y))