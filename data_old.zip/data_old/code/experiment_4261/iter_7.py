import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.scale = 0.8  # Initial scaling factor for mutation step size
        self.cr = 0.5     # Crossover probability
        self.min_scale = 0.1  # Minimum scale value to avoid premature convergence
        self.max_scale = 2.0  # Maximum scale value to allow exploration
        self.reduction_interval = 100  # Interval for reducing the scaling factor if no improvement
        self.no_improvement_threshold = 500  # Number of iterations without improvement before reducing scale
        self.no_improvement_count = 0  # Counter for consecutive iterations without improvement
        self.increase_factor = 1.2  # Factor to increase the scaling factor when significant improvement occurs
        self.reduction_interval_cr = 500  # Interval to adjust crossover rate if stagnation occurs
        self.stagnation_count_cr = 0  # Counter for consecutive iterations without significant change in best fitness
        self.initial_scale_factor = 0.8  # Initial factor to reduce the scaling factor when progress is slow

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 2))

        pop_size = 10 * dim  # Population size, arbitrary large enough to explore the space effectively
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        best_x = None
        best_y = float('inf')
        evaluations = 0

        while evaluations < budget:
            new_population = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = population[a] + self.scale * (population[b] - population[c])
                
                # Bound the mutant within search bounds
                mutant = np.clip(mutant, lb, ub)
                
                # Crossover
                mask = np.random.rand(*mutant.shape) < self.cr
                trial = np.where(mask, mutant, np.random.uniform(lb, ub, size=dim))
                
                # Evaluate the candidate solution
                y_trial = float(problem(trial))
                evaluations += 1
                
                # Update if better than current best
                if y_trial < best_y:
                    best_x, best_y = trial, y_trial
                    population[i] = trial
                    self.no_improvement_count = 0  # Reset count since we found a better solution
                    self.scale *= self.increase_factor  # Increase scale after improvement
                else:
                    self.no_improvement_count += 1
                
                # Check if we should reduce the scale due to no improvement
                if self.no_improvement_count > self.no_improvement_threshold:
                    self.scale = max(self.min_scale, self.scale / self.increase_factor)
                    self.no_improvement_count = 0
                
                # Adjust crossover rate if stagnation occurs
                if evaluations % self.reduction_interval_cr == 0 and self.stagnation_count_cr > self.reduction_interval_cr:
                    self.cr += (1 - self.cr) * 0.1
                    self.stagnation_count_cr = 0
                else:
                    self.stagnation_count_cr += 1
                
                new_population.append(trial)
            
            # Update population with the newly generated trials
            population = np.array(new_population)
        
        return (best_x, float(best_y))