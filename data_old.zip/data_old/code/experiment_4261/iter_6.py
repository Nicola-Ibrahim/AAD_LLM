import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.scale = 0.8  # Initial scaling factor for mutation step size
        self.cr = 0.5     # Crossover probability
        self.min_scale = 0.1  # Minimum scale value to avoid premature convergence
        self.max_scale = 2.0  # Maximum scale value to allow exploration
        self.reduction_interval = 100  # Interval for checking if a reduction in scale is needed
        self.no_improvement_threshold = 500  # Number of iterations without improvement before considering reducing scale
        self.no_improvement_count = 0  # Counter for consecutive iterations without improvement
        self.initial_scale_factor = 0.8  # Initial factor to reduce the scaling factor when progress is slow
        self.reduction_interval_cr = 250  # Interval to adjust crossover rate if stagnation occurs
        self.stagnation_count_cr = 0  # Counter for consecutive iterations without significant change in best fitness
        self.evaluation_budget = None  # Total budget of evaluations allowed

    def __call__(self, problem, budget):
        lb, ub = np.asarray(problem.lower_bound), np.asarray(problem.upper_bound)
        dim = len(lb)
        pop_size = max(10 * dim, 30)  # Population size, arbitrary large enough to explore the space effectively
        population = lb + (ub - lb) * np.random.rand(pop_size, dim)
        best_x = None
        best_y = float('inf')
        evaluations = 0

        while evaluations < budget:
            new_population = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = population[a] + self.scale * (population[b] - population[c])
                
                # Crossover
                mask = np.random.rand(*mutant.shape) < self.cr
                trial = np.where(mask, mutant, np.random.uniform(lb, ub))
                
                # Evaluate the candidate solution
                y_trial = float(problem(trial))
                evaluations += 1
                
                # Update if better than current best
                if y_trial < best_y:
                    best_x, best_y = trial, y_trial
                    population[i] = trial
                    self.no_improvement_count = 0  # Reset count since we found a better solution
                    self.scale = min(self.max_scale, self.scale * 0.95)  # Slightly increase scale for exploration after improvement
                    self.cr += (1 - self.cr) * 0.1  # Increase crossover rate slightly
                else:
                    self.no_improvement_count += 1
                
                # Check if we should reduce the scale due to no improvement
                if self.no_improvement_count > self.no_improvement_threshold:
                    self.scale = max(self.min_scale, self.scale * 0.9)
                    self.no_improvement_count = 0
                
                # Adjust crossover rate if stagnation occurs
                if evaluations % self.reduction_interval_cr == 0 and self.stagnation_count_cr > self.reduction_interval_cr:
                    self.cr -= (self.cr - 0.1) * 0.1
                    self.stagnation_count_cr = 0
                else:
                    self.stagnation_count_cr += 1
                
                # Gradually reduce scale to allow more exploration as evaluations increase
                if evaluations % self.reduction_interval == 0:
                    self.scale *= 0.995
        
        return (best_x, float(best_y))