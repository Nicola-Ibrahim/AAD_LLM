import numpy as np

class EvolutionaryStrategy:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Selection: Tournament selection
            selected_indices = np.random.choice(pop_size, size=(pop_size, 2), replace=False)
            candidates = pop[selected_indices[:, 0]] + pop[selected_indices[:, 1]]
            candidates = np.clip(candidates, lb, ub)

            # Evaluate new candidates
            k_evals = np.array([problem(x) for x in candidates])
            scores = k_evals.mean(axis=0)
            evaluations += len(k_evals)

            # Replacement: Update population and best solution
            candidate_fitness = scores
            candidate_indices = np.argsort(candidate_fitness)[:pop_size]
            pop = candidates[candidate_indices]

            new_best_idx = np.argmin(scores)
            if candidate_fitness[new_best_idx] < best_y:
                best_x = candidates[new_best_idx]
                best_y = candidate_fitness[new_best_idx]

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)