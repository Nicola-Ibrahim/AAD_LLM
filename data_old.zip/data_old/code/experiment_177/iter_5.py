import numpy as np

class EvolutionaryStrategy:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Mutation: Create new candidates by slightly perturbing the existing population
            mutation_rate = 0.1
            mutations = np.random.normal(0, mutation_rate, size=(pop_size, dim))
            candidates = pop + mutations
            candidates = np.clip(candidates, lb, ub)

            # Evaluate new candidates
            k_evals = np.array([problem(x) for x in candidates])
            evaluations += len(k_evals)
            scores = k_evals.mean(axis=0)

            # Replacement: Update population and best solution
            candidate_fitness = scores
            pop = candidates
            if candidate_fitness.min() < best_y:
                best_idx = np.argmin(candidate_fitness)
                best_x = candidates[best_idx]
                best_y = candidate_fitness[best_idx]

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)