import numpy as np

class NoiseResilientEvolutionaryStrategy:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitness = self.evaluate_candidates(problem, pop)
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Mutation: Create new candidates by slightly perturbing the existing population
            mutation_rate_exploration = 0.1
            mutations_exploration = np.random.normal(0, mutation_rate_exploration, size=(pop_size, dim))
            candidates_exploration = pop + mutations_exploration
            candidates_exploration = np.clip(candidates_exploration, lb, ub)

            mutation_rate_exploitation = 0.5
            mutations_exploitation = np.random.normal(0, mutation_rate_exploitation, size=(pop_size, dim))
            candidates_exploitation = pop - mutations_exploitation
            candidates_exploitation = np.clip(candidates_exploitation, lb, ub)

            # Evaluate new candidates
            k_evals_exploration = self.evaluate_candidates(problem, candidates_exploration)
            evaluations += len(k_evals_exploration)
            scores_exploration = k_evals_exploration.mean(axis=0)

            k_evals_exploitation = self.evaluate_candidates(problem, candidates_exploitation)
            evaluations += len(k_evals_exploitation)
            scores_exploitation = k_evals_exploitation.mean(axis=0)

            # Replacement: Update population and best solution
            candidate_fitness_exploration = scores_exploration
            candidate_fitness_exploitation = scores_exploitation
            pop = np.concatenate((candidates_exploration, candidates_exploitation), axis=0)
            fitness = np.concatenate((candidate_fitness_exploration, candidate_fitness_exploitation))
            best_idx = np.argmin(fitness)
            best_x = pop[best_idx]
            best_y = fitness[best_idx]

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)

    def evaluate_candidates(self, problem, candidates):
        k_evals_per_candidate = max(1, int(min(0.2 * len(candidates), 5)))  # Ensure we stay within 20% of budget and get at least one evaluation
        batched_k_evals = np.array([[problem(x) for _ in range(k_evals_per_candidate)] for x in candidates])
        scores = batched_k_evals.mean(axis=1)
        return scores