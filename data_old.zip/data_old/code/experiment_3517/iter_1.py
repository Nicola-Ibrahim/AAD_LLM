class DE_rand_1_bin:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10
        F = 0.9
        CR = 0.8

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=(pop_size, dim))
        best_y = np.array([problem(x) for x in best_x])
        evaluations = 1

        while evaluations < budget:
            r1, r2, r3 = np.random.randint(0, pop_size, 3)
            mutants = best_x[r1] + F * (best_x[r2] - best_x[r3])
            mask = np.random.rand(pop_size, dim) < CR
            trials = np.where(mask, mutants, best_x)
            trials = np.clip(trials, lb, ub)

            for x in trials:
                y = problem(x)
                evaluations += 1
                if y < best_y[0]:
                    best_x[0] = x
                    best_y[0] = y

        return best_x[0], float(best_y[0])