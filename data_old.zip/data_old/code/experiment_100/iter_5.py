import numpy as np

class ImprovedHybridOptimizer:
    def __init__(self):
        self.pop_size = 100  # Increased population size for better exploration
        self.F_min = 0.5
        self.F_max = 1.2
        self.CR = 0.9
        self.local_search_radius = 0.5

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial random population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        pop_evals = np.array([problem(x) for x in pop])
        evaluations = self.pop_size

        best_idx = np.argmin(pop_evals)
        best_x = pop[best_idx]
        best_y = pop_evals[best_idx]

        while evaluations < budget:
            # Adaptive mutation factor
            F = self.F_min + (self.F_max - self.F_min) * np.random.rand()

            # Differential evolution mutation
            r1, r2, r3 = np.random.choice(self.pop_size, size=(3, self.pop_size), replace=True)
            mutants = pop[r1] + F * (pop[r2] - pop[r3])
            mask = np.random.rand(self.pop_size, dim) < self.CR
            trials = np.where(mask, mutants, pop)
            trials = np.clip(trials, lb, ub)

            # Evaluate new candidates
            trial_evals = np.array([problem(x) for x in trials])
            evaluations += self.pop_size

            # Update the population and best solution
            pop[trial_evals < pop_evals] = trials[trial_evals < pop_evals]
            pop_evals[trial_evals < pop_evals] = trial_evals[trial_evals < pop_evals]

            current_best_idx = np.argmin(pop_evals)
            if pop_evals[current_best_idx] < best_y:
                best_x = pop[current_best_idx]
                best_y = pop_evals[current_best_idx]

            # Adaptive local search around the top candidates
            for i in range(min(10, self.pop_size)):
                x_local = np.random.uniform(best_x - self.local_search_radius * (evaluations / budget), 
 best_x + self.local_search_radius * (evaluations / budget), 
 size=(self.pop_size, dim))
                x_local = np.clip(x_local, lb, ub)
                local_evals = np.array([problem(x) for x in x_local])
                evaluations += self.pop_size

                if min(local_evals) < best_y:
                    best_x = x_local[np.argmin(local_evals)]
                    best_y = min(local_evals)

        return best_x, float(best_y)