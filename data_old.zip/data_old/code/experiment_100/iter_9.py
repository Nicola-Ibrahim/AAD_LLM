import numpy as np

class ImprovedHybridOptimizer:
    def __init__(self):
        self.pop_size = 50
        self.F_start = 0.8
        self.F_end = 0.1
        self.CR = 0.9
        self.local_search_radius = 0.1
        self.gradient_step = 1e-6

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial random population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        pop_evals = np.array([problem(x) for x in pop])
        evaluations = self.pop_size

        best_idx = np.argmin(pop_evals)
        best_x = pop[best_idx]
        best_y = pop_evals[best_idx]

        while evaluations < budget:
            # Adaptive mutation factor
            F = self.F_start + (self.F_end - self.F_start) * (evaluations / budget)

            # Differential evolution mutation
            r1, r2, r3 = np.random.choice(self.pop_size, size=(3, self.pop_size), replace=True)
            mutants = pop[r1] + F * (pop[r2] - pop[r3])
            mask = np.random.rand(self.pop_size, dim) < self.CR
            trials = np.where(mask, mutants, pop)
            trials = np.clip(trials, lb, ub)

            # Evaluate new candidates
            trial_evals = np.array([problem(x) for x in trials])
            evaluations += self.pop_size

            # Update the population and best solution
            pop[trial_evals < pop_evals] = trials[trial_evals < pop_evals]
            pop_evals[trial_evals < pop_evals] = trial_evals[trial_evals < pop_evals]

            current_best_idx = np.argmin(pop_evals)
            if pop_evals[current_best_idx] < best_y:
                best_x = pop[current_best_idx]
                best_y = pop_evals[current_best_idx]

            # Local search around the top candidates
            for i in range(min(10, self.pop_size)):
                x_local = np.copy(best_x)
                gradient = np.zeros(dim)
                for j in range(dim):
                    perturbation = np.zeros(dim)
                    perturbation[j] = self.gradient_step
                    gradient[j] = (problem(x_local + perturbation) - problem(x_local)) / self.gradient_step

                # Use gradient to refine the solution
                x_local -= 0.01 * gradient
                x_local = np.clip(x_local, lb, ub)
                local_eval = problem(x_local)
                evaluations += 1

                if local_eval < best_y:
                    best_x = x_local
                    best_y = local_eval

        return best_x, float(best_y)