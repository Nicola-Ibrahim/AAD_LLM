import numpy as np

class DifferentialEvolution:
    def __init__(self):
        pass  # No initialization needed for DE

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population with random vectors within bounds
        pop_size = min(10 * dim, budget // (dim + 2))  # Typically a factor of dimension or less
        F = 0.5  # Scaling factor for differential variation
        CR = 0.9  # Crossover probability
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size  # Initial population is evaluated at start

        best_x = None
        best_y = float('inf')

        while evaluations < budget:
            candidates = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, 3)
                mutant = pop[a] + F * (pop[b] - pop[c])
                mutant = np.clip(mutant, lb, ub)  # Ensure new vectors are within bounds

                # Crossover step
                trial = np.zeros_like(pop[i])
                jrand = np.random.randint(0, dim)
                for j in range(dim):
                    if np.random.rand() < CR or j == jrand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Evaluate the new candidate
                candidate_y = float(problem(trial))
                evaluations += 1

                # Update if this candidate is the best so far or not evaluated yet
                if candidate_y < best_y:
                    best_x, best_y = trial.copy(), candidate_y

                # Replacement step
                candidates.append((trial, candidate_y))

            # Replace old population with new generation
            pop[:] = [x for x, y in sorted(candidates, key=lambda pair: pair[1])[:pop_size]]

        return best_x, float(best_y)  # Return the best solution found