import numpy as np

class RobustDifferentialEvolution:
    def __init__(self):
        pass  # No initialization needed for DE

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population with random vectors within bounds
        pop_size = min(10 * dim, budget // (dim + 2))  # Typically a factor of dimension or less
        F = np.random.uniform(0.4, 0.8)  # Scaling factor for differential variation
        CR = np.random.uniform(0.7, 0.9)  # Crossover probability
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size  # Initial population is evaluated at start

        best_x = None
        best_y = float('inf')

        while evaluations < budget:
            candidates = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, 3)
                mutant = pop[a] + F * (pop[b] - pop[c])
                mutant = np.clip(mutant, lb, ub)  # Ensure new vectors are within bounds

                # Crossover step
                trial = np.zeros_like(pop[i])
                jrand = np.random.randint(0, dim)
                for j in range(dim):
                    if np.random.rand() < CR or j == jrand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Evaluate the new candidate multiple times and compute mean/median of results
                num_repeats = min(3, int((budget - evaluations) / (pop_size * dim)))
                if num_repeats > 1:
                    evals = [problem(trial) for _ in range(num_repeats)]
                    trial_mean = np.mean(evals)
                    trial_median = np.median(evals)
                    candidate_y = min(trial_mean, trial_median)  # Choose the best from mean and median
                else:
                    candidate_y = float(problem(trial))

                evaluations += num_repeats if num_repeats > 1 else 1

                # Update if this candidate is the best so far or not evaluated yet
                if candidate_y < best_y:
                    best_x, best_y = trial.copy(), candidate_y

                # Replacement step (keeping track of mean/median values)
                candidates.append((trial, candidate_y))

            # Replace old population with new generation
            pop[:] = [x for x, y in sorted(candidates, key=lambda pair: pair[1])[:pop_size]]

        return best_x, float(best_y)  # Return the best solution found