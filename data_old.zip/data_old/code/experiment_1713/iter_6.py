import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 50
        self.w = 0.729844
        self.c1 = 1.496180
        self.c2 = 1.496180
        self.F = 0.5
        self.CR = 0.9
        self.re_evaluations = 5

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        velocities = np.zeros((self.pop_size, dim))
        personal_best_positions = np.copy(pop)
        personal_best_values = np.array([np.median([float(problem(x)) for _ in range(self.re_evaluations)]) for x in pop])
        evaluations = self.pop_size * self.re_evaluations

        # Global best initialization
        global_best_index = np.argmin(personal_best_values)
        global_best_position = personal_best_positions[global_best_index]
        global_best_value = personal_best_values[global_best_index]

        while evaluations < 0.75 * budget:  # Reserve some budget for final evaluations
            # PSO update
            r1, r2 = np.random.rand(2, self.pop_size, dim)
            velocities = (self.w * velocities +
                          self.c1 * r1 * (personal_best_positions - pop) +
                          self.c2 * r2 * (global_best_position - pop))
            new_pop = np.clip(pop + velocities, lb, ub)

            # Evaluate PSO candidates
            pso_values = np.array([np.median([float(problem(x)) for _ in range(self.re_evaluations)]) for x in new_pop])
            evaluations += len(new_pop) * self.re_evaluations

            # ADE update
            mutated_indices = np.arange(self.pop_size)
            np.random.shuffle(mutated_indices)
            target_indices = (mutated_indices + 1) % self.pop_size
            donor_indices_1 = (target_indices + 1) % self.pop_size
            donor_indices_2 = (donor_indices_1 + 1) % self.pop_size

            donors = pop[mutated_indices] + self.F * (pop[donor_indices_1] - pop[donor_indices_2])
            donors = np.clip(donors, lb, ub)

            trial_pop = np.copy(new_pop)
            trial_mask = np.random.rand(self.pop_size, dim) < self.CR
            trial_pop[trial_mask] = donors[trial_mask]

            # Evaluate ADE candidates
            ade_values = np.array([np.median([float(problem(x)) for _ in range(self.re_evaluations)]) for x in trial_pop])
            evaluations += len(trial_pop) * self.re_evaluations

            # Selection: choose between PSO and ADE candidate based on fitness
            combined_values = np.minimum(pso_values, ade_values)
            combined_pop = np.where((pso_values[:, None] <= ade_values[:, None]), new_pop, trial_pop)

            for i in range(self.pop_size):
                if combined_values[i] < personal_best_values[i]:
                    personal_best_positions[i] = combined_pop[i]
                    personal_best_values[i] = combined_values[i]

            # Update global best
            new_global_best_index = np.argmin(personal_best_values)
            if personal_best_values[new_global_best_index] < global_best_value:
                global_best_position = personal_best_positions[new_global_best_index]
                global_best_value = personal_best_values[new_global_best_index]

        # Final evaluations using the remaining budget
        while evaluations < budget:
            for i in range(self.pop_size):
                new_val = float(problem(personal_best_positions[i]))
                evaluations += 1
                if new_val < personal_best_values[i]:
                    personal_best_values[i] = new_val

            new_global_best_index = np.argmin(personal_best_values)
            if personal_best_values[new_global_best_index] < global_best_value:
                global_best_position = personal_best_positions[new_global_best_index]
                global_best_value = personal_best_values[new_global_best_index]

        return global_best_position, float(global_best_value)