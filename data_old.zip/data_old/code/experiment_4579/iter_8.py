import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        pass  # No initialization state needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population generation
        pop_size = min(10 * dim, budget // (dim + 2))  # Empirical choice for pop_size based on dimension and budget
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        
        fitness = np.array([np.median([float(problem(x)) for _ in range(5)]) for x in pop])
        best_idx = np.argmin(fitness)  # Index of the best individual in the current population
        best_x = pop[best_idx].copy()
        best_y = fitness[best_idx]
        
        evaluations = len(pop) * 5  # Initial number of evaluations based on initial population size and re-evaluations per candidate

        while evaluations < budget:
            F = 0.5 + 0.3 * (best_y / 100) if best_y > 100 else 0.8  # Dynamic mutation factor based on the fitness of the best solution
            CR = 0.9 - 0.2 * (best_y / 100) if best_y < 100 else 0.5  # Dynamic crossover probability based on the fitness of the best solution

            # Differential evolution mutation step
            r1, r2, r3 = np.random.choice(pop_size, size=3, replace=False)
            mutants = pop[r1] + F * (pop[r2] - pop[r3])
            
            # Crossover to generate trial vectors
            mask = np.random.rand(pop_size, dim) < CR
            trials = np.where(mask, mutants, pop)
            
            # Apply boundary constraints to the trial vectors
            trials = np.clip(trials, lb, ub)
            
            # Evaluate new candidates multiple times for robustness against noise
            fitness_trials = np.array([np.median([float(problem(x)) for _ in range(5)]) for x in trials])
            evaluations += len(fitness_trials)  # Increment evaluations by the number of trial vectors evaluated
            
            # Update population and best solution found so far
            update_mask = fitness_trials < fitness[np.arange(pop_size)]
            pop[update_mask] = trials[update_mask].copy()
            fitness[update_mask] = fitness_trials[update_mask]
            
            if np.min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)].copy()
                best_y = np.min(fitness)
        
        return best_x, float(best_y)