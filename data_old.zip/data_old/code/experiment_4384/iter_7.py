import numpy as np

class CMAESOptimizerRefined:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5       # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)
        self.d = 3  # Dimension of the search space
        self.learning_rates = {
            'pc': 0.5 / np.sqrt(self.mu),
            'ps': 0.3 / np.sqrt(self.mu),
            'c_sigma': (np.exp(self.weights[-1]) + np.exp(self.weights[0])) / 2,
        }

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population (mu individuals)
        pop = np.random.uniform(lb, ub, size=(self.mu, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        order = fitness.argsort()
        best_idx = order[0]
        best_x = pop[best_idx].copy()
        best_y = fitness[best_idx]
        evaluations = self.mu

        # Initialize evolution paths
        pc = np.zeros(dim)  # Evolution path for the mean
        ps = np.zeros(dim)  # Evolution path for the standard deviation

        while evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if evaluations + self.mu > budget:
                break

            # Rank-based selection for breeding
            selected_indices = np.random.choice(np.arange(self.mu), size=self.mu, replace=True, p=self.weights)
            parents = pop[selected_indices]

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(parents + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < best_y:
                best_x = candidates[improved].copy()
                best_y = candidate_fitness[improved]

            # Update the population using CMA-ES update rules
            pc = (1 - self.learning_rates['pc']) * pc + np.sqrt(self.learning_rates['pc'] * (2 - self.learning_rates['pc'])) * (best_x - pop[selected_indices][0]) / self.sigma
            ps = (1 - self.learning_rates['ps']) * ps + np.sqrt(self.learning_rates['ps'] * (2 - self.learning_rates['ps'])) * pc
            self.sigma *= np.exp(self.learning_rates['c_sigma'] * (np.linalg.norm(ps) / np.sqrt(self.mu) - 1))

            pop = best_x + self.sigma * ps[:, None] * np.random.normal(size=(self.mu, dim))

        return best_x, float(best_y)