import numpy as np

class CMAESOptimizerRefinedAdaptive:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5       # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)
        self.d = 3  # Dimension of the search space
        self.sigma_decay = 0.99  # Rate at which sigma decays towards zero as convergence progresses
        self.best_y = float('inf')  # Initialize best fitness to a large number

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population (mu individuals)
        pop = np.random.uniform(lb, ub, size=(self.mu, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        order = fitness.argsort()
        best_idx = order[0]
        best_x = pop[best_idx].copy()
        self.best_y = min(self.best_y, fitness[best_idx])
        evaluations = self.mu

        while evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if evaluations + self.mu > budget:
                break

            # Rank-based selection for breeding
            selected_indices = np.random.choice(np.arange(self.mu), size=self.mu, replace=True, p=self.weights)
            parents = pop[selected_indices]

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(parents + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < self.best_y:
                best_x = candidates[improved].copy()
                self.best_y = candidate_fitness[improved]

            # Update the population using CMA-ES update rules (simplified for this example)
            pop = np.vstack([best_x + 0.5 * self.sigma * np.random.normal(size=dim)[np.newaxis, :], parents[:self.mu - 1]])

            # Adjust sigma based on the convergence of the population
            if evaluations % (budget // 20) == 0:  # Adjust sigma every so many evaluations
                self.sigma *= self.sigma_decay

        return best_x, float(self.best_y)