import numpy as np

class CMAESOptimizer:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5      # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population (mu individuals)
        pop = np.random.uniform(lb, ub, size=(self.mu, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        best_x = pop[np.argmin(fitness)]
        best_y = np.min(fitness)
        evaluations = self.mu

        while evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if evaluations + self.mu > budget:
                break

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(pop + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < best_y:
                best_x = candidates[improved]
                best_y = candidate_fitness[improved]

            # Update the population using CMA-ES update rules (simplified for this example)
            pop = np.array([best_x + 0.5 * self.sigma * np.random.normal(size=dim)])

        return best_x, float(best_y)