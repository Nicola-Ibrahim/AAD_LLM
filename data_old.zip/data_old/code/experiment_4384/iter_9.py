import numpy as np

class CMAESOptimizerRefinedAdaptive:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5       # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)
        self.d = 3  # Dimension of the search space
        self.best_x = None
        self.best_y = float('inf')
        self.evaluations = 0
        self.initial_sigma = self.sigma  # Store initial sigma for adaptive adjustment

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population (mu individuals)
        pop = np.random.uniform(lb, ub, size=(self.mu, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        order = fitness.argsort()
        best_idx = order[0]
        self.best_x = pop[best_idx].copy()
        self.best_y = fitness[best_idx]
        self.evaluations += self.mu

        while self.evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if self.evaluations + self.mu > budget:
                break

            # Elitist selection for breeding
            parents = pop[order[:self.mu]]

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(parents + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < self.best_y:
                self.best_x = candidates[improved].copy()
                self.best_y = candidate_fitness[improved]

            # Update the population using CMA-ES update rules (simplified for this example)
            pop = np.vstack([self.best_x + 0.5 * self.sigma * np.random.normal(size=dim)[np.newaxis, :], parents[:self.mu - 1]])

            # Adaptive step size adjustment based on the evolution path
            N = dim / 2  # Number of normally distributed directions
            h_sig = np.linalg.norm(noise.mean(0)) / (self.sigma * np.sqrt(N + 20)) / np.sqrt(2)
            self.sigma *= np.exp(0.3 * h_sig + 0.2 * (h_sig - 1))

        return self.best_x, float(self.best_y)