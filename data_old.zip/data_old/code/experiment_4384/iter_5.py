import numpy as np

class CMAESOptimizerRefined:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5       # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)
        self.d = 3       # Dimension of the search space
        self.initial_population = None

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        if self.initial_population is None:
            # Initialize population (mu individuals)
            self.initial_population = np.random.uniform(lb, ub, size=(self.mu, dim))
            fitness = np.array([float(problem(x)) for x in self.initial_population])
            order = fitness.argsort()
            best_idx = order[0]
            best_x = self.initial_population[best_idx].copy()
            best_y = fitness[best_idx]
        else:
            # Reinitialize population if necessary
            pop = np.random.uniform(lb, ub, size=(self.mu, dim))
            fitness = np.array([float(problem(x)) for x in pop])
            order = fitness.argsort()
            best_idx = order[0]
            best_x = pop[best_idx].copy()
            best_y = fitness[best_idx]

        evaluations = self.mu

        while evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if evaluations + self.mu > budget:
                break

            # Rank-based selection for breeding
            selected_indices = np.random.choice(np.arange(self.mu), size=self.mu, replace=True, p=self.weights)
            parents = self.initial_population[selected_indices]

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(parents + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < best_y:
                best_x = candidates[improved].copy()
                best_y = candidate_fitness[improved]

            # Update the population using CMA-ES update rules (simplified for this example)
            self.initial_population = np.vstack([best_x + 0.5 * self.sigma * np.random.normal(size=dim)[np.newaxis, :], parents[:self.mu - 1]])

        return best_x, float(best_y)