import numpy as np

class CMAESOptimizerRefined:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5       # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)
        self.d = 3       # Dimension of the search space
        self.learning_rate = 0.2  # Learning rate for sigma adjustment
        self.best_sigma = self.sigma  # Initialize best sigma

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population (mu individuals)
        pop = np.random.uniform(lb, ub, size=(self.mu, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        order = fitness.argsort()
        best_idx = order[0]
        best_x = pop[best_idx].copy()
        best_y = fitness[best_idx]
        evaluations = self.mu

        # Initialize sigma history to track changes for regularization
        sigma_history = [self.sigma]

        while evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if evaluations + self.mu > budget:
                break

            # Rank-based selection for breeding
            selected_indices = np.random.choice(np.arange(self.mu), size=self.mu, replace=True, p=self.weights)
            parents = pop[selected_indices]

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(parents + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < best_y:
                best_x = candidates[improved].copy()
                best_y = candidate_fitness[improved]

            # Update the population using CMA-ES update rules (simplified for this example)
            pop = np.vstack([best_x + 0.5 * self.sigma * np.random.normal(size=dim)[np.newaxis, :], parents[:self.mu - 1]])

            # Adjust sigma based on the performance of the population
            mean_fitness = np.mean(candidate_fitness)
            if mean_fitness < best_y:
                self.sigma *= (1 + self.learning_rate)
            else:
                self.sigma /= (1 + self.learning_rate)

            # Regularize the sigma to prevent sudden changes
            if len(sigma_history) > 10:
                recent_sigmas = np.array(sigma_history[-10:])
                mean_recent_sigma = np.mean(recent_sigmas)
                self.sigma = max(self.sigma, mean_recent_sigma * 0.95)
                self.sigma = min(self.sigma, mean_recent_sigma * 1.05)

            sigma_history.append(self.sigma)

        return best_x, float(best_y)