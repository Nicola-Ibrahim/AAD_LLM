import numpy as np

class CMAESOptimizerRefinedAdaptive:
    def __init__(self):
        self.sigma = 1.0  # Initial step size
        self.mu = 5       # Number of individuals to be considered for breeding
        self.weights = np.log(self.mu + 0.5) - np.log(np.arange(1, self.mu + 1))
        self.weights /= np.sum(self.weights)
        self.d = 3       # Dimension of the search space
        self.elitism_rate = 0.2  # Proportion of individuals to preserve as elite
        self.sigma_decay = 0.95  # Factor by which sigma is reduced if no improvement
        self.sigma_growth = 1.05  # Factor by which sigma is increased if improvement
        self.improvement_threshold = -np.inf  # Improvement threshold to increase sigma

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population (mu individuals)
        pop = np.random.uniform(lb, ub, size=(self.mu, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        order = fitness.argsort()
        best_idx = order[0]
        best_x = pop[best_idx].copy()
        best_y = fitness[best_idx]
        evaluations = self.mu

        # Initialize sigma based on the range of initial population positions
        init_range = ub - lb
        self.sigma *= np.mean(init_range) / 2.0

        while evaluations < budget:
            # Resample if necessary to ensure we don't exceed the budget
            if evaluations + self.mu > budget:
                break

            # Rank-based selection for breeding
            selected_indices = np.random.choice(np.arange(self.mu), size=self.mu, replace=True, p=self.weights)
            parents = pop[selected_indices]

            # Generate new population through mutation and crossover (simple average for now)
            noise = np.random.normal(0, self.sigma, size=(self.mu, dim))
            candidates = np.clip(parents + noise, lb, ub)

            # Evaluate the fitness of all candidates
            candidate_fitness = [float(problem(x)) for x in candidates]
            evaluations += self.mu

            # Update best_x and best_y if a better solution is found
            improved = np.argmin(candidate_fitness)
            if candidate_fitness[improved] < best_y:
                best_x = candidates[improved].copy()
                best_y = candidate_fitness[improved]

                # Reset sigma to initial value for better exploration after significant improvement
                self.sigma = np.mean(init_range) / 2.0

            else:
                # Reduce sigma if no improvement is observed
                if best_y > self.improvement_threshold:
                    self.sigma /= self.sigma_decay
                else:
                    self.sigma *= self.sigma_growth

                # Update the improvement threshold based on the current best fitness
                self.improvement_threshold = best_y * 0.95  # Threshold decreases slowly over time

            # Preserve elite individuals
            elites_indices = np.argsort(fitness)[:int(self.mu * self.elitism_rate)]
            pop[:len(elites_indices)] = pop[elites_indices]
            fitness[:len(elites_indices)] = fitness[elites_indices]

            # Update the population using CMA-ES update rules (simplified for this example)
            pop = np.vstack([best_x + 0.5 * self.sigma * np.random.normal(size=dim)[np.newaxis, :], parents[:self.mu - 1]])

        return best_x, float(best_y)