import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Initial scaling factor for differential evolution
        self.CR = 0.9  # Initial crossover probability
        self.min_F = 0.1  # Minimum scaling factor value
        self.max_F = 0.9  # Maximum scaling factor value
        self.min_CR = 0.1  # Minimum crossover probability value
        self.max_CR = 0.9  # Maximum crossover probability value

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = max(10 * dim, 20)  # Population size proportional to the problem dimension
        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += pop_size

        best_x = pop[np.argmin(fitness)]
        best_y = float(min(fitness))  # Minimize the objective function

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update the best solution found so far
            if min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)]
                best_y = float(min(fitness))

            # Adjust scaling factor F and crossover probability CR based on population fitness variance
            self.F = np.clip(self.F * (1 + np.random.normal(0, 0.1)), self.min_F, self.max_F)
            self.CR = np.clip(self.CR * (1 + np.random.normal(0, 0.1)), self.min_CR, self.max_CR)

        return best_x, float(best_y)