import numpy as np

class AdaptiveDE:
    def __init__(self):
        self.F = 0.5  # Initial scaling factor for differential evolution
        self.CR = 0.9  # Initial crossover probability
        self.min_F = 0.1  # Minimum value of F
        self.max_F = 0.9  # Maximum value of F
        self.min_CR = 0.4  # Minimum value of CR
        self.max_CR = 0.99  # Maximum value of CR
        self.F_decay = 0.95  # Decay rate for increasing F over time
        self.CR_decay = 0.98  # Decay rate for decreasing CR over time

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = min(20 * dim, 1000)  # Population size adjusted to avoid excessive computation
        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += pop_size

        best_x = pop[np.argmin(fitness)]
        best_y = float(min(fitness))  # Minimize the objective function

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update the best solution found so far
            if min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)]
                best_y = float(min(fitness))

            # Adjust F and CR over time to balance exploration and exploitation
            self.F *= self.F_decay
            if self.F < self.min_F:
                self.F = self.min_F

            self.CR *= self.CR_decay
            if self.CR > self.max_CR:
                self.CR = self.max_CR

        # Final local refinement using Simplex method
        simplex_step = 0.1 * (ub - lb)
        best_simplex, _ = self.simplex(problem, best_x, simplex_step, budget - evaluations)
        return best_simplex, float(best_y)

    def simplex(self, problem, x_start, step, remaining_budget):
        n_dim = len(x_start)
        vertices = [x_start + (np.random.randn(n_dim) * step) for _ in range(n_dim + 1)]
        fitnesses = np.array([float(problem(v)) for v in vertices])

        for _ in range(remaining_budget):
            worst, best = max(enumerate(fitnesses)), min(enumerate(fitnesses))
            centroid = np.mean([vertices[i] for i in range(n_dim + 1) if i != worst[0]], axis=0)

            # Reflection
            x_reflected = centroid + (2 * (centroid - vertices[worst[0]]))
            fitness_reflected = float(problem(x_reflected))

            if fitnesses[best[0]] < fitness_reflected < fitnesses[worst[0]]:
                vertices[worst[0]] = x_reflected
                fitnesses[worst[0]] = fitness_reflected
            else:
                # Expansion or contraction
                if fitness_reflected < fitnesses[best[0]]:
                    x_expanded = centroid + (3 * (x_reflected - centroid))
                    fitness_expanded = float(problem(x_expanded))
                    if fitness_expanded < fitness_reflected:
                        vertices[worst[0]] = x_expanded
                        fitnesses[worst[0]] = fitness_expanded
                else:
                    x_contracted = centroid - (0.5 * (centroid - vertices[worst[0]]))
                    fitness_contracted = float(problem(x_contracted))
                    if fitness_contracted < fitnesses[worst[0]]:
                        vertices[worst[0]] = x_contracted
                        fitnesses[worst[0]] = fitness_contracted
                    else:
                        # Shrink the simplex to focus on the best point
                        for i in range(1, n_dim + 1):
                            vertices[i] = vertices[0] + (0.5 * (vertices[i] - vertices[0]))
                        fitnesses = np.array([float(problem(v)) for v in vertices])
        return min(enumerate(fitnesses), key=lambda x: x[1]), float(min(fitnesses))