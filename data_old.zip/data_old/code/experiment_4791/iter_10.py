import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Initial scaling factor for differential evolution
        self.CR = 0.9  # Initial crossover probability
        self.learning_rate_F = 0.8  # Learning rate for F adjustment
        self.learning_rate_CR = 0.6  # Learning rate for CR adjustment
        self.seed = np.random.randint(1, 1000)  # Random seed for reproducibility

    def __call__(self, problem, budget):
        np.random.seed(self.seed)  # Set random seed
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = max(10 * dim, 20)  # Population size proportional to the problem dimension with a minimum of 20
        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += pop_size

        best_x = pop[np.argmin(fitness)].copy()
        best_y = float(min(fitness))  # Minimize the objective function

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update the best solution found so far with elitism
            if min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)].copy()
                best_y = float(min(fitness))

            # Adjust F and CR based on recent performance
            self.F *= np.exp(-self.learning_rate_F * (budget - evaluations) / budget)
            self.CR *= np.exp(-self.learning_rate_CR * (budget - evaluations) / budget)

        return best_x, float(best_y)