import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Initial scaling factor for differential evolution
        self.CR = 0.9  # Initial crossover probability
        self.F_min = 0.1  # Minimum value of F
        self.F_max = 0.9  # Maximum value of F
        self.CR_min = 0.1  # Minimum value of CR
        self.CR_max = 0.9  # Maximum value of CR
        self.reduction_factor = 0.95  # Reduction factor for F and CR
        self.increase_factor = 1.2  # Increase factor for F when stagnation occurs

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = min(10 * dim, budget // (2 * dim))  # Population size proportional to the problem dimension and budget
        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += pop_size

        best_x = pop[np.argmin(fitness)].copy()
        best_y = float(min(fitness))  # Minimize the objective function

        stagnation_counter = 0
        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

                # Elitist strategy to ensure best solution is preserved
                if fitness_trial < best_y:
                    best_x = trial.copy()
                    best_y = fitness_trial

            pop = np.array(new_pop)

            # Adjust F and CR based on stagnation or improvement
            if np.min(fitness) >= best_y:
                stagnation_counter += 1
                self.F *= self.reduction_factor
                self.CR *= self.reduction_factor
            else:
                stagnation_counter = 0
                self.F /= self.increase_factor
                self.CR /= self.increase_factor

        return best_x, float(best_y)