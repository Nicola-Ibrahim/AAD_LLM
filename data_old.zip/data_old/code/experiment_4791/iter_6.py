import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Initial scaling factor for differential evolution
        self.CR = 0.9  # Initial crossover probability
        self.min_F = 0.1  # Minimum value of F
        self.max_F = 0.9  # Maximum value of F
        self.min_CR = 0.1  # Minimum value of CR
        self.max_CR = 0.9  # Maximum value of CR
        self.reduction_factor_F = 0.95  # Factor to reduce F when stagnation occurs
        self.increase_factor_F = 1.2  # Factor to increase F when improvement is slow
        self.reduction_factor_CR = 0.95  # Factor to reduce CR when stagnation occurs
        self.increase_factor_CR = 1.2  # Factor to increase CR when improvement is slow
        self.stagnation_threshold = 50  # Number of iterations without significant improvement before reducing F and CR

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10 * dim  # Population size proportional to the problem dimension
        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += pop_size

        best_x = pop[np.argmin(fitness)]
        best_y = float(min(fitness))  # Minimize the objective function

        stagnation_counter = 0

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

                # Check for stagnation and adjust F and CR if necessary
                if fitness_trial >= fitness[i]:
                    stagnation_counter += 1
                else:
                    stagnation_counter = 0

                if stagnation_counter > self.stagnation_threshold:
                    self.F *= self.reduction_factor_F
                    self.CR *= self.reduction_factor_CR
                    stagnation_counter = 0

            pop = np.array(new_pop)

            # Update the best solution found so far
            if min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)]
                best_y = float(min(fitness))

        return best_x, float(best_y)