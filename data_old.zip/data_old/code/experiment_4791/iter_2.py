import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Initial mutation factor
        self.CR = 0.9  # Initial crossover probability
        self.min_F = 0.1  # Minimum mutation factor
        self.max_F = 0.8  # Maximum mutation factor
        self.F_decay_rate = 0.95  # Rate at which F decreases
        self.CR_decay_rate = 0.9  # Rate at which CR decreases
        self.min_CR = 0.1  # Minimum crossover probability

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10 * dim  # Population size proportional to the problem dimension
        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += pop_size

        best_x = pop[np.argmin(fitness)]
        best_y = float(min(fitness))  # Minimize the objective function

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.randint(0, pop_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update the best solution found so far
            if min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)]
                best_y = float(min(fitness))

            # Adjust F and CR for next iteration
            self.F *= self.F_decay_rate
            self.CR *= self.CR_decay_rate
            if self.F < self.min_F:
                self.F = self.min_F
            if self.CR < self.min_CR:
                self.CR = self.min_CR

        return best_x, float(best_y)