import numpy as np

class DifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Initial scaling factor for differential evolution
        self.CR = 0.9  # Crossover probability
        self.alpha_F = 0.6  # Learning rate for F
        self.beta_CR = 0.8  # Learning rate for CR
        self.min_F = 0.1  # Minimum value of F
        self.max_F = 0.9  # Maximum value of F
        self.min_CR = 0.3  # Minimum value of CR
        self.max_CR = 0.9  # Maximum value of CR
        self.population_size = 10 * dim  # Population size proportional to the problem dimension

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        evaluations = 0

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(lb, ub, size=(self.population_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])
        evaluations += self.population_size

        best_x = pop[np.argmin(fitness)]
        best_y = float(min(fitness))  # Minimize the objective function

        while evaluations < budget:
            new_pop = []
            for i in range(self.population_size):
                # Mutation step
                a, b, c = np.random.randint(0, self.population_size, size=3)
                mutant = pop[a] + self.F * (pop[b] - pop[c])

                # Crossover step
                trial = np.zeros_like(pop[i])
                j_rand = np.random.randint(dim)
                for j in range(dim):
                    if np.random.rand() < self.CR or j == j_rand:
                        trial[j] = mutant[j]
                    else:
                        trial[j] = pop[i][j]

                # Clip the trial vector to be within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the new candidate
                fitness_trial = float(problem(trial))
                evaluations += 1

                # Update if the trial is better than the current population member
                if fitness_trial < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = fitness_trial
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update the best solution found so far
            if min(fitness) < best_y:
                best_x = pop[np.argmin(fitness)]
                best_y = float(min(fitness))

            # Adjust F and CR based on fitness differences
            fitness_diff = np.abs(max(fitness) - min(fitness))
            self.F += self.alpha_F * (np.random.rand() - 0.5) * fitness_diff
            self.F = max(self.min_F, min(self.max_F, self.F))
            self.CR += self.beta_CR * (np.random.rand() - 0.5) * fitness_diff
            self.CR = max(self.min_CR, min(self.max_CR, self.CR))

        return best_x, float(best_y)