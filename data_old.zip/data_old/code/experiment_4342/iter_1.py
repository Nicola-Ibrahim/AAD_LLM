import numpy as np

class NoiseRobustOptimizer:
    def __init__(self):
        self.lb = None
        self.ub = None
        self.dim = None
        self.budget = None
        self.evaluations = 0
        self.pop_size = 100  # Population size
        self.mutation_rate = 0.1  # Rate for mutation to perturb candidate solutions
        self.crossover_rate = 0.7  # Probability of crossover when combining parent and mutant

    def __call__(self, problem, budget):
        self.budget = budget
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        self.dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        self.lb = lb
        self.ub = ub

        # Initialize population with random vectors within bounds
        pop = np.random.uniform(self.lb, self.ub, size=(self.pop_size, self.dim))
        eval_points = []  # Store points to avoid re-evaluation if the same point is selected again
        best_x = None
        best_y = float('inf')

        while self.evaluations < budget:
            # Evaluate all candidates in the population
            ys = np.array([self._evaluate(problem, x) for x in pop])
            self.evaluations += len(ys)

            # Update best_x and best_y if a better solution is found
            new_best_idx = np.argmin(ys)
            if ys[new_best_idx] < best_y:
                best_x = pop[new_best_idx].copy()
                best_y = ys[new_best_idx]

            # Select parents for reproduction (simple tournament selection)
            parent_indices = np.random.randint(0, self.pop_size, size=self.pop_size // 2 * 2)
            parents = pop[parent_indices].reshape((-1, 2))
            offspring = np.empty_like(parents)

            # Apply crossover and mutation to create new candidates
            for i in range(len(parents)):
                if np.random.rand() < self.crossover_rate:
                    midpoint = np.random.randint(0, self.dim)
                    offspring[i, :midpoint] = parents[i, 0][:midpoint]
                    offspring[i, midpoint:] = parents[i, 1][midpoint:]
                else:
                    offspring[i] = parents[i, np.random.choice([0, 1])]

            mutants = np.clip(offspring + np.random.normal(0, self.mutation_rate, size=offspring.shape), lb, ub)
            pop = mutants

        return best_x, float(best_y)

    def _evaluate(self, problem, x):
        # Re-evaluate the candidate if it hasn't been evaluated recently to avoid budget leaks due to noise
        key = tuple(x)
        if key not in eval_points:
            y = float(problem(x))
            eval_points.append(key)
        else:
            y = float('inf')  # If already evaluated, assume it's very bad
        return y