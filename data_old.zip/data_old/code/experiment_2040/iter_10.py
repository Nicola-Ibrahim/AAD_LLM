import numpy as np

class OptimizedDifferentialEvolution:
    def __init__(self):
        self.pop_size = 100
        self.crossover_rate = 0.8
        self.mutation_factor = 0.5
        self.local_search_iterations = 20

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 2))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(ind)) for ind in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        while evaluations < budget:
            # Differential Evolution step
            offspring = np.zeros_like(population)
            for i in range(self.pop_size):
                if evaluations >= budget:
                    break
                # Select three distinct individuals
                indices = list(range(self.pop_size))
                indices.remove(i)
                a, b, c = population[np.random.choice(indices, 3, replace=False)]

                # Mutation and crossover
                mutant = a + self.mutation_factor * (b - c)
                trial = np.where(np.random.rand(dim) < self.crossover_rate, mutant, population[i])
                trial = np.clip(trial, lb, ub)

                # Evaluate new individual
                trial_fitness = float(problem(trial))
                evaluations += 1

                if trial_fitness < fitness[i]:
                    offspring[i] = trial
                    fitness[i] = trial_fitness
                else:
                    offspring[i] = population[i]

            # Update best solution found so far
            current_best_x = offspring[np.argmin(fitness)]
            current_best_y = float(np.min(fitness))

            if current_best_y < best_y:
                best_x = current_best_x
                best_y = current_best_y

            # Local search step
            for _ in range(self.local_search_iterations):
                if evaluations >= budget:
                    break
                local_best_x = best_x + np.random.normal(0, 0.1, size=dim)
                local_best_x = np.clip(local_best_x, lb, ub)
                local_best_y = float(problem(local_best_x))
                evaluations += 1

                if local_best_y < best_y:
                    best_x = local_best_x
                    best_y = local_best_y

        return best_x, float(best_y)