import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Parameters
        pop_size = 40
        reeval_budget_limit = int(0.2 * budget)  # Limit for re-evaluation budget
        sigma = 1.0  # Initial step size (standard deviation)
        lambda_ = int(np.round(4 + np.floor(3 * np.log(dim))))  # Population size
        mu = lambda_ // 2  # Number of parents for evolution path update
        weights = np.array([np.log(mu + 0.5) - np.log(i) for i in range(1, mu + 1)])
        weights /= np.sum(weights)
        mueff = np.sum(weights) ** 2 / np.sum(weights ** 2)

        # Initialize population and evaluation counters
        best_x = np.random.uniform(lb, ub, size=dim)
        evaluations = 0

        # Initial mean and covariance matrix
        m = best_x.copy()
        C = np.eye(dim)

        def _robust_eval(x, k):
            nonlocal evaluations
            values = [problem(x) for _ in range(k)]
            evaluations += k
            return float(np.mean(values))

        # Archive to store promising solutions
        archive = []
        max_archive_size = 10

        while evaluations < budget:
            # Calculate remaining budget and re-evaluation budget
            remaining_budget = budget - evaluations
            reeval_budget = min(reeval_budget_limit, int(0.2 * remaining_budget))
            k = max(1, reeval_budget // (lambda_ + len(archive)))

            # Generate population
            z = np.random.randn(lambda_, dim)
            candidates = m + sigma * z.dot(C.T)

            # Clip to bounds
            candidates = np.clip(candidates, lb, ub)

            # Evaluate fitness of each candidate
            fitnesses = np.array([_robust_eval(x, k) for x in candidates])

            # Sort indices based on fitness
            sorted_indices = np.argsort(fitnesses)
            best_index = sorted_indices[0]

            # Update best solution if improved
            if fitnesses[best_index] < _robust_eval(best_x, k):
                best_x = candidates[best_index].copy()

            # Add the current best to the archive if it is not already there and not full
            if len(archive) < max_archive_size:
                archive.append(best_x)
            else:
                # Replace the least promising solution in the archive
                archive_fitnesses = np.array([_robust_eval(x, k) for x in archive])
                worst_index_in_archive = np.argmax(archive_fitnesses)
                if fitnesses[best_index] < archive_fitnesses[worst_index_in_archive]:
                    archive[worst_index_in_archive] = best_x

            # Update mean and covariance matrix
            x_diffs = candidates[sorted_indices[:mu]] - m
            m_prev = m.copy()
            m = np.sum(weights[:, None] * x_diffs, axis=0) + m

            C = (1 - 1/mueff) * C \
                + 1 / mueff * (x_diffs.T @ (np.diag(weights) @ x_diffs)) \
                + sigma**2 * (1 - 1/mueff) * np.eye(dim)

        # Final evaluation of the best solution
        best_y = float(problem(best_x))
        evaluations += 1

        return best_x, best_y