import numpy as np

class HybridOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population
        pop_size = 200
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitnesses = np.array([problem(x) for x in pop])
        evaluations += len(fitnesses)
        
        # Identify the best solution
        best_idx = np.argmin(fitnesses)
        best_x = pop[best_idx].copy()
        best_y = fitnesses[best_idx]

        while evaluations < budget:
            # Mutation: Gaussian mutation with varying standard deviation
            mutation_rates = np.random.uniform(0.05, 0.2, size=(pop_size, dim))
            mutations = np.clip(pop + np.random.normal(0, mutation_rates, size=(pop_size, dim)), lb, ub)
            mutated_fitnesses = np.array([problem(x) for x in mutations])
            evaluations += len(mutated_fitnesses)
            
            # Crossover: Differential evolution style
            parents_idx = np.random.choice(pop_size, (pop_size, 3), replace=True)
            crossover_mask = np.random.rand(pop_size, dim) < 0.7
            crossovers = np.where(crossover_mask, mutations, pop[parents_idx[:, 1]])

            # Evaluate crossovers
            crossover_fitnesses = np.array([problem(x) for x in crossovers])
            evaluations += len(crossover_fitnesses)

            # Update population with better solutions from mutations and crossovers
            new_pop = np.where(mutated_fitnesses[:, None] < fitnesses, mutations, pop)
            new_pop = np.where(crossover_fitnesses[:, None] < fitnesses, crossovers, new_pop)
            new_fitnesses = np.minimum(np.minimum(fitnesses, mutated_fitnesses), crossover_fitnesses)

            # Check if a new best solution is found
            current_best_idx = np.argmin(new_fitnesses)
            if new_fitnesses[current_best_idx] < best_y:
                best_x = new_pop[current_best_idx].copy()
                best_y = new_fitnesses[current_best_idx]

            # Aggressive local search using gradient approximation
            if evaluations + dim <= budget:  # Ensure we don't exceed the budget
                # Approximate gradient at the current best solution
                epsilon = 1e-5
                gradient_approx = np.zeros(dim)
                for d in range(dim):
                    perturbation = np.zeros(dim)
                    perturbation[d] = epsilon
                    pos_grad = problem(best_x + perturbation)
                    neg_grad = problem(best_x - perturbation)
                    evaluations += 2
                    gradient_approx[d] = (pos_grad - neg_grad) / (2 * epsilon)

                # Move in the direction of steepest descent
                step_size = 0.1
                new_best_x = np.clip(best_x - step_size * gradient_approx, lb, ub)
                new_best_y = problem(new_best_x)
                evaluations += 1

                if new_best_y < best_y:
                    best_x = new_best_x.copy()
                    best_y = new_best_y

            # Random restarts to escape local optima
            if (budget - evaluations) > pop_size * dim:
                restart_idx = np.random.choice(pop_size, int(0.1 * pop_size), replace=False)
                pop[restart_idx] = np.random.uniform(lb, ub, size=(len(restart_idx), dim))
                fitnesses[restart_idx] = np.array([problem(x) for x in pop[restart_idx]])
                evaluations += len(fitnesses[restart_idx])

        return best_x, float(best_y)