import numpy as np

class EnhancedGradientOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitnesses = np.array([problem(x) for x in pop])
        evaluations += len(fitnesses)
        
        # Identify the best solution
        best_idx = np.argmin(fitnesses)
        best_x = pop[best_idx].copy()
        best_y = fitnesses[best_idx]

        while evaluations < budget:
            # Mutation: Gaussian mutation with adaptive standard deviation
            std_dev = 0.5 / (evaluations // 1000 + 1)  # Adaptive step size
            mutations = np.clip(pop + np.random.normal(0, std_dev, size=(pop_size, dim)), lb, ub)
            mutated_fitnesses = np.array([problem(x) for x in mutations])
            evaluations += len(mutated_fitnesses)
            
            # Update population with better solutions from mutations
            for i in range(pop_size):
                if mutated_fitnesses[i] < fitnesses[i]:
                    pop[i] = mutations[i]
                    fitnesses[i] = mutated_fitnesses[i]

            # Check if a new best solution is found
            current_best_idx = np.argmin(fitnesses)
            if fitnesses[current_best_idx] < best_y:
                best_x = pop[current_best_idx].copy()
                best_y = fitnesses[current_best_idx]

            # Aggressive local search using gradient approximation with random restarts
            if evaluations + (dim * 2 + 1) <= budget:  # Ensure we don't exceed the budget
                # Approximate gradient at the current best solution
                epsilon = 1e-5
                gradient_approx = np.zeros(dim)
                for d in range(dim):
                    perturbation = np.zeros(dim)
                    perturbation[d] = epsilon
                    pos_grad = problem(best_x + perturbation)
                    neg_grad = problem(best_x - perturbation)
                    evaluations += 2
                    gradient_approx[d] = (pos_grad - neg_grad) / (2 * epsilon)

                # Move in the direction of steepest descent with a random restart
                step_size = 0.1
                new_best_x = np.clip(best_x - step_size * gradient_approx, lb, ub)
                new_best_y = problem(new_best_x)
                evaluations += 1

                if new_best_y < best_y:
                    best_x = new_best_x.copy()
                    best_y = new_best_y
                else:
                    # Random restart if local search fails to improve
                    random_restart_x = np.random.uniform(lb, ub, size=(dim,))
                    random_restart_y = problem(random_restart_x)
                    evaluations += 1

                    if random_restart_y < best_y:
                        best_x = random_restart_x.copy()
                        best_y = random_restart_y

        return best_x, float(best_y)