import numpy as np

class EnhancedGradientOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Parameters
        pop_size = 100
        mutation_std_init = 0.5
        mutation_std_min = 0.1
        diversity_threshold = 0.2
        step_size_init = 0.5
        step_size_min = 0.1
        annealing_factor = 0.99

        # Initial population
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitnesses = np.array([problem(x) for x in pop])
        evaluations += len(fitnesses)
        
        # Identify the best solution
        best_idx = np.argmin(fitnesses)
        best_x = pop[best_idx].copy()
        best_y = fitnesses[best_idx]

        mutation_std = mutation_std_init
        step_size = step_size_init

        while evaluations < budget:
            # Mutation: Gaussian mutation with adaptive standard deviation
            mutations = np.clip(pop + np.random.normal(0, mutation_std, size=(pop_size, dim)), lb, ub)
            mutated_fitnesses = np.array([problem(x) for x in mutations])
            evaluations += len(mutated_fitnesses)
            
            # Update population with better solutions from mutations
            for i in range(pop_size):
                if mutated_fitnesses[i] < fitnesses[i]:
                    pop[i] = mutations[i]
                    fitnesses[i] = mutated_fitnesses[i]

            # Check if a new best solution is found
            current_best_idx = np.argmin(fitnesses)
            if fitnesses[current_best_idx] < best_y:
                best_x = pop[current_best_idx].copy()
                best_y = fitnesses[current_best_idx]

            # Diversity preservation
            if evaluations % 1000 == 0 and np.std(pop, axis=0).min() < diversity_threshold:
                worst_indices = np.argsort(fitnesses)[-10:]
                pop[worst_indices] = np.random.uniform(lb, ub, size=(10, dim))
                fitnesses[worst_indices] = np.array([problem(x) for x in pop[worst_indices]])
                evaluations += len(worst_indices)

            # Aggressive local search using gradient approximation
            if evaluations + dim <= budget:  # Ensure we don't exceed the budget
                # Approximate gradient at the current best solution
                epsilon = 1e-5
                gradient_approx = np.zeros(dim)
                for d in range(dim):
                    perturbation = np.zeros(dim)
                    perturbation[d] = epsilon
                    pos_grad = problem(best_x + perturbation)
                    neg_grad = problem(best_x - perturbation)
                    evaluations += 2
                    gradient_approx[d] = (pos_grad - neg_grad) / (2 * epsilon)

                # Move in the direction of steepest descent with annealed step size
                new_best_x = np.clip(best_x - step_size * gradient_approx, lb, ub)
                new_best_y = problem(new_best_x)
                evaluations += 1

                if new_best_y < best_y:
                    best_x = new_best_x.copy()
                    best_y = new_best_y

            # Anneal mutation standard deviation and step size
            mutation_std = max(mutation_std * annealing_factor, mutation_std_min)
            step_size = max(step_size * annealing_factor, step_size_min)

        return best_x, float(best_y)