import numpy as np

class EnhancedOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitnesses = np.array([problem(x) for x in pop])
        evaluations += len(fitnesses)
        
        # Identify the best solution
        best_idx = np.argmin(fitnesses)
        best_x = pop[best_idx].copy()
        best_y = fitnesses[best_idx]

        mutation_std_dev = 0.1  # Initial mutation standard deviation

        while evaluations < budget:
            # Adaptive mutation: Gaussian mutation with adaptive standard deviation
            mutations = np.clip(pop + np.random.normal(0, mutation_std_dev, size=(pop_size, dim)), lb, ub)
            mutated_fitnesses = np.array([problem(x) for x in mutations])
            evaluations += len(mutated_fitnesses)
            
            # Update population with better solutions from mutations
            for i in range(pop_size):
                if mutated_fitnesses[i] < fitnesses[i]:
                    pop[i] = mutations[i]
                    fitnesses[i] = mutated_fitnesses[i]

            # Check if a new best solution is found
            current_best_idx = np.argmin(fitnesses)
            if fitnesses[current_best_idx] < best_y:
                best_x = pop[current_best_idx].copy()
                best_y = fitnesses[current_best_idx]

            # Adaptive mutation strategy: adjust the standard deviation based on success rate
            success_count = np.sum(mutated_fitnesses < fitnesses)
            if success_count > pop_size // 2:
                mutation_std_dev *= 0.95  # Reduce std dev for more exploitation
            else:
                mutation_std_dev *= 1.05  # Increase std dev for more exploration

            # Aggressive local search using gradient approximation
            if evaluations + dim <= budget:  # Ensure we don't exceed the budget
                # Improved gradient approximation using central difference
                epsilon = 1e-6
                gradient_approx = np.zeros(dim)
                for d in range(dim):
                    perturbation = np.zeros(dim)
                    perturbation[d] = epsilon
                    pos_grad = problem(best_x + perturbation)
                    neg_grad = problem(best_x - perturbation)
                    evaluations += 2
                    gradient_approx[d] = (pos_grad - neg_grad) / (2 * epsilon)

                # Move in the direction of steepest descent with a line search
                step_size = 0.1
                new_best_x = best_x - step_size * gradient_approx
                for _ in range(10):  # Perform a few steps of line search
                    if evaluations + dim > budget:
                        break
                    candidate_x = np.clip(new_best_x, lb, ub)
                    candidate_y = problem(candidate_x)
                    evaluations += 1
                    if candidate_y < best_y:
                        best_x = candidate_x.copy()
                        best_y = candidate_y
                    else:
                        break

        return best_x, float(best_y)