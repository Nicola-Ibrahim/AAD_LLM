import numpy as np

class EnhancedGradientOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Evaluate initial population
        fitnesses = np.array([problem(x) for x in pop])
        evaluations += len(fitnesses)
        
        # Identify the best solution
        best_idx = np.argmin(fitnesses)
        best_x = pop[best_idx].copy()
        best_y = fitnesses[best_idx]

        while evaluations < budget:
            # Mutation: Cauchy mutation with adaptive standard deviation
            std_dev = 1.0 / (1 + np.exp(-evaluations / 50000))  # Adaptive standard deviation
            mutations = np.clip(pop + std_dev * np.random.standard_cauchy(size=(pop_size, dim)), lb, ub)
            mutated_fitnesses = np.array([problem(x) for x in mutations])
            evaluations += len(mutated_fitnesses)
            
            # Update population with better solutions from mutations
            for i in range(pop_size):
                if mutated_fitnesses[i] < fitnesses[i]:
                    pop[i] = mutations[i]
                    fitnesses[i] = mutated_fitnesses[i]

            # Check if a new best solution is found
            current_best_idx = np.argmin(fitnesses)
            if fitnesses[current_best_idx] < best_y:
                best_x = pop[current_best_idx].copy()
                best_y = fitnesses[current_best_idx]

            # Aggressive local search using gradient approximation with adaptive step size
            if evaluations + dim <= budget:  # Ensure we don't exceed the budget
                # Approximate gradient at the current best solution
                epsilon = 1e-5
                gradient_approx = np.zeros(dim)
                for d in range(dim):
                    perturbation = np.zeros(dim)
                    perturbation[d] = epsilon
                    pos_grad = problem(best_x + perturbation)
                    neg_grad = problem(best_x - perturbation)
                    evaluations += 2
                    gradient_approx[d] = (pos_grad - neg_grad) / (2 * epsilon)

                # Adaptive step size
                step_size = 0.1 / (1 + np.exp(-evaluations / 50000))

                # Move in the direction of steepest descent
                new_best_x = np.clip(best_x - step_size * gradient_approx, lb, ub)
                new_best_y = problem(new_best_x)
                evaluations += 1

                if new_best_y < best_y:
                    best_x = new_best_x.copy()
                    best_y = new_best_y

            # Diversity-preserving mechanism
            if evaluations + pop_size * dim <= budget:  # Ensure we don't exceed the budget
                # Calculate pairwise distances in population
                dist_matrix = np.linalg.norm(pop[:, None, :] - pop[None, :, :], axis=2)
                min_distances = np.min(dist_matrix, axis=1)

                # Remove individuals with very low diversity
                threshold = 0.1 * (ub - lb).max()
                diverse_indices = np.where(min_distances > threshold)[0]
                if len(diverse_indices) < pop_size:
                    new_pop = pop[diverse_indices].copy()
                    new_fitnesses = fitnesses[diverse_indices].copy()

                    # Replace removed individuals with new random samples
                    additional_samples = pop_size - len(diverse_indices)
                    new_samples = np.random.uniform(lb, ub, size=(additional_samples, dim))
                    new_pop = np.vstack((new_pop, new_samples))
                    new_fitnesses = np.array([problem(x) for x in new_samples])
                    evaluations += len(new_samples)

                    # Evaluate the entire population
                    fitnesses = np.hstack((new_fitnesses, [problem(x) for x in pop if x not in new_pop]))
                    evaluations += len(fitnesses)

                    # Identify the best solution again
                    best_idx = np.argmin(fitnesses)
                    best_x = new_pop[best_idx].copy()
                    best_y = fitnesses[best_idx]

        return best_x, float(best_y)