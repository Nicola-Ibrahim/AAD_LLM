import numpy as np

class NoisyOptimization:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # --- YOUR ALGORITHM LOGIC BELOW ---
        pop_size = 50  # Population size
        num_evals_per_candidate = 5  # Number of evaluations per candidate

        population = np.random.uniform(lb, ub, size=(pop_size, dim))

        while evaluations < budget:
            new_population = []
            for x in population:
                # Evaluate the candidate multiple times and take the median
                candidate_ys = [float(problem(x)) for _ in range(num_evals_per_candidate)]
                evaluations += num_evals_per_candidate
                median_y = np.median(candidate_ys)
                
                if median_y < best_y:
                    best_x, best_y = x.copy(), median_y

                # Mutation to generate a new candidate
                new_x = np.clip(x + np.random.normal(0, 0.1, size=dim), lb, ub)
                new_population.append(new_x)

            population = np.array(new_population)

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)