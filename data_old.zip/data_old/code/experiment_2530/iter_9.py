import numpy as np

class EnhancedNoisyOptimization:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # --- YOUR ALGORITHM LOGIC BELOW ---
        pop_size = 50  # Population size
        num_evals_per_candidate = 20  # Number of evaluations per candidate
        elite_size = 5  # Number of top candidates to retain and mutate

        population = np.random.uniform(lb, ub, size=(pop_size, dim))

        while evaluations < budget:
            candidate_ys = []
            for x in population:
                # Evaluate the candidate multiple times and store all observations
                ys = [float(problem(x)) for _ in range(num_evals_per_candidate)]
                evaluations += num_evals_per_candidate
                candidate_ys.append(ys)

            # Calculate mean and standard deviation of each candidate's evaluations
            means = np.mean(candidate_ys, axis=1)
            stds = np.std(candidate_ys, axis=1)

            # Sort candidates by mean value
            sorted_indices = np.argsort(means)
            top_indices = sorted_indices[:elite_size]

            # Select the best candidate based on mean and standard deviation
            for idx in top_indices:
                if means[idx] < best_y:
                    best_x, best_y = population[idx].copy(), means[idx]

            # Generate new population by mutating the elite candidates
            new_population = []
            for idx in top_indices:
                mutation_rate = 0.1 + (1 - 0.1) * stds[idx] / np.max(stds)
                for _ in range(int(pop_size / elite_size)):
                    new_x = np.clip(population[idx] + np.random.normal(0, mutation_rate, size=dim), lb, ub)
                    new_population.append(new_x)

            population = np.array(new_population)

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)