import numpy as np

class ImprovedNoisyOptimization:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # --- YOUR ALGORITHM LOGIC BELOW ---
        pop_size = 50  # Population size
        num_evals_per_candidate = 10  # Initial number of evaluations per candidate
        elite_size = 5  # Number of top candidates to retain and mutate
        max_budget_for_reevaluations = int(0.2 * budget)  # Allocate 20% of the budget for re-evaluations

        population = np.random.uniform(lb, ub, size=(pop_size, dim))

        while evaluations < budget:
            candidate_ys = []
            for x in population:
                # Evaluate the candidate multiple times and store all observations
                ys = [float(problem(x)) for _ in range(num_evals_per_candidate)]
                evaluations += num_evals_per_candidate
                candidate_ys.append(ys)

            # Calculate mean and standard deviation of each candidate's evaluations
            means = np.mean(candidate_ys, axis=1)
            stds = np.std(candidate_ys, axis=1)

            # Sort candidates by mean value
            sorted_indices = np.argsort(means)
            top_indices = sorted_indices[:elite_size]

            # Select the best candidate based on weighted average of means and standard deviations
            weights = 1 / (stds + 1e-6)  # Avoid division by zero
            normalized_weights = weights / np.sum(weights)
            weighted_means = np.dot(normalized_weights, means)

            if weighted_means < best_y:
                best_x, best_y = population[sorted_indices[0]].copy(), means[sorted_indices[0]]

            # Generate new population by mutating the elite candidates
            new_population = []
            for idx in top_indices:
                for _ in range(int(pop_size / elite_size)):
                    mutation_rate = 0.1 + (1 - 0.1) * stds[idx] / np.max(stds)
                    new_x = np.clip(population[idx] + np.random.normal(0, mutation_rate, size=dim), lb, ub)
                    new_population.append(new_x)

            population = np.array(new_population)

            # Re-evaluate the best candidate if budget allows
            remaining_budget = budget - evaluations
            if remaining_budget > max_budget_for_reevaluations:
                reeval_budget = min(max_budget_for_reevaluations, remaining_budget // elite_size)
                for idx in top_indices:
                    ys = [float(problem(population[idx])) for _ in range(reeval_budget)]
                    evaluations += reeval_budget
                    new_mean = np.mean(ys)
                    if new_mean < best_y:
                        best_x, best_y = population[idx].copy(), new_mean

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)