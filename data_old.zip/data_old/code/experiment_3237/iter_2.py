import numpy as np

class MedianSearch:

    def __init__(self):
        pass  # No initialization needed for this simple algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        while evaluations <= budget:
            # Generate new candidate solutions by adding random noise to the current best solution
            candidates = np.clip(best_x + np.random.normal(0, 0.1, size=(10, dim)), lb, ub)
            
            # Evaluate each candidate multiple times and compare means or medians
            for i, x in enumerate(candidates):
                evaluations += 10  # Re-evaluate 10 times per candidate
                y_values = [float(problem(x)) for _ in range(10)]
                
                if np.mean(y_values) < best_y:
                    best_x = x
                    best_y = np.mean(y_values)

        return best_x, float(best_y)