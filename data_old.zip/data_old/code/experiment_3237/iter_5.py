import numpy as np

class MedianSearchAdaptive:
    def __init__(self):
        pass  # No initialization needed for this simple algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        while evaluations <= budget:
            # Generate new candidate solutions by adding random noise to the current best solution
            candidates = np.clip(best_x + np.random.normal(0, 0.1, size=(10, dim)), lb, ub)
            
            # Evaluate each candidate multiple times and compare means or medians
            for i, x in enumerate(candidates):
                evaluations += 10  # Re-evaluate 10 times per candidate
                
                y_values = [float(problem(x)) for _ in range(10)]
                
                if np.mean(y_values) < best_y:
                    best_x = x
                    best_y = np.mean(y_values)
                
                # Calculate variance to guide exploration vs. exploitation
                variance = np.var(y_values)
                
                # Adjust the noise level based on variance
                if variance > 0.1:  # Arbitrary threshold to decide on noise adjustment
                    noise_level = max(0, min(0.5, np.sqrt(variance)))
                else:
                    noise_level = 0.1
                
                # Increase evaluations per candidate for better performance with higher variance
                if variance > 2.0:  # Another arbitrary threshold
                    evaluations += 10 * int(np.ceil(variance / 2.0))
                
            # Adaptively adjust the search strategy based on the current best solution
            if np.abs(best_y - 76.27) < 1.0:
                noise_level = min(0.3, noise_level)
                evaluations += 50 * int(np.ceil(variance / 4.0))
            
        return best_x, float(best_y)