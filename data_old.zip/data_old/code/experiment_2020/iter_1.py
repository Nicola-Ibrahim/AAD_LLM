import numpy as np

class NoiseResilientOptimizer:
    def __init__(self):
        pass  # Initialize any necessary state variables here if needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population setup
        pop_size = 100
        candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
        means = np.zeros(pop_size)
        std_devs = np.ones(pop_size)

        evaluations = 0

        while evaluations < budget:
            # Evaluate each candidate multiple times to get reliable estimates
            num_evaluations_per_candidate = min(10, budget - evaluations)  # Ensure we do not exceed the budget
            for i in range(pop_size):
                samples = np.array([problem(candidates[i]) for _ in range(num_evaluations_per_candidate)])
                means[i] = np.mean(samples)
                std_devs[i] = np.std(samples)
                evaluations += num_evaluations_per_candidate

            # Identify the best candidate considering mean and uncertainty
            z_scores = (means - min(means)) / (std_devs + 1e-8)  # Add small constant to avoid division by zero
            best_index = np.argmax(z_scores)
            best_x, best_y = candidates[best_index], means[best_index]

            # Refine the best candidate with small perturbations
            num_refinements = min(50, budget - evaluations)  # Ensure we do not exceed the budget
            for _ in range(num_refinements):
                refined_x = np.clip(best_x + np.random.normal(0, 0.1, size=dim), lb, ub)
                refined_y = problem(refined_x)
                evaluations += 1

                if refined_y < best_y:
                    best_x, best_y = refined_x, refined_y

            # Introduce new random candidates to explore the search space
            num_new_candidates = min(20, budget - evaluations)  # Ensure we do not exceed the budget
            for _ in range(num_new_candidates):
                new_candidate = np.random.uniform(lb, ub, size=dim)
                new_y = problem(new_candidate)
                evaluations += 1

                if new_y < best_y:
                    best_x, best_y = new_candidate, new_y

        return best_x, float(best_y)  # Return the best solution found