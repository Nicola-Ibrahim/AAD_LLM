import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # Initialize any necessary state variables here if needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population setup
        pop_size = 100
        candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
        means = np.zeros(pop_size)

        evaluations = 0

        while evaluations < budget:
            # Evaluate each candidate multiple times to get reliable estimates
            num_initial_evaluations_per_candidate = min(50, budget - evaluations)
            for i in range(pop_size):
                samples = np.array([problem(candidates[i]) for _ in range(num_initial_evaluations_per_candidate)])
                means[i] = np.mean(samples)
                evaluations += num_initial_evaluations_per_candidate

            # Identify the best candidate considering mean
            sorted_indices = np.argsort(means)

            # Re-evaluate top 10% of candidates for better accuracy within a budget limit
            max_re_evaluation_budget = int(0.2 * budget)
            re_evaluation_budget_used = 0
            top_k = min(10, len(sorted_indices))
            for j in range(top_k):
                if evaluations + re_evaluation_budget_used >= budget:
                    break
                best_index = sorted_indices[j]
                best_x = candidates[best_index]

                num_re_evaluations_per_candidate = min(50, max_re_evaluation_budget - re_evaluation_budget_used)
                samples = np.array([problem(best_x) for _ in range(num_re_evaluations_per_candidate)])
                means[best_index] = np.mean(samples)
                evaluations += num_re_evaluations_per_candidate
                re_evaluation_budget_used += num_re_evaluations_per_candidate

            # Refine the top candidates with small perturbations
            for j in range(min(30, len(sorted_indices))):  # Refine top 30% of candidates
                if evaluations >= budget:
                    break
                best_index = sorted_indices[j]
                best_x, best_y = candidates[best_index], means[best_index]

                num_refinements = min(15, budget - evaluations)  # Ensure we do not exceed the budget
                for _ in range(num_refinements):
                    refined_x = np.clip(best_x + np.random.normal(0, 0.1, size=dim), lb, ub)
                    refined_y = problem(refined_x)
                    evaluations += 1

                    if refined_y < best_y:
                        best_x, best_y = refined_x, refined_y
                candidates[best_index] = best_x  # Update the candidate with the refined solution

            # Introduce new random candidates to explore the search space more aggressively
            num_new_candidates = min(40, budget - evaluations)  # Ensure we do not exceed the budget
            for _ in range(num_new_candidates):
                new_candidate = np.random.uniform(lb, ub, size=dim)
                new_y = problem(new_candidate)
                evaluations += 1

                if new_y < best_y:
                    candidates = np.vstack((candidates[:-1], new_candidate))  # Replace the worst candidate
                    means[-1] = new_y

        # Return the best solution found
        best_index = np.argmin(means)
        return candidates[best_index], float(means[best_index])