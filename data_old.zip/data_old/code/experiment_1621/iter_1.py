import numpy as np
from scipy.optimize import minimize

class HybridOptimizer:
    def __init__(self):
        self.pop_size = 20
        self.F = 1.0  # Mutation factor for Differential Evolution
        self.Cr = 0.7  # Crossover probability for Differential Evolution
        self.max_local_iter = 50  # Maximum iterations for L-BFGS

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))

        while evaluations < budget:
            for i in range(self.pop_size):
                if evaluations >= budget:
                    break

                # Select indices for mutation
                idxs = [idx for idx in range(self.pop_size) if idx != i]
                a, b, c = pop[np.random.choice(idxs, 3, replace=False)]

                # Perform Differential Mutation
                mutant = np.clip(a + self.F * (b - c), lb, ub)

                # Crossover
                crossover_mask = np.random.rand(dim) < self.Cr
                trial = np.where(crossover_mask, mutant, pop[i])

                # Evaluate the trial solution
                trial_y = float(problem(trial))
                evaluations += 1

                if trial_y < best_y:
                    best_x = trial
                    best_y = trial_y

                    # Perform local refinement using L-BFGS
                    def objective(x):
                        return problem(x)

                    res = minimize(objective, x0=best_x, method='L-BFGS-B', bounds=list(zip(lb, ub)), options={'maxiter': self.max_local_iter})
                    evaluations += res.nfev

                    if res.fun < best_y:
                        best_x = res.x
                        best_y = res.fun

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)