import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 50
        self.F = 1.0  # Mutation factor for Differential Evolution
        self.Cr = 0.7  # Crossover probability for Differential Evolution
        self.max_local_iter = 20  # Maximum iterations for local refinement
        self.epsilon = 1e-6  # Small value for numerical gradient approximation

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', [-5.0, -5.0, -5.0]), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', [5.0, 5.0, 5.0]), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb)))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evals = np.array([problem(ind) for ind in pop], dtype=float)
        evaluations = self.pop_size

        best_idx = np.argmin(evals)
        best_x = pop[best_idx]
        best_y = evals[best_idx]

        while evaluations < budget:
            # Vectorized Differential Evolution
            idxs = np.random.choice(self.pop_size, (self.pop_size, 3), replace=False)
            a, b, c = pop[idxs[:, 0]], pop[idxs[:, 1]], pop[idxs[:, 2]]
            mutant = np.clip(a + self.F * (b - c), lb, ub)

            crossover_mask = np.random.rand(*mutant.shape) < self.Cr
            trial = np.where(crossover_mask, mutant, pop)

            # Evaluate the trial solutions
            trial_evals = np.array([problem(ind) for ind in trial], dtype=float)
            evaluations += self.pop_size

            better_solutions = trial_evals < evals
            if np.any(better_solutions):
                pop[better_solutions] = trial[better_solutions]
                evals[better_solutions] = trial_evals[better_solutions]

                best_trial_idx = np.argmin(trial_evals)
                if trial_evals[best_trial_idx] < best_y:
                    best_x = trial[best_trial_idx].copy()
                    best_y = trial_evals[best_trial_idx]

                    # Perform local refinement using gradient descent
                    local_best_x, _evaluations = self.local_refinement(problem, best_x.copy(), lb, ub, budget - evaluations)
                    evaluations += _evaluations

                    if problem(local_best_x) < best_y:
                        best_x = local_best_x
                        best_y = float(problem(best_x))

        return best_x, float(best_y)

    def local_refinement(self, problem, x, lb, ub, budget):
        step_size = 0.1
        for _ in range(min(self.max_local_iter, budget // 3)):  # Ensure we do not exceed budget
            grad = self.numerical_gradient(problem, x, self.epsilon)
            new_x = np.clip(x - step_size * grad, lb, ub)

            if problem(new_x) < problem(x):
                x = new_x.copy()
            else:
                step_size *= 0.5  # Reduce step size if no improvement
        return x, (self.max_local_iter + 1) * len(x)  # Estimate evaluations based on max iterations

    def numerical_gradient(self, problem, x, epsilon):
        grad = np.zeros_like(x)
        for i in range(len(x)):
            x_plus = x.copy()
            x_minus = x.copy()

            x_plus[i] += epsilon
            x_minus[i] -= epsilon

            f_plus = float(problem(x_plus))
            f_minus = float(problem(x_minus))

            grad[i] = (f_plus - f_minus) / (2 * epsilon)
        return grad