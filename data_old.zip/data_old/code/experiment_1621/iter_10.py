import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 50
        self.F = 1.0  # Mutation factor for Differential Evolution
        self.Cr = 0.7  # Crossover probability for Differential Evolution
        self.max_local_iter = 5  # Reduced maximum iterations for local refinement
        self.epsilon = 1e-6  # Small value for numerical gradient approximation

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evals = [float(problem(ind)) for ind in pop]
        evaluations = self.pop_size

        best_idx = np.argmin(evals)
        best_x = pop[best_idx]
        best_y = evals[best_idx]

        while evaluations < budget:
            for i in range(self.pop_size):
                if evaluations >= budget:
                    break

                # Select indices for mutation
                idxs = [idx for idx in range(self.pop_size) if idx != i]
                a, b, c = pop[np.random.choice(idxs, 3, replace=False)]

                # Perform Differential Mutation
                mutant = np.clip(a + self.F * (b - c), lb, ub)

                # Crossover
                crossover_mask = np.random.rand(dim) < self.Cr
                trial = np.where(crossover_mask, mutant, pop[i])

                # Evaluate the trial solution
                trial_y = float(problem(trial))
                evaluations += 1

                if trial_y < best_y:
                    best_x = trial.copy()
                    best_y = trial_y

                    # Perform local refinement using gradient descent with adaptive step size
                    local_best_x = self.local_refinement(problem, best_x.copy(), lb, ub, budget - evaluations)
                    evaluations += self.max_local_iter * dim  # Each gradient step evaluates the function for each dimension

                    local_best_y = float(problem(local_best_x))
                    if local_best_y < best_y:
                        best_x = local_best_x
                        best_y = local_best_y

                    pop[i] = best_x.copy()
                else:
                    pop[i] = trial.copy()

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)

    def local_refinement(self, problem, x, lb, ub, budget):
        step_size = 0.1
        for _ in range(self.max_local_iter):
            if budget <= 0:
                break

            grad = self.numerical_gradient(problem, x, self.epsilon)
            new_x = np.clip(x - step_size * grad, lb, ub)

            # Adaptive step size adjustment based on improvement
            new_y = float(problem(new_x))
            evaluations = len(new_x)  # Each gradient step evaluates the function for each dimension

            if new_y < float(problem(x)):
                step_size *= 1.25  # Increase step size if improvement is observed
            else:
                step_size *= 0.75  # Decrease step size if no improvement

            x = new_x.copy()
            budget -= evaluations
        return x

    def numerical_gradient(self, problem, x, epsilon):
        dim = len(x)
        grad = np.zeros(dim)
        for i in range(dim):
            x_plus = x.copy()
            x_minus = x.copy()

            x_plus[i] += epsilon
            x_minus[i] -= epsilon

            f_plus = float(problem(x_plus))
            f_minus = float(problem(x_minus))

            grad[i] = (f_plus - f_minus) / (2 * epsilon)
        return grad