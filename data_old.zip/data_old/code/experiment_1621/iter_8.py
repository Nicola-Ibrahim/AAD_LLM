import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 50
        self.max_local_iter = 100  # Maximum iterations for local refinement
        self.epsilon = 1e-6  # Small value for numerical gradient approximation
        self.step_size_init = 0.1  # Initial step size for gradient descent

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evals = [float(problem(ind)) for ind in pop]
        evaluations = self.pop_size

        best_idx = np.argmin(evals)
        best_x = pop[best_idx]
        best_y = evals[best_idx]

        while evaluations < budget:
            # Randomly select an individual to refine
            idx = np.random.choice(self.pop_size)
            x = pop[idx].copy()

            # Perform local refinement using gradient descent with adaptive step size
            local_best_x, local_best_y, evaluations = self.local_refinement(problem, x, lb, ub, budget - evaluations, best_y)

            if local_best_y < best_y:
                best_x = local_best_x.copy()
                best_y = local_best_y

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)

    def local_refinement(self, problem, x, lb, ub, budget, global_best):
        step_size = self.step_size_init
        for _ in range(self.max_local_iter):
            if budget <= 0:
                break

            grad = self.numerical_gradient(problem, x, self.epsilon)
            new_x = np.clip(x - step_size * grad, lb, ub)

            # Evaluate the new position
            new_y = float(problem(new_x))
            evaluations = 1

            if new_y < global_best:
                # Reduce step size to exploit better
                step_size *= 0.95
            else:
                # Increase step size to explore more
                step_size *= 1.1

            x = new_x.copy()
        return x, new_y, evaluations

    def numerical_gradient(self, problem, x, epsilon):
        dim = len(x)
        grad = np.zeros(dim)
        for i in range(dim):
            x_plus = x.copy()
            x_minus = x.copy()

            x_plus[i] += epsilon
            x_minus[i] -= epsilon

            f_plus = float(problem(x_plus))
            f_minus = float(problem(x_minus))

            grad[i] = (f_plus - f_minus) / (2 * epsilon)
        return grad