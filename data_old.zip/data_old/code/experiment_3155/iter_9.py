import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 100
        self.dim = 10
        self.initial_population = None
        
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        
        # Initialize a random population
        self.initial_population = np.random.uniform(lb, ub, size=(self.pop_size, self.dim))
        
        evaluations = 1
        best_x = np.zeros(self.dim)
        best_y = float('inf')
        
        step_size = 0.5
        
        while evaluations <= budget:
            local_best_x = np.copy(self.initial_population[np.argmin(best_y)])
            
            # Gradient descent step
            gradient = problem.gradient(local_best_x)
            x_new = local_best_x - 0.1 * gradient
            
            if lb[0] < x_new[0] < ub[0] and lb[1] < x_new[1] < ub[1] and \
               lb[2] < x_new[2] < ub[2] and lb[3] < x_new[3] < ub[3] and \
               lb[4] < x_new[4] < ub[4] and lb[5] < x_new[5] < ub[5] and \
               lb[6] < x_new[6] < ub[6] and lb[7] < x_new[7] < ub[7] and \
               lb[8] < x_new[8] < ub[8] and lb[9] < x_new[9] < ub[9]:
                y_new = float(problem(x_new))
                
                if y_new < best_y:
                    best_x = x_new
                    best_y = y_new
            
            # Local search step
            for _ in range(50):
                random_direction = np.random.randn(self.dim)
                x_candidate = local_best_x + 0.1 * random_direction
                
                if lb[0] < x_candidate[0] < ub[0] and lb[1] < x_candidate[1] < ub[1] and \
                   lb[2] < x_candidate[2] < ub[2] and lb[3] < x_candidate[3] < ub[3] and \
                   lb[4] < x_candidate[4] < ub[4] and lb[5] < x_candidate[5] < ub[5] and \
                   lb[6] < x_candidate[6] < ub[6] and lb[7] < x_candidate[7] < ub[7] and \
                   lb[8] < x_candidate[8] < ub[8] and lb[9] < x_candidate[9] < ub[9]:
                    y_candidate = float(problem(x_candidate))
                    
                    if y_candidate < best_y:
                        local_best_x = x_candidate
                        best_y = y_candidate
            
            # Update the population with the best solution found
            self.initial_population[np.argmin(best_y)] = local_best_x
            
            # Adaptive step size adjustment
            step_size *= 0.95 if evaluations < budget / 2 else 1.05
            
            evaluations += 100
        
        return best_x, float(best_y)