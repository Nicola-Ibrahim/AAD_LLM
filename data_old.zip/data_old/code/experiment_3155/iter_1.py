import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize a random population
        initial_population = np.random.uniform(lb, ub, size=(100, dim))  # Population size and dimension are arbitrary
        evaluations = 1
        
        while evaluations <= budget:
            best_x = np.zeros(dim)
            for i in range(100):
                x = initial_population[i]
                gradient = problem.gradient(x)  # Compute the exact gradient
                step_size = 0.1 / (np.sqrt(evaluations * 0.1))  # Adaptive step size
                new_x = np.clip(x + step_size * gradient, lb, ub)
                
                y_new = float(problem(new_x))
                if y_new < best_y:
                    best_x = new_x
                    best_y = y_new
            
            initial_population = np.copy(best_x)  # Update the population with the best solution found
            
            evaluations += 100  # Increment evaluations by the number of solutions processed in this iteration

        return best_x, float(best_y)