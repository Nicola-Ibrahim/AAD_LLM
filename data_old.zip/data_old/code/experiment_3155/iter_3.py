import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize a random population
        initial_population = np.random.uniform(lb, ub, size=(100, dim))  # Population size and dimension are arbitrary
        
        evaluations = 1
        best_x = np.zeros(dim)
        best_y = float('inf')
        
        while evaluations <= budget:
            for i in range(100):
                x = initial_population[i]
                gradient = problem.gradient(x)  # Compute the exact gradient
                step_size = self.adaptive_step_size(evaluations, dim, gradient)  # Adaptive step size
                new_x = np.clip(x + step_size * gradient, lb, ub)
                
                y_new = float(problem(new_x))
                if y_new < best_y:
                    best_x = new_x
                    best_y = y_new
            
            # Update the population with a more robust selection strategy
            initial_population = self.select_best_from_population(initial_population, best_x, dim)
            
            evaluations += 100
        
        return best_x, float(best_y)
    
    def adaptive_step_size(self, evaluations, dim, gradient):
        # A simple adaptive step size based on gradient magnitude
        step_size = 0.1 / (np.sqrt(evaluations * 0.1) + np.linalg.norm(gradient))
        return step_size
    
    def select_best_from_population(self, population, best_x, dim):
        # Select the best solution and maintain diversity using a tournament selection
        n_tournaments = 10
        tournament_size = min(2, len(population))
        
        best_indices = []
        for _ in range(n_tournaments):
            indices = np.random.choice(len(population), size=tournament_size, replace=False)
            tournament_best = min(population[indices], key=lambda x: float(problem(x)))
            best_indices.append(np.where(population == tournament_best)[0][0])
        
        new_population = []
        for i in best_indices:
            if len(new_population) < 100:
                new_population.append(population[i])
            else:
                # Maintain diversity by occasionally replacing the worst
                worst_index = np.argmax(float(problem(population)))
                new_population[worst_index] = population[i]
        
        return np.asarray(new_population)