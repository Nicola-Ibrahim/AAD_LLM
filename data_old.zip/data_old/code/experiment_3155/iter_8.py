import numpy as np

class MyOptimizer:
    def __init__(self):
        pass
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        
        # Initialize a random population
        self.initial_population = np.random.uniform(lb, ub, size=(self.pop_size, self.dim))
        
        evaluations = 1
        best_x = np.zeros(self.dim)
        best_y = float('inf')
        
        step_size = 0.5
        
        while evaluations <= budget:
            local_best_x = np.copy(self.initial_population[np.argmin(best_y)])
            
            # Perform a random walk to explore the search space
            x = local_best_x + np.random.randn(self.dim) * step_size
            
            y_new = float(problem(x))
            
            if y_new < best_y:
                best_x = x
                best_y = y_new
            
            # Adaptive step size adjustment
            step_size *= 0.95 if evaluations < budget / 2 else 1.05
            
            evaluations += 100
        
        return best_x, float(best_y)