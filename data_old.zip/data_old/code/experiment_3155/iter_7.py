import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 100
        self.dim = 10
        self.initial_population = None
        
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        
        # Initialize a random population
        self.initial_population = np.random.uniform(lb, ub, size=(self.pop_size, self.dim))
        
        evaluations = 1
        best_x = np.zeros(self.dim)
        best_y = float('inf')
        
        step_size = 0.5
        
        while evaluations <= budget:
            local_best_x = np.copy(self.initial_population[np.argmin(best_y)])
            
            # Perform crossover to create offspring
            for _ in range(10):
                partner_index = np.random.randint(self.pop_size)
                partner_x = self.initial_population[partner_index]
                
                child_x = local_best_x * 0.5 + partner_x * 0.5
                
                y_new = float(problem(child_x))
                
                if y_new < best_y:
                    best_x = child_x
                    best_y = y_new
            
            # Perform mutation to create offspring
            for _ in range(10):
                child_x = local_best_x + np.random.randn(self.dim) * step_size
                
                y_new = float(problem(child_x))
                
                if y_new < best_y:
                    best_x = child_x
                    best_y = y_new
            
            # Update the population with the best solution found
            self.initial_population[np.argmin(best_y)] = best_x
            
            # Adaptive step size adjustment
            step_size *= 0.95 if evaluations < budget / 2 else 1.05
            
            evaluations += 100
        
        return best_x, float(best_y)