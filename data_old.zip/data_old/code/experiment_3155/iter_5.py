import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize a PSO swarm
        num_particles = 100
        swarm = np.random.uniform(lb, ub, size=(num_particles, dim))  # Population size and dimension are arbitrary
        velocities = np.zeros((num_particles, dim))
        p_best = np.copy(swarm)
        g_best = swarm[np.argmin(p_best)]
        
        evaluations = 1
        
        while evaluations <= budget:
            for i in range(num_particles):
                r1 = np.random.rand()
                r2 = np.random.rand()
                
                # Update velocity
                velocities[i] = w * velocities[i] + c1 * r1 * (p_best[i] - swarm[i]) + c2 * r2 * (g_best - swarm[i])
                
                # Update position
                new_position = swarm[i] + velocities[i]
                
                # Bound the position within the search space
                new_position = np.clip(new_position, lb, ub)
                
                # Evaluate the new position
                y_new = float(problem(new_position))
                
                if y_new < p_best[i]:
                    p_best[i] = new_position
                
                if y_new < g_best:
                    g_best = new_position
            
            evaluations += num_particles  # Increment evaluations by the number of particles processed in this iteration

        return g_best, float(g_best)