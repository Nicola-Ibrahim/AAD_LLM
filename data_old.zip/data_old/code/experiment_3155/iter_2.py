import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize a random population
        initial_population = np.random.uniform(lb, ub, size=(100, dim))  # Population size and dimension are arbitrary
        
        evaluations = 1
        
        best_x = np.zeros(dim)
        best_y = float('inf')
        
        while evaluations <= budget:
            # PSO Update
            for i in range(100):
                x = initial_population[i]
                v = 0.5 * (r1 * (initial_population[np.random.randint(1, 100)] - x) + r2 * (best_x - x))
                new_x = np.clip(x + v, lb, ub)
                
                y_new = float(problem(new_x))
                
                if y_new < best_y:
                    best_x = new_x
                    best_y = y_new
            
            # Update step size adaptively
            step_size = 0.1 / (np.sqrt(evaluations * 0.1))  # Adaptive step size
            
            # Gradient-based Search in the vicinity of the best solution
            gradient = problem.gradient(best_x)
            new_x = np.clip(best_x + step_size * gradient, lb, ub)
            
            y_new = float(problem(new_x))
            
            if y_new < best_y:
                best_x = new_x
                best_y = y_new
            
            evaluations += 100
        
        return best_x, float(best_y)