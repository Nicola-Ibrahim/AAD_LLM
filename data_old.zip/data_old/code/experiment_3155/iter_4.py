import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize a random population
        initial_population = np.random.uniform(lb, ub, size=(100, dim))  # Population size and dimension are arbitrary
        
        evaluations = 1
        best_x = np.zeros(dim)
        best_y = float('inf')
        
        while evaluations <= budget:
            local_best_x = np.copy(initial_population[np.argmin(best_y)])
            for i in range(100):
                x = local_best_x + 0.1 * np.random.randn(dim)  # Random perturbation
                y_new = float(problem(x))
                
                if y_new < best_y:
                    best_x = x
                    best_y = y_new
            
            initial_population = np.copy(best_x)  # Update the population with the best solution found
            
            evaluations += 100  # Increment evaluations by the number of solutions processed in this iteration

        return best_x, float(best_y)