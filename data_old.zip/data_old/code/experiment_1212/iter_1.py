import numpy as np

class PSOAlgorithm:
    def __init__(self):
        pass  # Initialization state not needed for this simple example

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 30
        particles = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        personal_best_positions = particles.copy()
        global_best_position = particles[np.argmin([problem(p) for p in particles])]
        global_best_value = float(problem(global_best_position))

        inertia_weight = 0.7
        cognitive_weight = 1.4
        social_weight = 1.4

        evaluations = pop_size  # Initialize with the initial population evaluations

        while evaluations < budget:
            for i, particle in enumerate(particles):
                personal_best_value = float(problem(personal_best_positions[i]))
                current_value = float(problem(particle))

                if current_value < personal_best_value:
                    personal_best_positions[i] = particle.copy()

                if current_value < global_best_value:
                    global_best_position = particle.copy()
                    global_best_value = current_value

            for i, velocity in enumerate(velocities):
                r1, r2 = np.random.rand(2)
                cognitive_term = cognitive_weight * r1 * (personal_best_positions[i] - particles[i])
                social_term = social_weight * r2 * (global_best_position - particles[i])
                velocities[i] = inertia_weight * velocity + cognitive_term + social_term
                particles[i] += velocities[i]

                # Apply bounds to the particles
                particles[i] = np.clip(particles[i], lb, ub)

            evaluations += pop_size

        return global_best_position, float(global_best_value)