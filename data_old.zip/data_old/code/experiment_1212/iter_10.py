import numpy as np

class AdaptivePSOAlgorithm:
    def __init__(self):
        pass  # Initialization state not needed for this simple example

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 30
        particles = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        personal_best_positions = particles.copy()
        global_best_position = particles[np.argmin([problem(p) for p in particles])]
        global_best_value = float(problem(global_best_position))

        inertia_weight = 0.7
        cognitive_weight = 1.4
        social_weight = 1.4

        evaluations = pop_size  # Initialize with the initial population evaluations

        while evaluations < budget:
            personal_best_values = np.array([problem(p) for p in particles], dtype=float)
            current_values = np.array([problem(p) for p in particles], dtype=float)

            # Re-evaluate each candidate multiple times to reduce noise
            num_retries = 5
            re_evaluated_personal_best_values = []
            re_evaluated_current_values = []

            for value, position in zip(personal_best_values, particles):
                retries = np.random.choice(10, size=num_retries) / 10.0 + 0.9  # Random values between 0.9 and 2.0
                re_evaluated_personal_best_values.append(np.mean([problem(position) * retry for retry in retries]))
            for value, position in zip(current_values, particles):
                retries = np.random.choice(10, size=num_retries) / 10.0 + 0.9  # Random values between 0.9 and 2.0
                re_evaluated_current_values.append(np.mean([problem(position) * retry for retry in retries]))

            # Update personal best positions and global best position using the mean values
            updated_indices = np.array(re_evaluated_personal_best_values) < np.array(re_evaluated_current_values)
            personal_best_positions[updated_indices] = particles[updated_indices]
            if np.any(updated_indices):
                new_global_best_index = np.argmin(np.array(re_evaluated_current_values)[updated_indices])
                global_best_position = particles[new_global_best_index].copy()
                global_best_value = re_evaluated_current_values[new_global_best_index]

            # Update velocities and positions
            r1, r2 = np.random.rand(2)
            cognitive_term = cognitive_weight * r1 * (personal_best_positions - particles)
            social_term = social_weight * r2 * (global_best_position - particles)
            velocities = inertia_weight * velocities + cognitive_term + social_term
            particles += velocities

            # Apply bounds to the particles
            particles = np.clip(particles, lb, ub)

            evaluations += pop_size

        return global_best_position, float(global_best_value)