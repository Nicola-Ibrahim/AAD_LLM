import numpy as np

class EnhancedPSOAlgorithm:
    def __init__(self):
        pass  # Initialization state not needed for this simple example

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 30
        particles = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        personal_best_positions = particles.copy()
        global_best_position = particles[np.argmin([problem(p) for p in particles])]
        global_best_value = float(problem(global_best_position))

        inertia_weight = 0.7
        cognitive_weight = 1.4
        social_weight = 1.4

        evaluations = pop_size  # Initialize with the initial population evaluations

        while evaluations < budget:
            personal_best_values = np.array([problem(p) for p in particles], dtype=float)
            current_values = np.array([problem(p) for p in particles], dtype=float)

            # Update personal best positions and global best position
            updated_indices = personal_best_values < current_values
            personal_best_positions[updated_indices] = particles[updated_indices]
            if np.any(updated_indices):
                new_global_best_index = np.argmin(current_values[updated_indices])
                global_best_position = particles[new_global_best_index].copy()
                global_best_value = current_values[new_global_best_index]

            # Update velocities and positions
            r1, r2 = np.random.rand(2)
            cognitive_term = cognitive_weight * r1 * (personal_best_positions - particles)
            social_term = social_weight * r2 * (global_best_position - particles)
            velocities = inertia_weight * velocities + cognitive_term + social_term
            particles += velocities

            # Apply bounds to the particles
            particles = np.clip(particles, lb, ub)

            evaluations += pop_size

        return global_best_position, float(global_best_value)