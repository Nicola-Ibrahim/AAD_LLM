import numpy as np

class AdaptiveDiversityOptimizer:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        pop_size = 100
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = 0

        # Evaluate the initial population
        fitness = np.array([float(problem(x)) for x in population])
        evaluations += pop_size
        best_idx = np.argmin(fitness)
        best_x = population[best_idx].copy()
        best_y = fitness[best_idx]

        # Parameters
        mutation_rate = 0.1
        step_size = 1.0
        decay_factor = 0.99

        while evaluations < budget:
            # Mutation
            new_population = population + np.random.normal(0, step_size * mutation_rate, size=(pop_size, dim))
            new_population = np.clip(new_population, lb, ub)
            evaluations += pop_size

            # Evaluate new population
            new_fitness = np.array([float(problem(x)) for x in new_population])
            evaluations += pop_size

            # Selection: Combine old and new population
            combined_population = np.vstack((population, new_population))
            combined_fitness = np.concatenate((fitness, new_fitness))

            # Update best solution
            idx = np.argmin(combined_fitness)
            if combined_fitness[idx] < best_y:
                best_x = combined_population[idx].copy()
                best_y = combined_fitness[idx]

            # Update population
            sorted_indices = np.argsort(combined_fitness)
            population = combined_population[sorted_indices[:pop_size]]
            fitness = combined_fitness[sorted_indices[:pop_size]]

            # Decay step size
            step_size *= decay_factor

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)