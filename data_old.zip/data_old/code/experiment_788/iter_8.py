import numpy as np

class MyOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = 0

        # Evaluate the initial population
        fitness = np.array([float(problem(x)) for x in population])
        evaluations += pop_size
        best_idx = np.argmin(fitness)
        best_x = population[best_idx].copy()
        best_y = fitness[best_idx]

        # Parameters
        mutation_rate = 0.1
        step_size = 1.0
        decay_factor = 0.995
        re_evaluations_per_candidate = 7

        while evaluations < budget:
            # Re-evaluation: Evaluate each candidate multiple times and take the median
            new_fitness = np.array([np.median([float(problem(x)) for _ in range(re_evaluations_per_candidate)]) for x in population])
            evaluations += pop_size * re_evaluations_per_candidate

            # Mutation
            mutation_mask = np.random.rand(pop_size, dim) < mutation_rate
            mutation_vector = np.random.normal(0, step_size, size=(pop_size, dim))
            new_population = population.copy()
            new_population[mutation_mask] += mutation_vector[mutation_mask]
            new_population = np.clip(new_population, lb, ub)
            evaluations += pop_size

            # Crossover
            for i in range(pop_size):
                if np.random.rand() < mutation_rate:
                    partner_idx = np.random.randint(0, pop_size)
                    crossover_point = np.random.randint(0, dim)
                    new_population[i, crossover_point:] = population[partner_idx, crossover_point:]

            # Evaluate new population
            new_fitness_new = np.array([np.median([float(problem(x)) for _ in range(re_evaluations_per_candidate)]) for x in new_population])
            evaluations += pop_size * re_evaluations_per_candidate

            # Selection: Combine old and new population
            combined_population = np.vstack((population, new_population))
            combined_fitness = np.concatenate((new_fitness, new_fitness_new))

            # Update best solution
            idx = np.argmin(combined_fitness)
            if combined_fitness[idx] < best_y:
                best_x = combined_population[idx].copy()
                best_y = combined_fitness[idx]

            # Update population
            sorted_indices = np.argsort(combined_fitness)
            population = combined_population[sorted_indices[:pop_size]]
            fitness = combined_fitness[sorted_indices[:pop_size]]

            # Decay step size
            step_size *= decay_factor

            # Adapt mutation rate based on population diversity and progress
            std_dev = np.std(population, axis=0).mean()
            if evaluations < budget / 2:
                mutation_rate += 0.01 * (1 - (evaluations / (budget / 2)))
            else:
                mutation_rate -= 0.01 * ((evaluations - (budget / 2)) / (budget / 2))
            mutation_rate = max(0.01, min(mutation_rate, 0.5))

        return best_x, float(best_y)