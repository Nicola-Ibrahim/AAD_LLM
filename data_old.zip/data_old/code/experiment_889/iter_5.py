import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 128  # Increased population size for better exploration
        self.inertia_weight = 0.7  # Inertia weight for PSO
        self.cognitive_coefficient = 1.5  # Cognitive coefficient for PSO
        self.social_coefficient = 1.5  # Social coefficient for PSO
        self.mutation_rate = 0.2  # Initial mutation rate for ES
        self.re_eval_count = 5  # Number of evaluations per candidate

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and velocities randomly
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        velocities = np.zeros_like(population)  # Initialize velocities to zero

        pbest_positions = population.copy()
        pbest_values = np.array([problem(x) for x in population])
        evaluations = self.pop_size * self.re_eval_count  # Initial evaluations for all candidates

        gbest_index = np.argmin(pbest_values)
        gbest_position = pbest_positions[gbest_index]
        best_y = pbest_values[gbest_index]

        while evaluations < budget:
            # Update velocities and positions using PSO
            velocities = (self.inertia_weight * velocities +
                         self.cognitive_coefficient * np.random.rand(self.pop_size, dim) * (pbest_positions - population) +
                         self.social_coefficient * np.random.rand(self.pop_size, dim) * (gbest_position - population))
            population += velocities

            # Clip positions to bounds
            population = np.clip(population, lb, ub)

            # Re-evaluate new positions and update personal bests
            for i in range(self.pop_size):
                if evaluations >= budget:
                    break
                candidate = population[i]
                values = [problem(candidate) for _ in range(self.re_eval_count)]
                new_value = np.mean(values)
                evaluations += self.re_eval_count
                if new_value < pbest_values[i]:
                    pbest_positions[i] = candidate
                    pbest_values[i] = new_value

            # Update global best
            gbest_index = np.argmin(pbest_values)
            if pbest_values[gbest_index] < best_y:
                gbest_position = pbest_positions[gbest_index]
                best_y = pbest_values[gbest_index]

            # Introduce mutations for exploration using ES with adaptive mutation rate
            mutation_indices = np.random.rand(self.pop_size) < self.mutation_rate
            population[mutation_indices] += np.random.normal(0, 1, size=(np.sum(mutation_indices), dim))
            population[mutation_indices] = np.clip(population[mutation_indices], lb, ub)

            # Re-evaluate mutated positions and update personal bests
            for i in range(self.pop_size):
                if evaluations >= budget:
                    break
                candidate = population[i]
                values = [problem(candidate) for _ in range(self.re_eval_count)]
                new_value = np.mean(values)
                evaluations += self.re_eval_count
                if new_value < pbest_values[i]:
                    pbest_positions[i] = candidate
                    pbest_values[i] = new_value

            # Update global best again after mutations
            gbest_index = np.argmin(pbest_values)
            if pbest_values[gbest_index] < best_y:
                gbest_position = pbest_positions[gbest_index]
                best_y = pbest_values[gbest_index]

        return gbest_position, float(best_y)