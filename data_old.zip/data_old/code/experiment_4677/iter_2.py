import numpy as np

class NoiseResilientOptimizer:
    def __init__(self, num_reevaluations=5):
        self.num_reevaluations = num_reevaluations

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population with random points
        pop_size = min(10, budget // self.num_reevaluations)  # Number of candidates to evaluate at once
        evaluations = 0

        best_x = None
        best_y = float('inf')
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        
        while evaluations < budget:
            # Evaluate the population multiple times and compute mean values
            reevaluation_budget = min(budget - evaluations, int(0.2 * budget))  # Limit to 20% of total budget
            reevaluations_per_candidate = self.num_reevaluations
            remaining_reevaluations = reevaluation_budget // reevaluations_per_candidate
            
            values = np.zeros((pop_size, reevaluations_per_candidate))
            for i in range(reevaluations_per_candidate):
                if remaining_reevaluations <= 0:
                    break
                values[:, i] = [problem(x) for x in population]
                remaining_reevaluations -= 1
            
            mean_values = np.mean(values, axis=1)
            evaluations += pop_size * reevaluations_per_candidate

            # Update the best solution found so far
            current_best_idx = np.argmin(mean_values)
            if mean_values[current_best_idx] < best_y:
                best_x = population[current_best_idx].copy()
                best_y = mean_values[current_best_idx]

            # Generate new candidates using mutation (simple approach, can be improved)
            mutated_population = np.clip(population + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)
            
            # Replace the population with the mutated population for the next iteration
            population = mutated_population

        return best_x, float(best_y)