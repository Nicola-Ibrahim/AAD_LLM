import numpy as np

class NoiseResilientOptimizer:
    def __init__(self):
        pass  # No initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population with random points
        pop_size = 10  # Number of candidates to evaluate at once
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        
        best_x = None
        best_y = float('inf')
        evaluations = 0

        reevaluation_budget = int(budget * 0.2)  # Allow up to 20% of the budget for re-evaluations
        num_reevaluations = min(10, reevaluation_budget // pop_size)  # Re-evaluate each candidate a few times

        while evaluations < budget:
            # Evaluate the population with multiple noisy observations
            values = np.array([np.median([problem(x) for _ in range(num_reevaluations)]) for x in population])
            evaluations += pop_size * num_reevaluations

            # Update the best solution found so far
            current_best_idx = np.argmin(values)
            if values[current_best_idx] < best_y:
                best_x = population[current_best_idx].copy()
                best_y = values[current_best_idx]

            # Generate new candidates using mutation (simple approach, can be improved)
            mutated_population = np.clip(population + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)
            
            # Replace the population with the mutated population for the next iteration
            population = mutated_population

        return best_x, float(best_y)