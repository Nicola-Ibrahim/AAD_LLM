import numpy as np

class NoiseResilientOptimizer:
    def __init__(self):
        pass  # No initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10  # Number of candidates to evaluate at once
        num_repeats = 5  # Number of re-evaluations per candidate
        
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        
        best_x = None
        best_y = float('inf')
        evaluations = 0

        while evaluations < budget:
            # Evaluate the population multiple times and compute mean values
            values = np.array([[problem(x) for _ in range(num_repeats)] for x in population])
            mean_values = np.mean(values, axis=1)  # Compute mean of re-evaluations
            evaluations += pop_size * num_repeats

            # Update the best solution found so far
            current_best_idx = np.argmin(mean_values)
            if mean_values[current_best_idx] < best_y:
                best_x = population[current_best_idx].copy()
                best_y = mean_values[current_best_idx]

            # Generate new candidates using mutation (simple approach, can be improved)
            mutated_population = np.clip(population + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)
            
            # Replace the population with the mutated population for the next iteration
            population = mutated_population

            # Ensure we do not exceed the budget by re-evaluations
            if evaluations >= budget * 0.8:
                break

        return best_x, float(best_y)