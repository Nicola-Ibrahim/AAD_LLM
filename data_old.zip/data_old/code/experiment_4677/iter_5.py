import numpy as np

class NoiseResilientOptimizer:
    def __init__(self):
        pass  # No initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population with random points
        pop_size = 10  # Number of candidates to evaluate at once
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        
        best_x = None
        best_y = float('inf')
        evaluations = 0

        reevaluation_budget = int(budget * 0.2)  # Allow up to 20% of the budget for re-evaluations
        max_reevaluations = min(100, reevaluation_budget // pop_size)  # Re-evaluate each candidate up to 100 times

        while evaluations < budget:
            # Evaluate the population with multiple noisy observations
            values = np.array([np.mean([problem(x) for _ in range(max_reevaluations)]) for x in population])
            evaluations += pop_size * max_reevaluations

            # Update the best solution found so far
            current_best_idx = np.argmin(values)
            if values[current_best_idx] < best_y:
                best_x = population[current_best_idx].copy()
                best_y = values[current_best_idx]

            # Generate new candidates using mutation (simple approach, can be improved)
            mutated_population = np.clip(population + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)
            
            # Replace the population with a mix of current and mutated candidates for the next iteration
            num_to_mutate = max(1, int(pop_size * 0.2))  # Mutate up to 20% of the population each generation
            mutation_indices = np.random.choice(pop_size, size=num_to_mutate, replace=False)
            population[mutation_indices] = mutated_population[mutation_indices]

        return best_x, float(best_y)