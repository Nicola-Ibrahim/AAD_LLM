import numpy as np

class AdaptiveEvolutionStrategy:
    def __init__(self):
        self.population_size = 50
        self.initial_sigma = 1.0
        self.learning_rate = 0.3
        self.num_reevaluations = 5
        self.adaptive_factor = 0.95
        self.moving_window_size = 10

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.population_size, dim))
        evaluations = 0

        while evaluations < budget:
            # Evaluate the current population with reevaluation
            fitnesses = self._reevaluate_population(pop, problem)
            evaluations += self.population_size * self.num_reevaluations

            # Find the best individual
            best_idx = np.argmin(fitnesses)
            best_x, best_y = pop[best_idx], fitnesses[best_idx]

            # Mutate and create new population
            mutation = np.random.normal(0, self.initial_sigma, size=(self.population_size, dim))
            mutated_pop = pop + self.learning_rate * mutation

            # Clip to bounds
            mutated_pop = np.clip(mutated_pop, lb, ub)

            # Evaluate the mutated population with reevaluation
            mutated_fitnesses = self._reevaluate_population(mutated_pop, problem)
            evaluations += self.population_size * self.num_reevaluations

            # Combine original and mutated populations based on fitness
            combined_pop = np.vstack((pop, mutated_pop))
            combined_fitnesses = np.hstack((fitnesses, mutated_fitnesses))

            # Sort by fitness
            sort_indices = np.argsort(combined_fitnesses)
            pop = combined_pop[sort_indices][:self.population_size]

            # Update sigma based on performance
            avg_improvement = np.mean(np.abs(best_y - fitnesses))
            if avg_improvement < 1e-5:
                self.initial_sigma *= self.adaptive_factor

        return best_x, float(best_y)

    def _reevaluate_population(self, pop, problem):
        reevaluated_fitnesses = []
        for x in pop:
            total_value = 0
            for _ in range(self.num_reevaluations):
                total_value += float(problem(x))
            reevaluated_fitnesses.append(total_value / self.num_reevaluations)
        return np.array(reevaluated_fitnesses)