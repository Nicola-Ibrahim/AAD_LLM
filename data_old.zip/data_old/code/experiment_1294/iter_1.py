import numpy as np

class EvolutionStrategy:
    def __init__(self):
        self.population_size = 50
        self.sigma = 1.0
        self.learning_rate = 0.3

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.population_size, dim))
        evaluations = 0

        while evaluations < budget:
            # Evaluate the current population
            fitnesses = np.array([float(problem(x)) for x in pop])
            evaluations += self.population_size

            # Find the best individual
            best_idx = np.argmin(fitnesses)
            best_x, best_y = pop[best_idx], fitnesses[best_idx]

            # Mutate and create new population
            mutation = np.random.normal(0, self.sigma, size=(self.population_size, dim))
            mutated_pop = pop + self.learning_rate * mutation

            # Clip to bounds
            mutated_pop = np.clip(mutated_pop, lb, ub)

            # Evaluate the mutated population
            mutated_fitnesses = np.array([float(problem(x)) for x in mutated_pop])
            evaluations += self.population_size

            # Combine original and mutated populations based on fitness
            combined_pop = np.vstack((pop, mutated_pop))
            combined_fitnesses = np.hstack((fitnesses, mutated_fitnesses))

            # Sort by fitness
            sort_indices = np.argsort(combined_fitnesses)
            pop = combined_pop[sort_indices][:self.population_size]

        return best_x, float(best_y)