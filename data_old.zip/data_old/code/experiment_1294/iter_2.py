import numpy as np

class ImprovedEvolutionStrategy:
    def __init__(self):
        self.population_size = 50
        self.initial_sigma = 1.0
        self.learning_rate = 0.3
        self.re_evaluation_factor = 20
        self.max_re_evaluations = None

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.population_size, dim))
        evaluations = 0

        # Calculate the maximum number of re-evaluations allowed
        self.max_re_evaluations = int(budget * self.re_evaluation_factor) // (self.population_size * dim)

        while evaluations < budget:
            # Evaluate the current population with re-evaluation
            fitnesses = np.array([np.mean([float(problem(x)) for _ in range(self.max_re_evaluations)]) for x in pop])
            evaluations += self.population_size

            # Find the best individual
            best_idx = np.argmin(fitnesses)
            best_x, best_y = pop[best_idx], fitnesses[best_idx]

            # Mutate and create new population
            mutation = np.random.normal(0, self.initial_sigma, size=(self.population_size, dim))
            mutated_pop = pop + self.learning_rate * mutation

            # Clip to bounds
            mutated_pop = np.clip(mutated_pop, lb, ub)

            # Evaluate the mutated population with re-evaluation
            mutated_fitnesses = np.array([np.mean([float(problem(x)) for _ in range(self.max_re_evaluations)]) for x in mutated_pop])
            evaluations += self.population_size

            # Combine original and mutated populations based on fitness
            combined_pop = np.vstack((pop, mutated_pop))
            combined_fitnesses = np.hstack((fitnesses, mutated_fitnesses))

            # Sort by fitness
            sort_indices = np.argsort(combined_fitnesses)
            pop = combined_pop[sort_indices][:self.population_size]

            # Dynamically adjust mutation strength based on performance
            if best_idx == 0:
                self.initial_sigma *= 1.2
            else:
                self.initial_sigma *= 0.8

        return best_x, float(best_y)