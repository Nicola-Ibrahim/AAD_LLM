import numpy as np

class OptimizedDifferentialEvolution:
    def __init__(self):
        self.pop_size = 50  # Initial population size
        self.mutation_factor = 0.8  # Mutation factor
        self.crossover_rate = 0.9  # Crossover rate
        self.dynamic_scaling = 1.0  # Dynamic scaling factor for mutation

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([problem(x) for x in pop])
        evaluations = self.pop_size

        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Mutation
            mutated = np.zeros_like(pop)
            for i in range(self.pop_size):
                indices = list(range(self.pop_size))
                indices.remove(i)
                a, b, c = np.random.choice(indices, 3, replace=False)
                mutated[i] = pop[a] + self.mutation_factor * self.dynamic_scaling * (pop[b] - pop[c])
                mutated[i] = np.clip(mutated[i], lb, ub)  # Ensure within bounds

            # Crossover
            trial = np.zeros_like(pop)
            for i in range(self.pop_size):
                crossover_mask = np.random.rand(dim) < self.crossover_rate
                trial[i] = np.where(crossover_mask, mutated[i], pop[i])

            # Evaluate trial solutions
            trial_fitness = np.array([problem(x) for x in trial])
            evaluations += len(trial)

            # Selection
            mask = trial_fitness < fitness
            pop[mask] = trial[mask]
            fitness[mask] = trial_fitness[mask]

            # Update best solution
            new_best_idx = np.argmin(fitness)
            if fitness[new_best_idx] < best_y:
                best_x = pop[new_best_idx]
                best_y = fitness[new_best_idx]

            # Dynamic scaling adjustment based on diversity
            std_devs = np.std(pop, axis=0)
            self.dynamic_scaling = 1.0 / (1.0 + np.exp(-std_devs.mean()))

        return best_x, float(best_y)