import numpy as np

class AdaptiveNoisyPSO:
    def __init__(self):
        pass  # Initialization can be done here if needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and velocities
        pop_size = 20
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        vel = np.zeros_like(pop)
        pbest = np.copy(pop)
        pbest_y = np.full(pop_size, np.inf)

        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # Initialize model for ensemble
        models = []
        for _ in range(5):  # Use 5 models in the ensemble
            model = lambda x: problem(x) + np.random.normal(0, 0.5, size=x.shape)
            models.append(model)

        while evaluations < budget:
            # Evaluate the population using the ensemble of models
            y_ensemble = [np.array([model(x) for x in pop]) for model in models]
            y_mean = np.mean(y_ensemble, axis=0)
            y_std = np.std(y_ensemble, axis=0)
            evaluations += pop_size

            # Update personal bests with the ensemble mean
            mask = y_mean < pbest_y
            pbest[mask] = pop[mask]
            pbest_y[mask] = y_mean[mask]

            # Update global best based on the ensemble mean
            global_mask = y_mean < best_y
            if np.any(global_mask):
                best_x = pop[global_mask][0]
                best_y = y_mean[global_mask][0]

            # PSO update rules with adaptive step size
            r1, r2 = np.random.rand(2, pop_size, dim)
            w = 0.9 - (0.9 - 0.4) * evaluations / budget  # Decrease inertia weight over time
            c1 = 1.5 + 2.5 * evaluations / budget  # Increase cognitive coefficient over time
            c2 = 1.5 + 2.5 * evaluations / budget  # Increase social coefficient over time
            vel = w * vel + c1 * r1 * (pbest - pop) + c2 * r2 * (np.array(best_x).reshape(1, -1) - pop)
            pop += vel

            # Ensure bounds
            pop = np.clip(pop, lb, ub)

        return best_x, float(best_y)