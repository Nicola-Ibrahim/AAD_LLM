import numpy as np

class EnhancedPSO:
    def __init__(self):
        pass  # Initialization can be done here if needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and velocities
        pop_size = 20
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        vel = np.zeros_like(pop)
        pbest = np.copy(pop)
        pbest_y = np.full(pop_size, np.inf)

        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        while evaluations < budget:
            # Evaluate the population
            y = np.array([float(problem(x)) for x in pop])
            evaluations += pop_size

            # Update personal bests
            mask = y < pbest_y
            pbest[mask] = pop[mask]
            pbest_y[mask] = y[mask]

            # Update global best
            global_mask = y < best_y
            if np.any(global_mask):
                best_x = pop[global_mask][0]
                best_y = y[global_mask][0]

            # PSO update rules with adaptive step size and coefficients
            r1, r2 = np.random.rand(2, pop_size, dim)
            inertia_weight = 0.9 - (0.9 - 0.4) * evaluations / budget
            cognitive_coefficient = 1.5 + (2.5 - 1.5) * (evaluations ** 0.6) / (budget ** 0.6)
            social_coefficient = 1.5 + (2.5 - 1.5) * (evaluations ** 0.6) / (budget ** 0.6)

            vel = inertia_weight * vel + cognitive_coefficient * r1 * (pbest - pop) + social_coefficient * r2 * (np.array(best_x).reshape(1, -1) - pop)
            pop += vel

            # Ensure bounds
            pop = np.clip(pop, lb, ub)

        return best_x, float(best_y)