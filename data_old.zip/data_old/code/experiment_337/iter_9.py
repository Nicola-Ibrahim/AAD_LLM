import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this problem-specific algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        step_size_factor = 0.95
        learning_rate = 0.001
        min_improvement_threshold = -1e-4
        max_iterations_without_improvement = 200

        # Initial exploration phase
        for _ in range(2000):
            pop_size = 50
            candidates = np.clip(np.random.normal(0, 0.1, (pop_size, dim)), lb, ub)

            # Evaluate each candidate
            ys = np.array([float(problem(x)) for x in candidates])
            evaluations += len(candidates)

            # Find the best candidate and update best_x if necessary
            best_index = np.argmin(ys)
            current_y = ys[best_index]

            if current_y < best_y:
                best_x = candidates[best_index]
                best_y = current_y

            # Adaptive step size based on distance to best solution
            step_size_factor = max(step_size_factor * (1 + learning_rate), 0.9)
            step_size = 0.1 * step_size_factor

            # Adjust candidates using the adaptive step size
            candidates += np.random.normal(0, step_size, (pop_size, dim))

            # Local search to refine solutions
            local_best_y = float(problem(best_x))
            for i in range(pop_size):
                if ys[i] < local_best_y:
                    local_best_y = ys[i]
                    best_x = candidates[i]

        # Main exploitation phase with early stopping mechanism
        best_y_no_improvement = best_y
        no_improvement_iterations = 0

        while evaluations < budget and no_improvement_iterations < max_iterations_without_improvement:
            pop_size = 50
            candidates = np.clip(np.random.normal(0, 0.1, (pop_size, dim)), lb, ub)

            # Evaluate each candidate
            ys = np.array([float(problem(x)) for x in candidates])
            evaluations += len(candidates)

            # Find the best candidate and update best_x if necessary
            best_index = np.argmin(ys)
            current_y = ys[best_index]

            if current_y < best_y:
                best_x = candidates[best_index]
                best_y = current_y

            # Adaptive step size based on distance to best solution
            step_size_factor = max(step_size_factor * (1 + learning_rate), 0.9)
            step_size = 0.1 * step_size_factor

            # Adjust candidates using the adaptive step size
            candidates += np.random.normal(0, step_size, (pop_size, dim))

            # Local search to refine solutions
            local_best_y = float(problem(best_x))
            for i in range(pop_size):
                if ys[i] < local_best_y:
                    local_best_y = ys[i]
                    best_x = candidates[i]

            # Check for no improvement and update learning rate
            if current_y > best_y_no_improvement + min_improvement_threshold:
                no_improvement_iterations += 1
                step_size_factor *= np.exp(-learning_rate * no_improvement_iterations)
            else:
                no_improvement_iterations = 0
                best_y_no_improvement = current_y

        return best_x, float(best_y)