import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this problem-specific algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # Initial exploration phase
        pop_size = 50
        candidates = np.clip(np.random.normal(0, 0.1, (pop_size, dim)), lb, ub)

        # Evaluate each candidate
        ys = np.array([float(problem(x)) for x in candidates])
        evaluations += len(candidates)

        # Find the best candidate and update best_x if necessary
        best_index = np.argmin(ys)
        current_y = ys[best_index]

        if current_y < best_y:
            best_x = candidates[best_index]
            best_y = current_y

        # Adaptive step size based on distance to best solution
        step_size_factor = 0.995 ** (np.linalg.norm(candidates - best_x) / np.linalg.norm(best_x))
        step_size = 0.1 * step_size_factor

        # Adjust candidates using the adaptive step size
        candidates += np.random.normal(0, step_size, (pop_size, dim))

        # Local search to refine solutions using PSO or simulated annealing
        local_search_iterations = 5
        for _ in range(local_search_iterations):
            for i in range(pop_size):
                if ys[i] < best_y:
                    current_best_x = candidates[i]
                    current_best_y = ys[i]

                    # Simulated Annealing (SA) to refine the solution
                    T = 100.0
                    alpha = 0.95
                    while T > 0.1:
                        new_candidate = np.clip(current_best_x + np.random.normal(0, 0.1, dim), lb, ub)
                        new_y = float(problem(new_candidate))

                        # Acceptance probability based on SA
                        if new_y < current_best_y:
                            current_best_x = new_candidate
                            current_best_y = new_y
                        elif np.random.rand() < np.exp((current_best_y - new_y) / T):
                            current_best_x = new_candidate
                            current_best_y = new_y

                        T *= alpha

                    candidates[i] = current_best_x
                    ys[i] = current_best_y

        # Main exploitation phase
        while evaluations < budget:
            pop_size = 50
            candidates = np.clip(np.random.normal(0, 0.1, (pop_size, dim)), lb, ub)

            # Evaluate each candidate
            ys = np.array([float(problem(x)) for x in candidates])
            evaluations += len(candidates)

            # Find the best candidate and update best_x if necessary
            best_index = np.argmin(ys)
            current_y = ys[best_index]

            if current_y < best_y:
                best_x = candidates[best_index]
                best_y = current_y

            # Adaptive step size based on distance to best solution
            step_size_factor = 0.995 ** (np.linalg.norm(candidates - best_x) / np.linalg.norm(best_x))
            step_size = 0.1 * step_size_factor

            # Adjust candidates using the adaptive step size
            candidates += np.random.normal(0, step_size, (pop_size, dim))

            # Local search to refine solutions using PSO or simulated annealing
            local_search_iterations = 5
            for _ in range(local_search_iterations):
                for i in range(pop_size):
                    if ys[i] < best_y:
                        current_best_x = candidates[i]
                        current_best_y = ys[i]

                        # Simulated Annealing (SA) to refine the solution
                        T = 100.0
                        alpha = 0.95
                        while T > 0.1:
                            new_candidate = np.clip(current_best_x + np.random.normal(0, 0.1, dim), lb, ub)
                            new_y = float(problem(new_candidate))

                            # Acceptance probability based on SA
                            if new_y < current_best_y:
                                current_best_x = new_candidate
                                current_best_y = new_y
                            elif np.random.rand() < np.exp((current_best_y - new_y) / T):
                                current_best_x = new_candidate
                                current_best_y = new_y

                        candidates[i] = current_best_x
                        ys[i] = current_best_y

        return best_x, float(best_y)