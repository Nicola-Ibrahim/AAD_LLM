import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this problem-specific algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a uniform initial point using vectorization
        best_x = np.full(dim, -4.829671)  # A common starting point for BBOB Problem 21
        best_y = float(problem(best_x))
        evaluations = 1

        # Initial exploration phase
        for _ in range(1000):
            pop_size = 50
            candidates = np.clip(np.random.normal(best_x, 0.5, (pop_size, dim)), lb, ub)

            # Evaluate each candidate
            ys = np.array([float(problem(x)) for x in candidates])
            evaluations += len(candidates)

            # Find the best candidate and update best_x if necessary
            best_index = np.argmin(ys)
            current_y = ys[best_index]

            if current_y < best_y:
                best_x = candidates[best_index]
                best_y = current_y

            # Adaptive step size based on distance to best solution
            step_size_factor = 0.995 ** (np.linalg.norm(candidates - best_x) / np.linalg.norm(best_x))
            step_size = 0.1 * step_size_factor

            # Adjust candidates using the adaptive step size
            candidates += np.random.normal(0, step_size, (pop_size, dim))

            # Local search to refine solutions using gradient information
            grad_y = problem.grad(best_x)
            if grad_y is not None:
                step = -grad_y * 0.1
                next_x = np.clip(best_x + step, lb, ub)
                next_y = float(problem(next_x))
                evaluations += 1

                if next_y < current_y:
                    best_x = next_x
                    best_y = next_y

        # Main exploitation phase
        while evaluations < budget:
            pop_size = 50
            candidates = np.clip(np.random.normal(best_x, 0.2, (pop_size, dim)), lb, ub)

            # Evaluate each candidate
            ys = np.array([float(problem(x)) for x in candidates])
            evaluations += len(candidates)

            # Find the best candidate and update best_x if necessary
            best_index = np.argmin(ys)
            current_y = ys[best_index]

            if current_y < best_y:
                best_x = candidates[best_index]
                best_y = current_y

            # Adaptive step size based on distance to best solution
            step_size_factor = 0.995 ** (np.linalg.norm(candidates - best_x) / np.linalg.norm(best_x))
            step_size = 0.1 * step_size_factor

            # Adjust candidates using the adaptive step size
            candidates += np.random.normal(0, step_size, (pop_size, dim))

            # Local search to refine solutions using gradient information
            grad_y = problem.grad(best_x)
            if grad_y is not None:
                step = -grad_y * 0.1
                next_x = np.clip(best_x + step, lb, ub)
                next_y = float(problem(next_x))
                evaluations += 1

                if next_y < current_y:
                    best_x = next_x
                    best_y = next_y

        return best_x, float(best_y)