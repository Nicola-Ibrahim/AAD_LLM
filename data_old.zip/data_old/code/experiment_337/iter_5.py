import numpy as np

class MyOptimizer:
    def __init__(self):
        pass  # No initialization needed for this problem-specific algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        while evaluations < budget:
            # Generate candidates in batches
            pop_size = 50
            candidates = np.clip(np.random.normal(0, 0.1, (pop_size, dim)), lb, ub)

            # Evaluate each candidate
            ys = np.array([float(problem(x)) for x in candidates])
            evaluations += len(candidates)

            # Find the best candidate and update best_x if necessary
            best_index = np.argmin(ys)
            current_y = ys[best_index]

            if current_y < best_y:
                best_x = candidates[best_index]
                best_y = current_y

            # Adaptive step size based on distance to best solution
            step_size_factor = 0.995 ** (np.linalg.norm(candidates - best_x) / np.linalg.norm(best_x))
            step_size = 0.1 * step_size_factor

            # Adjust candidates using the adaptive step size
            candidates += np.random.normal(0, step_size, (pop_size, dim))

            # Local search to refine solutions using Nelder-Mead simplex method
            from scipy.optimize import minimize
            result = minimize(lambda x: float(problem(x)), best_x, method='Nelder-Mead', bounds=[lb, ub])
            best_x = result.x
            best_y = result.fun

        return best_x, float(best_y)