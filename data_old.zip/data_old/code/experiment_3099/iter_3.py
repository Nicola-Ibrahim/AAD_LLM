import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor, RBF

class GaussianProcessOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1
        
        # Initialize the Gaussian Process model
        kernel = RBF(length_scale=np.ones(dim))
        gp = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=9)
        
        # Perform Bayesian optimization
        while evaluations < budget:
            # Sample a new point from the GP posterior distribution
            mu, sigma = gp.predict(np.random.uniform(lb, ub, size=(10, dim)), return_std=True)
            x_new = lb + np.clip(mu, 0, 1) * (ub - lb)
            
            # Evaluate the new point
            y_new = float(problem(x_new))
            
            # Update the Gaussian Process model with the new data
            gp.fit(np.vstack([best_x]), [best_y])
            if y_new < best_y:
                best_x = x_new
                best_y = y_new
                evaluations += 1
        
        return best_x, float(best_y)