import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 100
        self.F = 0.8
        self.CR = 0.7
        self.adaptive_factor = 1.2
        self.max_success_rate = 0.5
        self.min_success_rate = 0.3
        self.re_evaluations = 20  # Increase re-evaluations to reduce noise impact

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evaluations = self.pop_size * self.re_evaluations

        # Evaluate initial population with re-evaluations
        fitness = np.array([np.mean([problem(ind) for _ in range(self.re_evaluations)]) for ind in pop])

        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = fitness[best_idx]

        success_rate = 0.0
        trials_success_count = 0

        while evaluations < budget * 0.8:  # Reserve 20% of the budget for local search
            # Generate random indices for mutation
            r1 = np.random.randint(0, self.pop_size, size=(self.pop_size,))
            r2 = np.random.randint(0, self.pop_size, size=(self.pop_size,))
            r3 = np.random.randint(0, self.pop_size, size=(self.pop_size,))
            mask = (r1 != np.arange(self.pop_size)) & (r2 != np.arange(self.pop_size)) & (r3 != np.arange(self.pop_size))
            if ~mask.any():
                r1[~mask] = np.random.randint(0, self.pop_size, size=~mask.sum())
                r2[~mask] = np.random.randint(0, self.pop_size, size=~mask.sum())
                r3[~mask] = np.random.randint(0, self.pop_size, size=~mask.sum())

            # Mutation
            mutants = pop[r1] + self.F * (pop[r2] - pop[r3])

            # Crossover
            mask = np.random.rand(self.pop_size, dim) < self.CR
            trials = np.where(mask, mutants, pop)

            # Ensure candidates are within bounds
            trials = np.clip(trials, lb, ub)

            # Evaluate trial vectors with re-evaluations
            trial_fitness = np.array([np.mean([problem(ind) for _ in range(self.re_evaluations)]) for ind in trials])
            evaluations += self.pop_size * self.re_evaluations

            # Selection
            success_mask = trial_fitness < fitness
            trials_success_count += success_mask.sum()
            pop[success_mask] = trials[success_mask]
            fitness[success_mask] = trial_fitness[success_mask]

            # Update best solution found so far
            new_best_idx = np.argmin(fitness)
            if fitness[new_best_idx] < best_y:
                best_x = pop[new_best_idx]
                best_y = fitness[new_best_idx]

            # Adaptive F and CR adjustment based on success rate
            if evaluations % self.pop_size == 0:
                success_rate = trials_success_count / self.pop_size
                if success_rate > self.max_success_rate:
                    self.F /= self.adaptive_factor
                    self.CR *= self.adaptive_factor
                elif success_rate < self.min_success_rate:
                    self.F *= self.adaptive_factor
                    self.CR /= self.adaptive_factor
                trials_success_count = 0

        # Local search around the best solution using remaining budget
        while evaluations < budget:
            local_pop = best_x + np.random.normal(0, 0.1, size=(self.pop_size, dim))
            local_pop = np.clip(local_pop, lb, ub)
            local_fitness = np.array([np.mean([problem(ind) for _ in range(self.re_evaluations)]) for ind in local_pop])
            evaluations += self.pop_size * self.re_evaluations

            # Selection
            success_mask = local_fitness < fitness
            pop[success_mask] = local_pop[success_mask]
            fitness[success_mask] = local_fitness[success_mask]

            # Update best solution found so far
            new_best_idx = np.argmin(fitness)
            if fitness[new_best_idx] < best_y:
                best_x = pop[new_best_idx]
                best_y = fitness[new_best_idx]

        return best_x, float(best_y)