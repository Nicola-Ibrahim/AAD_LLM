import numpy as np

class CMAEsNoiseResilient:
    def __init__(self):
        pass  # Initialization can be added here if needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialization of parameters
        sigma = (ub - lb) / 6.0
        mu = dim / 2.0
        weights = np.log(mu + 0.5) - np.log(np.arange(1, mu+1))
        weights /= np.sum(weights)
        mueff = np.sum(weights)**2 / np.sum(weights**2)

        # Initialize the population and covariance matrix
        pop_size = int(4 + np.floor(3 * np.log(dim)))
        pop = lb + (ub - lb) * np.random.rand(pop_size, dim)
        B = np.eye(dim)
        D = sigma * np.ones(dim)
        C = D ** 2 * B.T @ B

        # Initialize best solution
        evaluations = 0
        best_x = pop[0]
        best_y = float(problem(best_x))
        evaluations += 1

        k = min(4, int(0.2 * budget))  # Maximum re-evaluation per candidate

        while evaluations < budget:
            # Generate new candidates with covariance matrix adaptation
            z = np.random.randn(pop_size, dim)
            x = pop + np.dot(C**0.5, z.T).T
            x = np.clip(x, lb, ub)

            # Evaluate candidates using re-evaluation strategy
            y = np.array([np.mean([problem(candidate) for _ in range(k)]) for candidate in x])
            evaluations += k * pop_size

            # Update population and covariance matrix based on fitness values
            diff = (x - best_x)
            outer_prod = np.sum(diff.T * diff, axis=1)
            D = np.sqrt((outer_prod / (mu * mueff)) * weights + np.finfo(float).eps)
            C = np.dot(D**-2, B.T @ np.diag(weights) @ B)

            # Update best solution
            mask = y < best_y
            best_x[mask] = x[mask]
            best_y[mask] = y[mask]

        return best_x, float(best_y)