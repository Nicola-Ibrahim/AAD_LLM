import numpy as np

class SimulatedAnnealing:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 50
        k = 2  # Number of re-evaluations per candidate

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size * k

        # Evaluate initial population
        fitness = np.array([_robust_eval(problem, x, k) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        temperature = 100.0  # Initial temperature
        cooling_rate = 0.95  # Cooling rate

        while evaluations < budget:
            for _ in range(pop_size):
                # Mutation
                mutation_rate = 0.2
                mutated_x = pop[np.random.randint(pop_size), :] + np.random.normal(0, mutation_rate, size=dim)
                mutated_x = np.clip(mutated_x, lb, ub)

                # Evaluate mutated candidate
                mutated_fitness = _robust_eval(problem, mutated_x, k)

                # Calculate acceptance probability
                if mutated_fitness < fitness[best_idx]:
                    best_x = mutated_x.copy()
                    best_y = float(problem(best_x))
                    fitness[best_idx] = mutated_fitness
                else:
                    acceptance_prob = np.exp(-(mutated_fitness - fitness[best_idx]) / temperature)
                    if np.random.rand() < acceptance_prob:
                        pop[np.random.randint(pop_size), :] = mutated_x.copy()
                        fitness[np.random.randint(pop_size)] = mutated_fitness

            # Cool down the temperature
            temperature *= cooling_rate
            evaluations += pop_size * k

        return best_x, float(best_y)

def _robust_eval(problem, x, k):
    return float(np.mean([problem(x) for _ in range(k)]))