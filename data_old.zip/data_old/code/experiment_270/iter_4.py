import numpy as np

class RobustOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 50
        k = 2  # Number of re-evaluations per candidate

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size * k

        # Evaluate initial population
        fitness = np.array([_robust_eval(problem, x, k) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        while evaluations < budget:
            # Mutation
            mutation_rate = 0.2
            mutations = np.random.normal(0, mutation_rate, size=(pop_size, dim))
            mutated_pop = np.clip(pop + mutations, lb, ub)

            # Evaluate mutated population
            mutated_fitness = np.array([_robust_eval(problem, x, k) for x in mutated_pop])
            mutated_best_idx = np.argmin(mutated_fitness)
            if mutated_fitness[mutated_best_idx] < fitness[best_idx]:
                best_x = mutated_pop[mutated_best_idx]
                best_y = float(problem(best_x))
                fitness[best_idx] = mutated_fitness[mutated_best_idx]

            # Update population
            pop = np.where(mutated_fitness[:, np.newaxis] < fitness, mutated_pop, pop)
            evaluations += pop_size * k

        return best_x, float(best_y)

def _robust_eval(problem, x, k):
    return float(np.mean([problem(x) for _ in range(k)]))