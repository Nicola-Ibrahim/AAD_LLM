import numpy as np

class CMAEvolutionStrategy:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10
        k = 2  # Number of re-evaluations per candidate

        # Initialize population and covariance matrix
        mean = np.random.uniform(lb, ub)
        sigma = (ub - lb) / 4.0
        C = np.eye(dim) * sigma ** 2
        pop = np.random.multivariate_normal(mean, C, size=pop_size)

        evaluations = pop_size * k

        while evaluations < budget:
            # Evaluate population
            fitness = np.array([_robust_eval(problem, x, k) for x in pop])
            best_idx = np.argmin(fitness)
            best_x = pop[best_idx]
            best_y = float(problem(best_x))

            # Update covariance matrix
            D = np.diag(C)
            invD = 1.0 / D
            mu = 2 * np.sum(np.exp(-0.5 * invD * (pop - mean) @ np.linalg.inv(C) @ (pop - mean).T)) / pop_size
            w = np.exp(-0.5 * invD * (pop - mean) @ np.linalg.inv(C) @ (pop - mean).T) / mu
            w_sum = np.sum(w)
            C = (1 - 1.0 / pop_size + 2.0 * np.sum(w ** 2)) * C / w_sum
            C += np.diag(2.0 / pop_size * w * np.diag(C)) @ np.diag(w) @ np.diag(2.0 / pop_size * w * np.diag(C))

            # Update mean and sigma
            mean = (np.sum(w[:, None] * pop, axis=0) + 1e-9) / w_sum
            sigma *= np.sqrt((w_sum - 1.0) * dim / mu)

            evaluations += pop_size * k

        return best_x, float(best_y)

def _robust_eval(problem, x, k):
    return float(np.mean([problem(x) for _ in range(k)]))