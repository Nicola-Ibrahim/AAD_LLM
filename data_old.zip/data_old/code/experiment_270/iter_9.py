import numpy as np

class SimulatedAnnealingEnhanced:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 50
        k = 2  # Number of re-evaluations per candidate

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size * k

        # Evaluate initial population
        fitness = np.array([_robust_eval(problem, x, k) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        temperature = 100.0  # Initial temperature
        cooling_rate = 0.995  # Faster cooling rate

        while evaluations < budget:
            for _ in range(pop_size):
                # Multi-point mutation with dynamic mutation rate
                num_mutations = max(1, int(np.random.normal(2, 1)))
                mutated_x = best_x.copy()
                for _ in range(num_mutations):
                    idx = np.random.randint(dim)
                    mutation_rate = max(0.1, min(0.5, best_y / (np.std(fitness) + 1e-8)))  # Adjusted mutation rate
                    mutated_x[idx] += np.random.normal(0, mutation_rate)
                    mutated_x[idx] = max(lb[idx], min(mutated_x[idx], ub[idx]))

                # Evaluate mutated candidate
                mutated_fitness = _robust_eval(problem, mutated_x, k)

                # Calculate acceptance probability using Metropolis-Hastings ratio
                if mutated_fitness < best_y:
                    accept_prob = np.exp((best_y - mutated_fitness) / temperature)
                else:
                    accept_prob = np.exp((mutated_fitness - best_y) / temperature)

                if np.random.rand() < accept_prob:
                    pop[np.random.randint(pop_size), :] = mutated_x.copy()
                    fitness[np.random.randint(pop_size)] = mutated_fitness
                    if mutated_fitness < best_y:  # Update best solution only if better
                        best_idx = np.argmin(fitness)
                        best_x = pop[best_idx]
                        best_y = float(problem(best_x))

            # Cool down the temperature
            temperature *= cooling_rate
            evaluations += pop_size * k

        return best_x, float(best_y)

def _robust_eval(problem, x, k):
    return float(np.mean([problem(x) for _ in range(k)]))