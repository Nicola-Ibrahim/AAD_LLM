import numpy as np

class EnhancedSimulatedAnnealing:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 50
        k = 2  # Number of re-evaluations per candidate

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size * k

        # Evaluate initial population
        fitness = np.array([_robust_eval(problem, x, k) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        temperature = 100.0  # Initial temperature
        cooling_rate = 0.995  # Faster cooling rate

        restart_threshold = 1000  # Number of evaluations before a restart
        no_improvement_count = 0

        while evaluations < budget:
            for _ in range(pop_size):
                # Multi-point mutation
                num_mutations = max(1, int(np.random.normal(2, 1)))
                mutated_x = best_x.copy()
                for _ in range(num_mutations):
                    idx = np.random.randint(dim)
                    mutation_rate = 0.4 * (np.exp((best_y - fitness[best_idx]) / temperature) + 1)  # Dynamic mutation rate
                    mutated_x[idx] += np.random.normal(0, mutation_rate)
                    mutated_x[idx] = max(lb[idx], min(mutated_x[idx], ub[idx]))

                # Evaluate mutated candidate
                mutated_fitness = _robust_eval(problem, mutated_x, k)

                # Calculate acceptance probability
                if mutated_fitness < fitness[best_idx]:
                    best_x = mutated_x.copy()
                    best_y = float(problem(best_x))
                    fitness[best_idx] = mutated_fitness
                    no_improvement_count = 0
                else:
                    acceptance_prob = np.exp(-(mutated_fitness - fitness[best_idx]) / temperature)
                    if np.random.rand() < acceptance_prob:
                        pop[np.random.randint(pop_size), :] = mutated_x.copy()
                        fitness[np.random.randint(pop_size)] = mutated_fitness
                        no_improvement_count = 0

            # Cool down the temperature
            temperature *= cooling_rate
            evaluations += pop_size * k

            # Check for restart criteria
            if evaluations % restart_threshold == 0 and no_improvement_count > 10:
                best_x, best_y = self._restart(pop, fitness, lb, ub, problem, budget - evaluations)

        return best_x, float(best_y)

    def _robust_eval(self, problem, x, k):
        return float(np.mean([problem(x) for _ in range(k)]))

    def _restart(self, pop, fitness, lb, ub, problem, remaining_budget):
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        pop_size = 50
        k = 2  # Number of re-evaluations per candidate

        # Initialize population with a focus around the current best solution
        new_pop = np.random.normal(best_x, 0.1 * (ub - lb), size=(pop_size, len(lb)))
        new_pop = np.clip(new_pop, lb, ub)

        # Evaluate initial new population
        new_fitness = np.array([_robust_eval(problem, x, k) for x in new_pop])
        new_best_idx = np.argmin(new_fitness)
        new_best_x = new_pop[new_best_idx]
        new_best_y = float(problem(new_best_x))

        # Update the best solution if the restart improves it
        if new_best_y < best_y:
            return new_best_x, new_best_y

        return best_x, best_y