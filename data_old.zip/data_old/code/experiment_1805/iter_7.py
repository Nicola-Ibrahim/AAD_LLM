import numpy as np

class EnhancedHybridExplorer:
    def __init__(self):
        self.pop_size = 50
        self.crossover_rate = 0.7
        self.initial_temperature = 100.0
        self.cooling_rate = 0.99
        self.max_local_search_steps = 20
        self.local_search_step_size = 0.1

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(individual)) for individual in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        temperature = self.initial_temperature

        while evaluations < budget:
            new_population = []
            diversity = np.mean(np.std(population, axis=0))
            mutation_factor = self.initial_temperature / (self.initial_temperature + diversity)

            for i in range(self.pop_size):
                # Select three distinct individuals
                indices = [idx for idx in range(self.pop_size) if idx != i]
                np.random.shuffle(indices)
                a, b, c = population[indices[:3]]

                # Mutation with adaptive factor
                mutant = a + mutation_factor * (b - c)

                # Crossover
                crossover_mask = np.random.rand(dim) < self.crossover_rate
                trial_vector = np.where(crossover_mask, mutant, population[i])

                # Ensure the trial vector is within bounds
                trial_vector = np.clip(trial_vector, lb, ub)
                
                # Evaluate the new candidate
                trial_fitness = float(problem(trial_vector))
                evaluations += 1

                # Simulated Annealing acceptance criterion with clamping to avoid underflow
                exp_term = (fitness[i] - trial_fitness) / temperature
                if exp_term < -709:  # Clamp to prevent overflow in exp
                    exp_term = -709
                accept_prob = np.exp(exp_term)
                
                if (trial_fitness < fitness[i]) or (np.random.rand() < accept_prob):
                    new_population.append(trial_vector)
                    if trial_fitness < best_y:
                        best_x = trial_vector
                        best_y = trial_fitness
                else:
                    new_population.append(population[i])

            population = np.array(new_population)

            # Local search on the current best solution
            for _ in range(self.max_local_search_steps):
                perturbation = np.random.uniform(-self.local_search_step_size, self.local_search_step_size, dim)
                local_candidate = np.clip(best_x + perturbation, lb, ub)
                local_fitness = float(problem(local_candidate))
                evaluations += 1

                if local_fitness < best_y:
                    best_x = local_candidate
                    best_y = local_fitness

            # Cool down the temperature
            temperature *= self.cooling_rate

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)