import numpy as np

class ImprovedHybridExplorer:
    def __init__(self):
        self.initial_pop_size = 50
        self.crossover_rate = 0.7
        self.initial_mutation_factor = 0.8
        self.mutation_factor_decay = 0.999
        self.initial_temperature = 100.0
        self.cooling_rate = 0.995

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = self.initial_pop_size
        mutation_factor = self.initial_mutation_factor
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(individual)) for individual in population])
        evaluations = pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        temperature = self.initial_temperature

        while evaluations < budget:
            new_population = []
            for i in range(pop_size):
                # Select three distinct individuals
                indices = [idx for idx in range(pop_size) if idx != i]
                np.random.shuffle(indices)
                a, b, c = population[indices[:3]]

                # Mutation with adaptive factor
                mutant = a + mutation_factor * (b - c)

                # Crossover using Binomial crossover
                crossover_mask = np.random.rand(dim) < self.crossover_rate
                trial_vector = np.where(crossover_mask, mutant, population[i])

                # Ensure the trial vector is within bounds
                trial_vector = np.clip(trial_vector, lb, ub)
                
                # Evaluate the new candidate
                trial_fitness = float(problem(trial_vector))
                evaluations += 1

                # Simulated Annealing acceptance criterion using Metropolis-Hastings
                if (trial_fitness < fitness[i]) or (np.random.rand() < np.exp(-max(0, (trial_fitness - fitness[i])) / temperature)):
                    new_population.append(trial_vector)
                    if trial_fitness < best_y:
                        best_x = trial_vector
                        best_y = trial_fitness
                else:
                    new_population.append(population[i])

            population = np.array(new_population)
            fitness = np.array([float(problem(individual)) for individual in population])
            evaluations += pop_size

            # Cool down the temperature and decay mutation factor
            temperature *= self.cooling_rate
            mutation_factor *= self.mutation_factor_decay

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)