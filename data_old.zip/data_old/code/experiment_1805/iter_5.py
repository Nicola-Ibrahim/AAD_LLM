import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 100
        self.crossover_rate = 0.7
        self.initial_mutation_factor = 0.8
        self.mutation_factor_decay = 0.9995
        self.initial_temperature = 100.0
        self.cooling_rate = 0.99

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(individual)) for individual in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        mutation_factor = self.initial_mutation_factor
        temperature = self.initial_temperature

        while evaluations < budget:
            new_population = []
            for i in range(self.pop_size):
                # Select three distinct individuals
                indices = [idx for idx in range(self.pop_size) if idx != i]
                np.random.shuffle(indices)
                a, b, c = population[indices[:3]]

                # Mutation with adaptive mutation factor
                mutant = a + mutation_factor * (b - c)

                # Blend crossover
                blend_alpha = np.random.rand(dim)
                trial_vector = blend_alpha * population[i] + (1 - blend_alpha) * mutant

                # Ensure the trial vector is within bounds
                trial_vector = np.clip(trial_vector, lb, ub)
                
                # Evaluate the new candidate
                trial_fitness = float(problem(trial_vector))
                evaluations += 1

                # Simulated Annealing acceptance criterion
                if (trial_fitness < fitness[i]) or (np.random.rand() < np.exp((fitness[i] - trial_fitness) / temperature)):
                    new_population.append(trial_vector)
                    if trial_fitness < best_y:
                        best_x = trial_vector
                        best_y = trial_fitness
                else:
                    new_population.append(population[i])

            population = np.array(new_population)
            fitness = np.array([float(problem(individual)) for individual in population])
            evaluations += self.pop_size

            # Update mutation factor and cool down the temperature
            mutation_factor *= self.mutation_factor_decay
            temperature *= self.cooling_rate

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)