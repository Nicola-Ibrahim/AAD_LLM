import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 100
        self.initial_mutation_factor = 0.5
        self.min_mutation_factor = 0.2
        self.max_mutation_factor = 1.0
        self.crossover_rate = 0.8
        self.initial_temperature = 100.0
        self.cooling_factor = 0.95

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(individual)) for individual in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        temperature = self.initial_temperature
        mutation_factor = self.initial_mutation_factor

        while evaluations < budget:
            new_population = []
            for i in range(self.pop_size):
                # Select three distinct individuals
                indices = [idx for idx in range(self.pop_size) if idx != i]
                np.random.shuffle(indices)
                a, b, c = population[indices[:3]]

                # Mutation with adaptive factor
                mutant = a + mutation_factor * (b - c)

                # Crossover
                crossover_mask = np.random.rand(dim) < self.crossover_rate
                trial_vector = np.where(crossover_mask, mutant, population[i])

                # Ensure the trial vector is within bounds
                trial_vector = np.clip(trial_vector, lb, ub)
                
                # Evaluate the new candidate
                trial_fitness = float(problem(trial_vector))
                evaluations += 1

                # Simulated Annealing acceptance criterion
                if (trial_fitness < fitness[i]) or (np.random.rand() < max(0, np.exp((fitness[i] - trial_fitness) / temperature))):
                    new_population.append(trial_vector)
                    if trial_fitness < best_y:
                        best_x = trial_vector
                        best_y = trial_fitness
                else:
                    new_population.append(population[i])

            population = np.array(new_population)
            fitness = np.array([float(problem(individual)) for individual in population])
            evaluations += self.pop_size

            # Adapt mutation factor based on recent improvements
            if np.min(fitness) < best_y:
                mutation_factor = min(mutation_factor * 1.05, self.max_mutation_factor)
            else:
                mutation_factor = max(mutation_factor * 0.95, self.min_mutation_factor)

            # Cool down the temperature with adaptive factor
            population_diversity = np.mean(np.std(population, axis=0))
            if population_diversity < 1e-3:
                temperature *= self.cooling_factor ** 2
            else:
                temperature *= self.cooling_factor

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)