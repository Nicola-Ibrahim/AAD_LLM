import numpy as np

class EnhancedExplorer:
    def __init__(self):
        self.pop_size = 100
        self.initial_mutation_factor = 0.5
        self.crossover_rate = 0.8
        self.initial_temperature = 100.0
        self.cooling_rate = 0.95
        self.min_cooling_rate = 0.01

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(individual)) for individual in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        temperature = self.initial_temperature
        mutation_factor = self.initial_mutation_factor
        no_improvement_count = 0

        while evaluations < budget:
            new_population = []
            for i in range(self.pop_size):
                # Select three distinct individuals
                indices = [idx for idx in range(self.pop_size) if idx != i]
                np.random.shuffle(indices)
                a, b, c = population[indices[:3]]

                # Mutation with adaptive mutation factor
                mutant = a + mutation_factor * (b - c)

                # Crossover
                crossover_mask = np.random.rand(dim) < self.crossover_rate
                trial_vector = np.where(crossover_mask, mutant, population[i])

                # Ensure the trial vector is within bounds
                trial_vector = np.clip(trial_vector, lb, ub)
                
                # Evaluate the new candidate
                trial_fitness = float(problem(trial_vector))
                evaluations += 1

                # Simulated Annealing acceptance criterion
                if (trial_fitness < fitness[i]) or (np.random.rand() < np.exp((fitness[i] - trial_fitness) / temperature)):
                    new_population.append(trial_vector)
                    if trial_fitness < best_y:
                        best_x = trial_vector
                        best_y = trial_fitness
                        no_improvement_count = 0
                else:
                    new_population.append(population[i])
                    no_improvement_count += 1

            population = np.array(new_population)
            fitness = np.array([float(problem(individual)) for individual in population])
            evaluations += self.pop_size

            # Cool down the temperature dynamically
            if no_improvement_count >= 50:
                no_improvement_count = 0
                mutation_factor *= 0.95
                mutation_factor = max(0.1, mutation_factor)
                cooling_rate = self.cooling_rate ** (no_improvement_count / 50 + 1)
                temperature *= cooling_rate
                temperature = max(self.min_cooling_rate, temperature)

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)