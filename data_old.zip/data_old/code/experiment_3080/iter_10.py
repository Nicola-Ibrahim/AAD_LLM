import numpy as np

class NoisyBBOBP1:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # Running dataset of noisy evaluations for each candidate
        eval_dataset = {}

        while evaluations <= budget:
            # Generate a population of candidates using batch mutation
            candidates = np.clip(best_x + np.random.normal(0, 0.1, size=(len(best_x), dim)), lb, ub)

            # Evaluate each candidate and update the running dataset
            for x in candidates:
                y_new = float(problem(x))
                eval_dataset[tuple(x)] = y_new  # Convert numpy array to tuple
                evaluations += 1

            # Update best_x and best_y using the weighted median of the current set of noisy evaluations at each candidate
            for x, ys in eval_dataset.items():
                if ys:
                    weight_factor = 0.5  # Small weight factor for exploration vs exploitation
                    best_y_candidates = np.array([ys[0] + (y - ys[0]) * weight_factor for y in ys])
                    median_y = np.median(best_y_candidates)
                    if y_new < median_y:
                        best_x = np.array(x)  # Convert tuple back to numpy array
                        best_y = y_new

        return best_x, float(best_y)