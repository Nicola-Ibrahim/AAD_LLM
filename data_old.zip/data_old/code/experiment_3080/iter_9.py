import numpy as np

class NoisyBBOBP1:
    def __init__(self):
        pass  # Initialization state if needed, but not necessary for this implementation

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # Priority queue to store candidates based on their current evaluation value
        candidate_queue = [(best_y, tuple(best_x))]

        while evaluations <= budget:
            # Generate a population of candidates using batch mutation
            candidates = np.clip(best_x + np.random.normal(0, 0.1, size=(len(best_x), dim)), lb, ub)

            # Evaluate each candidate and update the priority queue
            for x in candidates:
                y_new = float(problem(x))
                evaluations += 1
                if (y_new, tuple(x)) not in candidate_queue:
                    heapq.heappush(candidate_queue, (y_new, tuple(x)))

            # Update best_x and best_y with the top of the priority queue
            if candidate_queue:
                best_y, best_x = heapq.heappop(candidate_queue)

        return np.asarray(best_x), float(best_y)