import numpy as np

class NoisyBBOBP1:
    def __init__(self):
        # Initialize parameters
        self.dim = 10
        self.lb = -5.0 * np.ones(self.dim)
        self.ub = 5.0 * np.ones(self.dim)
        self.init_stddev = 0.1
        self.mutation_step_size = 0.1
        self.min_budget = 1000000

    def __call__(self, problem, budget):
        if budget < self.min_budget:
            return None, None  # Not enough budget

        best_x = np.random.uniform(self.lb, self.ub, size=self.dim)
        best_y = float(problem(best_x))
        evaluations = 1
        eval_dataset = {}

        while evaluations <= budget:
            # Generate a population of candidates using batch mutation
            candidates = np.clip(best_x + np.random.normal(0, self.mutation_step_size, size=(len(best_x), self.dim)), self.lb, self.ub)

            # Evaluate each candidate and update the running dataset
            for x in candidates:
                y_new = float(problem(x))
                eval_dataset[tuple(x)] = y_new  # Convert numpy array to tuple
                evaluations += 1

            # Update best_x and best_y using the median of the current set of evaluations at each candidate
            for x, ys in eval_dataset.items():
                if ys:
                    median_y = np.median(ys)
                    if y_new < median_y:
                        best_x = np.array(x)  # Convert tuple back to numpy array
                        best_y = y_new

            # Adjust mutation step size adaptively
            self.adjust_mutation_step_size(eval_dataset)

        return best_x, float(best_y)

    def adjust_mutation_step_size(self, eval_dataset):
        # Use the median of evaluations as a reference point for adjustment
        medians = [np.median(ys) for ys in eval_dataset.values()]
        if len(medians) > 0:
            self.mutation_step_size *= 1.01 - np.mean(np.abs(np.array(medians)))

# Example usage
class Problem:
    def __init__(self, dim):
        self.dim = dim

    def __call__(self, x):
        # Simulate a noisy objective function
        return np.random.normal(x @ x / self.dim, 1)

problem = Problem(10)
optimizer = NoisyBBOBP1()
best_x, best_y = optimizer(problem, 1000000)
print(f"Best solution: {best_x}, Best value: {best_y}")