import numpy as np

class NoiseAveragingOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Initial best solution
        best_idx = np.argmin([_robust_eval(x, 3) for x in pop])
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        # Main optimization loop
        while evaluations < budget:
            # Mutation
            candidates = np.clip(pop + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)
            new_evaluations = evaluations

            # Evaluate candidates in batches
            chunk_size = min(int(budget * 0.2) // pop_size, 1)  # Use at most 20% of the budget for re-evaluation
            chunks = np.array_split(candidates[:pop_size], chunk_size)
            for chunk in chunks:
                results = [_robust_eval(x, 3) for x in chunk]
                new_evaluations += len(results)

            # Update population and best solution
            for i, (x, y) in enumerate(zip(chunk, results)):
                pop[i] = x
                if y < best_y:
                    best_idx = i
                    best_x = x
                    best_y = float(problem(x))

            evaluations = new_evaluations

        return best_x, best_y

# Helper function to robustly evaluate a solution multiple times and return the mean
def _robust_eval(x, k):
    return float(np.mean([problem(x) for _ in range(k)]))