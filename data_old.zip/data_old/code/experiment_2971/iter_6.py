import numpy as np

class NoiseRobustOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        # Initialize history of evaluations
        history = []

        while evaluations < budget:
            # Mutation
            candidates = np.clip(pop + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)

            # Evaluate candidates in batches and store the results
            chunk_size = min(int(budget * 0.2) // pop_size, 1)  # Use at most 20% of the budget for re-evaluation
            chunks = np.array_split(candidates[:pop_size], chunk_size)
            for chunk in chunks:
                results = [np.mean([problem(x) for _ in range(3)]) for x in chunk]
                new_evaluations += len(results)

            # Update history
            history.extend(zip(chunk, results))

            # Select the best candidate based on weighted average fitness
            weights = np.array([result[1] for result in history])
            weights /= np.sum(weights)
            selected_idx = np.random.choice(range(len(history)), p=weights)
            selected_x, selected_y = history[selected_idx]

            # Update population with the selected solution
            pop[selected_idx % pop_size] = selected_x

        # Final evaluation of the best solution found so far
        best_idx = np.argmin([np.mean([problem(x) for _ in range(3)]) for x in pop])
        best_x = pop[best_idx]
        best_y = float(problem(best_x))

        return best_x, best_y