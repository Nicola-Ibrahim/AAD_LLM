import numpy as np

class EnhancedNoiseResilientOptimizer:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # --- YOUR ALGORITHM LOGIC BELOW ---
        pop_size = 50
        num_samples_per_candidate = 10

        while evaluations < budget:
            scores = []
            for x in pop:
                samples = [problem(x) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score = np.median(samples)
                scores.append(score)

            # Find the best candidate based on median score
            best_idx = np.argmin(scores)
            if scores[best_idx] < best_y:
                best_x = pop[best_idx]
                best_y = scores[best_idx]

            # Balance exploration and exploitation
            new_candidates = np.random.uniform(lb, ub, size=(pop_size // 2, dim))
            pop[:pop_size // 2] = new_candidates
            for i in range(pop_size // 2, pop_size):
                x = pop[i]
                samples = [problem(x) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score = np.median(samples)
                if score < scores[i]:
                    pop[i] = x

            # Local search around the best candidate
            local_search_radius = 0.1
            for _ in range(5):  # Perform 5 local searches
                perturbation = np.random.uniform(-local_search_radius, local_search_radius, size=dim)
                candidate = best_x + perturbation
                candidate = np.clip(candidate, lb, ub)  # Ensure within bounds
                samples = [problem(candidate) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score = np.median(samples)
                if score < best_y:
                    best_x = candidate
                    best_y = score

            # Adjust population size and sample count based on progress
            if evaluations < budget * 0.5:
                pop_size = 100
                num_samples_per_candidate = 20
            elif evaluations < budget * 0.8:
                pop_size = 60
                num_samples_per_candidate = 15

        # --- YOUR ALGORITHM LOGIC ABOVE ---

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)