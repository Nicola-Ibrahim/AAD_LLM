import numpy as np

class ImprovedNoiseResilientOptimizer:
    def __init__(self):
        self.learning_rate = 0.75  # Adaptive learning rate for exploration and exploitation

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # --- YOUR ALGORITHM LOGIC BELOW ---
        pop_size = 50
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        num_samples_per_candidate = 10

        while evaluations < budget:
            scores = []
            for x in pop:
                samples = [problem(x) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score = np.median(samples)
                scores.append(score)

            # Find the best candidate based on median score
            best_idx = np.argmin(scores)
            if scores[best_idx] < best_y:
                best_x = pop[best_idx]
                best_y = scores[best_idx]

            # Balance exploration and exploitation using a learning rate
            new_candidates = np.clip(
                best_x + self.learning_rate * (np.random.rand(pop_size, dim) - 0.5),
                lb, ub
            )
            for i in range(pop_size):
                x = new_candidates[i]
                samples = [problem(x) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score = np.median(samples)
                if score < scores[i]:
                    pop[i] = x

        # --- YOUR ALGORITHM LOGIC ABOVE ---

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)