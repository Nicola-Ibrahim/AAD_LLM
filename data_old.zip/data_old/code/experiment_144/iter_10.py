import numpy as np

class ImprovedNoiseResilientOptimizer:
    def __init__(self):
        pass  # No specific initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Start with a random initial point
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        pop_size = 50
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))

        while evaluations < budget:
            scores = []
            for x in pop:
                # Use trimmed mean to reduce the impact of outliers due to noise
                samples = [problem(x) for _ in range(15)]
                evaluations += 15
                score = np.mean(np.sort(samples)[3:-3])  # Trimmed mean: remove top and bottom 20%
                scores.append(score)

            # Find the best candidate based on trimmed mean score
            best_idx = np.argmin(scores)
            if scores[best_idx] < best_y:
                best_x = pop[best_idx]
                best_y = scores[best_idx]

            # Calculate mutation rate based on population diversity
            std_devs = np.std(pop, axis=0)
            mutation_rate = 0.5 * (1 - evaluations / budget) + 0.2 + np.mean(std_devs) / 10

            new_candidates = np.clip(
                best_x + mutation_rate * (np.random.rand(pop_size, dim) - 0.5),
                lb, ub
            )
            for i in range(pop_size):
                x = new_candidates[i]
                samples = [problem(x) for _ in range(15)]
                evaluations += 15
                score = np.mean(np.sort(samples)[3:-3])  # Trimmed mean: remove top and bottom 20%
                if score < scores[i]:
                    pop[i] = x

        return best_x, float(best_y)