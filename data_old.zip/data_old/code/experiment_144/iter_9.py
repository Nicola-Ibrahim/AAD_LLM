import numpy as np

class ImprovedNoiseResilientOptimizer:
    def __init__(self):
        pass  # No specific initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Start with a random initial point
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        pop_size = 50
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))

        while evaluations < budget:
            scores = []
            for x in pop:
                # Use trimmed mean to reduce the impact of outliers due to noise
                samples = [problem(x) for _ in range(20)]
                evaluations += 20
                score = np.mean(np.sort(samples)[4:-4])  # Trimmed mean: remove top and bottom 25%
                scores.append(score)

            # Find the best candidate based on trimmed mean score
            best_idx = np.argmin(scores)
            if scores[best_idx] < best_y:
                best_x = pop[best_idx]
                best_y = scores[best_idx]

            # Balance exploration and exploitation using a dynamic learning rate
            learning_rate = 0.8 * (1 - evaluations / budget) + 0.2  # Decrease exploration as we approach the end of budget
            new_candidates = np.clip(
                best_x + learning_rate * (np.random.rand(pop_size, dim) - 0.5),
                lb, ub
            )
            for i in range(pop_size):
                x = new_candidates[i]
                samples = [problem(x) for _ in range(20)]
                evaluations += 20
                score = np.mean(np.sort(samples)[4:-4])  # Trimmed mean: remove top and bottom 25%
                if score < scores[i]:
                    pop[i] = x

            # Periodically refresh the population to maintain diversity
            if evaluations % (budget // 10) == 0:
                new_random_points = np.random.uniform(lb, ub, size=(pop_size, dim))
                for i in range(pop_size):
                    samples = [problem(new_random_points[i]) for _ in range(20)]
                    evaluations += 20
                    score = np.mean(np.sort(samples)[4:-4])
                    if score < scores[i]:
                        pop[i] = new_random_points[i]

        return best_x, float(best_y)