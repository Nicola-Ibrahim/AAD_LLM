import numpy as np

class EnhancedNoiseResilientOptimizer:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # --- YOUR ALGORITHM LOGIC BELOW ---
        pop_size = 50
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        num_samples_per_candidate = 20

        while evaluations < budget:
            scores = []
            for x in pop:
                samples = [problem(x) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score_mean = np.mean(samples)
                score_std = np.std(samples, ddof=1)
                confidence_interval = (score_mean - 2 * score_std / np.sqrt(num_samples_per_candidate), 
 score_mean + 2 * score_std / np.sqrt(num_samples_per_candidate))
                scores.append((score_mean, confidence_interval))

            # Find the best candidate based on mean score and confidence interval
            best_idx = np.argmin([score[0] for score in scores])
            if scores[best_idx][1][0] < best_y:
                best_x = pop[best_idx]
                best_y = scores[best_idx][1][0]

            # Balance exploration and exploitation
            new_candidates = np.random.uniform(lb, ub, size=(pop_size // 2, dim))
            pop[:pop_size // 2] = new_candidates
            for i in range(pop_size // 2, pop_size):
                x = pop[i]
                samples = [problem(x) for _ in range(num_samples_per_candidate)]
                evaluations += num_samples_per_candidate
                score_mean = np.mean(samples)
                score_std = np.std(samples, ddof=1)
                confidence_interval = (score_mean - 2 * score_std / np.sqrt(num_samples_per_candidate), 
 score_mean + 2 * score_std / np.sqrt(num_samples_per_candidate))
                if confidence_interval[0] < scores[i][0]:
                    pop[i] = x

        # --- YOUR ALGORITHM LOGIC ABOVE ---

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)