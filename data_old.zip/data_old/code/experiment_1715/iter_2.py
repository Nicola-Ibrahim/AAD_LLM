import numpy as np

class MyOptimizer:
    def __init__(self):
        self.pop_size = 100
        self.F = 0.5  # Differential weight
        self.CR = 0.7  # Crossover rate
        self.w = 0.5   # Inertia weight for PSO

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        candidates = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        velocities = np.zeros_like(candidates)
        evaluations = 0

        # Evaluate initial population
        fitnesses = np.array([problem(x) for x in candidates])
        best_idx = np.argmin(fitnesses)
        best_x = candidates[best_idx]
        best_y = float(fitnesses[best_idx])
        evaluations += self.pop_size

        while evaluations < budget:
            # Differential Evolution Mutation
            a, b, c = self.select_parents(candidates, best_idx)
            trial_vectors_de = candidates[a] + self.F * (candidates[b] - candidates[c])
            trial_vectors_de = np.clip(trial_vectors_de, lb, ub)

            # PSO Velocity Update
            r1, r2 = np.random.rand(self.pop_size, dim), np.random.rand(self.pop_size, dim)
            velocities = self.w * velocities + \
                         self.CR * r1 * (best_x - candidates) + \
                         self.CR * r2 * (candidates[a] - candidates)

            # Update candidate positions with PSO
            trial_vectors_pso = candidates + velocities
            trial_vectors_pso = np.clip(trial_vectors_pso, lb, ub)

            # Evaluate new candidates from DE and PSO
            fitnesses_de = np.array([problem(x) for x in trial_vectors_de])
            evaluations += len(fitnesses_de)
            fitnesses_pso = np.array([problem(x) for x in trial_vectors_pso])
            evaluations += len(fitnesses_pso)

            # Select the best candidates from current, DE, and PSO
            combined_candidates = np.vstack((candidates, trial_vectors_de, trial_vectors_pso))
            combined_fitnesses = np.hstack((fitnesses, fitnesses_de, fitnesses_pso))

            sorted_indices = np.argsort(combined_fitnesses)[:self.pop_size]
            candidates = combined_candidates[sorted_indices]
            fitnesses = combined_fitnesses[sorted_indices]

            # Update best solution found so far
            current_best_idx = np.argmin(fitnesses)
            if fitnesses[current_best_idx] < best_y:
                best_x = candidates[current_best_idx]
                best_y = float(fitnesses[current_best_idx])

        return best_x, best_y

    def select_parents(self, population, exclude_index):
        indices = list(range(population.shape[0]))
        indices.remove(exclude_index)
        a, b, c = np.random.choice(indices, 3, replace=False)
        return a, b, c