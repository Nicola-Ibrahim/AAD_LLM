import numpy as np

class CMAES:
    def __init__(self):
        self.mu = 20  # Number of offspring individuals (population size)
        self.lambda_ = 100  # Number of new individuals per generation
        self.sigma = 0.5  # Step size for the mutation distribution
        self.weights = np.full(self.mu, 1 / self.mu)  # Weighting coefficients for covariance matrix update
        self.learning_rates = (0.3, 0.3)  # Learning rates for step-size adaptation
        self.dampening = 1 + 2 * np.max([0, np.sqrt((self.lambda_ - 1) / self.mu) - 1])  # Dampening factor
        
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize population (mu + lambda) individuals randomly within bounds
        population = np.random.uniform(lb, ub, size=(self.lambda_, dim))
        fitness = np.zeros(self.lambda_)
        best_x = population[np.argmin(fitness)]  # Best solution found so far (in this case, the one with lowest fitness)
        evaluations = self.lambda_
        
        while evaluations < budget:
            offspring = []
            for _ in range(self.mu):
                # Generate new individuals (offspring) via mutation
                z = np.random.normal(0, 1, size=(self.lambda_, dim))
                sigma_p = self.sigma * np.diag(np.cov(z.T)) ** 0.5
                
                # Vectorized addition of population and scaled noise
                offspring += list((population + sigma_p[:, None] * z).tolist())
            
            # Evaluate the fitness of each new individual
            fitness_offspring = np.array([problem(x) for x in offspring])
            evaluations += self.lambda_
            
            # Select mu best individuals as parents for the next generation
            idx = np.argsort(fitness_offspring)[:self.mu]
            population[:] = offspring[idx]
            fitness[:] = fitness_offspring[idx]
            
            # Update the mean (best found so far)
            best_x = population[np.argmin(fitness)]
            
            # Adapt step size and learning rates based on evolution path statistics
            hsig = np.linalg.norm(self.learning_rate * self.weights @ (population - best_x)) / np.sqrt(1 - (1 - self.dampening) ** (2 * evaluations / self.lambda_))
            self.sigma *= np.exp(self.learning_rates[0] * hsig)
            
        return best_x, float(np.min(fitness))  # Return the best solution found and its fitness value