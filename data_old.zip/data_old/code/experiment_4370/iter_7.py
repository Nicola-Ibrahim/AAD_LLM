import numpy as np

class CMAESOptimizer:
    def __init__(self):
        self.mu = 20  # Number of offspring individuals (population size)
        self.lambda_ = 100  # Number of new individuals per generation
        self.sigma = 0.5  # Step size for the mutation distribution
        self.weights = np.full(self.mu, 1 / self.mu)  # Weighting coefficients for covariance matrix update
        self.learning_rates = (0.3, 0.3)  # Learning rates for step-size adaptation
        self.dampening = 1 + 2 * np.max([0, np.sqrt((self.lambda_ - 1) / self.mu) - 1])  # Dampening factor
        
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        
        # Initialize population (mu + lambda) individuals randomly within bounds
        population = np.random.uniform(lb, ub, size=(self.lambda_, dim))
        fitness = np.zeros(self.lambda_)
        
        while evaluations < budget:
            offspring = []
            for _ in range(self.mu):
                # Generate new individuals (offspring) via mutation
                z = np.random.normal(0, 1, size=(self.lambda_, dim))
                sigma_p = self.sigma * np.diag(np.cov(z.T)) ** 0.5
                offspring += list(population + sigma_p[:, None] * z)
            
            # Evaluate the fitness of each new individual
            k_evals = int(self.lambda_ / self.mu * budget // self.lambda_)  # Number of evaluations per offspring
            if k_evals > 20:
                k_evals = 20
            fitness_offspring = np.array([np.mean([problem(x) for _ in range(k_evals)]) for x in offspring])
            evaluations += len(fitness_offspring)
            
            # Select mu best individuals as parents for the next generation
            idx = np.argsort(fitness_offspring)[:self.mu]
            population[:] = offspring[idx]
            fitness[:] = fitness_offspring[idx]
            
        return population[np.argmin(fitness)], float(np.min(fitness))  # Return the best solution found and its fitness value