import numpy as np

class EnhancedDiverseEvolutionV4:
    def __init__(self):
        self.pop_size = 100  # Increased population size for better diversity
        self.mutation_rate_start = 0.5  # Higher initial mutation rate for exploration
        self.crossover_rate_start = 0.9  # Higher initial crossover rate to maintain diversity
        self.local_search_iterations = 30  # More iterations for local search

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population randomly
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(x)) for x in population])
        evaluations = self.pop_size

        best_idx = np.argmin(fitness)
        best_x = population[best_idx].copy()
        best_y = fitness[best_idx]

        # Adaptive mutation rate
        mutation_rate = self.mutation_rate_start
        mutation_decay = (self.mutation_rate_start - 0.05) / budget  # Faster decay rate

        # Adaptive crossover rate
        crossover_rate = self.crossover_rate_start

        while evaluations < budget:
            # Selection based on crowding distance and fitness
            distances = self.calculate_crowding_distance(population, fitness)
            selected_indices = np.argsort(fitness + distances)[:self.pop_size // 2]
            selected_parents = population[selected_indices]

            # Mutation
            mutation_mask = np.random.rand(*selected_parents.shape) < mutation_rate
            mutated_population = selected_parents + mutation_mask * np.clip(
                np.random.normal(0, 1.5, size=selected_parents.shape), -1, 1)
            mutated_population = np.clip(mutated_population, lb, ub)

            # Crossover
            crossover_idx = np.random.rand(*mutated_population.shape) < crossover_rate
            offsprings = np.where(crossover_idx, mutated_population[:, None], selected_parents[None, :]).reshape(-1, dim)
            offsprings_fitness = np.array([float(problem(x)) for x in offsprings])
            evaluations += len(offsprings)

            # Elitism: keep the best individual
            elite_x, elite_y = best_x, best_y

            # Update population and fitness
            combined_population = np.vstack((mutated_population, offsprings))
            combined_fitness = np.concatenate((fitness[selected_indices], offsprings_fitness))

            sorted_indices = np.argsort(combined_fitness)
            population[:self.pop_size] = combined_population[sorted_indices][:self.pop_size]
            fitness[:self.pop_size] = combined_fitness[sorted_indices][:self.pop_size]

            # Local Search on the best solution
            step_size = max(0.1 * (budget - evaluations) / budget, 0.05)
            for _ in range(self.local_search_iterations):
                if evaluations >= budget:
                    break
                neighbors = np.array([best_x + i * step_size * np.random.randn(dim) for i in [-2, -1, 1, 2]])
                neighbors_fitness = np.array([float(problem(x)) for x in neighbors])
                evaluations += len(neighbors)
                for i, y in enumerate(neighbors_fitness):
                    if y < best_y:
                        best_x = neighbors[i]
                        best_y = y

            # Restore elitism
            population[0], fitness[0] = elite_x, elite_y

            # Adaptive mutation rate decay
            mutation_rate = max(self.mutation_rate_start - (evaluations * mutation_decay), 0.05)

            # Adaptive crossover rate adjustment based on diversity
            if np.std(population) < 0.1:
                crossover_rate = min(crossover_rate + 0.1, 1.0)
            else:
                crossover_rate = max(crossover_rate - 0.1, 0.3)

        return best_x, float(best_y)

    def calculate_crowding_distance(self, population, fitness):
        sorted_indices = np.argsort(fitness)
        sorted_population = population[sorted_indices]
        distances = np.zeros(len(sorted_population))
        for d in range(population.shape[1]):
            min_d = np.min(sorted_population[:, d])
            max_d = np.max(sorted_population[:, d])
            if max_d == min_d:
                continue
            distances += (sorted_population[1:, d] - sorted_population[:-1, d]) / (max_d - min_d)
        return distances