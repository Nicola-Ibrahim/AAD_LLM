import numpy as np

class AdaptiveDiverseEvolution:
    def __init__(self):
        self.pop_size = 50  # Population size
        self.mutation_rate_start = 0.1  # Initial mutation rate
        self.crossover_rate_start = 0.7  # Initial crossover rate
        self.tournament_size = 3  # Tournament size for selection

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population randomly
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(x)) for x in population])
        evaluations = self.pop_size

        best_idx = np.argmin(fitness)
        best_x = population[best_idx].copy()
        best_y = fitness[best_idx]

        # Adaptive mutation and crossover rates
        mutation_rate = self.mutation_rate_start
        crossover_rate = self.crossover_rate_start
        mutation_decay = (self.mutation_rate_start - 0.01) / budget
        crossover_decay = (self.crossover_rate_start - 0.5) / budget

        while evaluations < budget:
            # Selection using tournament selection
            parents_idx = []
            for _ in range(self.pop_size):
                tournament_indices = np.random.choice(self.pop_size, self.tournament_size, replace=False)
                best_in_tournament = tournament_indices[np.argmin(fitness[tournament_indices])]
                parents_idx.append(best_in_tournament)
            selected_parents = population[parents_idx]

            # Mutation
            mutation_mask = np.random.rand(*selected_parents.shape) < mutation_rate
            mutated_population = selected_parents + mutation_mask * np.clip(
                np.random.normal(0, 0.1, size=selected_parents.shape), -1, 1)
            mutated_population = np.clip(mutated_population, lb, ub)

            # Crossover
            crossover_idx = np.random.rand(*mutated_population.shape) < crossover_rate
            offsprings = np.where(crossover_idx, mutated_population[:, None], selected_parents[None, :]).reshape(-1, dim)
            offsprings_fitness = np.array([float(problem(x)) for x in offsprings])
            evaluations += len(offsprings)

            # Update population and fitness
            combined_population = np.vstack((mutated_population, offsprings))
            combined_fitness = np.concatenate((fitness[parents_idx], offsprings_fitness))

            sorted_indices = np.argsort(combined_fitness)
            population[:self.pop_size] = combined_population[sorted_indices][:self.pop_size]
            fitness[:self.pop_size] = combined_fitness[sorted_indices][:self.pop_size]

            # Local Search on the best solution
            step_size = 0.1
            for _ in range(5):
                if evaluations >= budget:
                    break
                neighbors = np.array([best_x + i * step_size * np.random.randn(dim) for i in [-1, 1]])
                neighbors_fitness = np.array([float(problem(x)) for x in neighbors])
                evaluations += len(neighbors)
                for i, y in enumerate(neighbors_fitness):
                    if y < best_y:
                        best_x = neighbors[i]
                        best_y = y

            # Adaptive mutation and crossover rate decay
            mutation_rate = max(self.mutation_rate_start - (evaluations * mutation_decay), 0.01)
            crossover_rate = max(self.crossover_rate_start - (evaluations * crossover_decay), 0.5)

        return best_x, float(best_y)