import numpy as np

class BBOB11Optimizer:
    def __init__(self):
        pass  # No additional initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        pop_size = 10  # Number of candidates in the population
        k = int(0.2 * budget / (pop_size * dim))  # Re-evaluation strategy: at most 20% of budget for each candidate
        if k < 1:
            k = 1

        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        best_x = pop[np.argmin(np.apply_along_axis(lambda x: _robust_eval(x, k), 1, pop))]
        best_y = float(problem(best_x))

        # Initialize the covariance matrix for CMA-ES
        sigma_init = 0.5 * (ub - lb)
        cma_init = np.eye(dim)
        cmu = dim / ((dim + 1) * (2 * dim + 1))

        evaluations = 1 + pop_size

        while evaluations < budget:
            # Generate new candidates using CMA-ES
            mu = pop.mean(axis=0).reshape((-1, 1))
            s = sigma_init * np.sqrt(cma_init)
            z = np.random.normal(size=(dim, pop_size))
            x_new = mu + s * z

            # Clip the new candidate within bounds and evaluate
            x_new = np.clip(x_new, lb, ub).reshape((-1,))
            evals = float(np.mean([problem(x) for x in x_new], axis=0))

            # Update population and covariance matrix using CMA-ES equations
            pop = np.vstack((pop, x_new.reshape(-1, dim)))
            n = len(pop)
            s_update = (n - 1) * cmu + 2 * (n - 1) / ((n - 1) + k)
            cma_init = sigma_init**2 * np.eye(dim) + (s_update - 1) * np.outer(x_new - pop.mean(axis=0), x_new - pop.mean(axis=0)) / n

            evaluations += 1

        return best_x, float(best_y)

def _robust_eval(x, k):
    return float(np.mean([problem(x) for _ in range(k)]))

# Example usage:
# optimizer = BBOB11Optimizer()
# result = optimizer(problem_instance, budget)