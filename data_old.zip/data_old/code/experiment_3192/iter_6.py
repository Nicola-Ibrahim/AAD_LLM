import numpy as np

class BBOB11Optimizer:
    def __init__(self):
        pass  # No additional initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        pop_size = 50  # Number of candidates in the population
        k = int(0.2 * budget / (pop_size * dim))  # Re-evaluation strategy: at most 20% of budget for each candidate
        if k < 1:
            k = 1

        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        best_x = pop[np.argmin(np.apply_along_axis(lambda x: _robust_eval(x, k, problem), 1, pop))]
        best_y = float(problem(best_x))
        evaluations = 1 + pop_size * (k + 1)

        while evaluations < budget:
            # Generate new candidates
            new_pop = np.clip(pop + np.random.normal(0, 0.1, size=(pop_size, dim)), lb, ub)
            
            # Evaluate each candidate
            new_evals = float(np.mean([problem(x) for x in new_pop], axis=1))
            evaluations += pop_size * len(new_evals)

            # Select the best candidate based on mean noisy evaluation
            best_idx = np.argmin(new_evals)
            if new_evals[best_idx] < best_y:
                best_x = new_pop[best_idx]
                best_y = float(problem(best_x))
                evaluations += 1

        return best_x, float(best_y)

def _robust_eval(x, k, problem):
    return float(np.mean([problem(x) for _ in range(k)]))

# Example usage:
# optimizer = BBOB11Optimizer()
# result = optimizer(problem_instance, budget)