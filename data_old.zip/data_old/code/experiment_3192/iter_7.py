import numpy as np

class BBOB11Optimizer:
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Number of particles and swarm size
        n_particles = 50
        w = 0.729  # Inertia weight
        c1 = 2.0  # Cognitive component
        c2 = 2.0  # Social component

        # Initialize particle positions, velocities, and best solutions
        particles = np.random.uniform(lb, ub, size=(n_particles, dim))
        vels = np.zeros((n_particles, dim))
        p_best = particles.copy()
        g_best = particles[np.argmin(np.apply_along_axis(lambda x: _robust_eval(x, 5, problem), 1, particles))]
        g_best_y = float(problem(g_best))

        evaluations = n_particles * (5 + 1)  # Initial evaluations for initialization

        while evaluations < budget:
            # Update particle velocities
            vels = w * vels + c1 * np.random.rand(n_particles, dim) * (p_best - particles) + \
                   c2 * np.random.rand(n_particles, dim) * (g_best - particles)

            # Update particle positions and evaluate
            new_positions = np.clip(particles + vels, lb, ub)
            new_evals = _robust_eval(new_positions, 5, problem)

            evaluations += n_particles * len(new_evals)

            # Update personal best solutions
            idx_to_update = (new_evals < p_best[:, np.newaxis]).argmax(axis=0)
            p_best[idx_to_update] = new_positions[idx_to_update]

            # Update global best solution if necessary
            idx_to_update = (new_evals < g_best_y).argmax()
            if new_evals[idx_to_update] < g_best_y:
                g_best = new_positions[idx_to_update]
                g_best_y = float(problem(g_best))

        return g_best, float(g_best_y)

def _robust_eval(x, k):
    return float(np.mean([problem(x) for _ in range(k)]))

# Example usage:
# optimizer = BBOB11Optimizer()
# result = optimizer(problem_instance, budget)