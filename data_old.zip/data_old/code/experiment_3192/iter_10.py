import numpy as np

class PSOBBOB11Optimizer:
    def __init__(self):
        pass  # No additional initialization needed

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize PSO parameters
        pop_size = 50
        c1, c2 = 2.0, 2.0  # Cognitive and social weights
        w = 0.9          # Inertia weight
        n_iter = int(budget / (pop_size * dim)) + 1  # Number of iterations

        # Initialize the swarm
        X = np.random.uniform(lb, ub, size=(pop_size, dim))
        V = np.zeros_like(X)
        p_best = X.copy()
        g_best = X[np.argmin(np.apply_along_axis(lambda x: _robust_eval(x, 1, problem), 1, X))]

        evaluations = pop_size * n_iter

        for i in range(n_iter):
            # Update velocities and positions
            r1, r2 = np.random.rand(pop_size, dim), np.random.rand(pop_size, dim)
            V = w * V + c1 * r1 * (p_best - X) + c2 * r2 * (g_best - X)
            X += V

            # Clip positions within bounds
            X = np.clip(X, lb, ub)

            # Evaluate each candidate
            new_evals = _robust_eval(X, 1, problem)

            # Update p_best and g_best
            for j in range(pop_size):
                if new_evals[j] < _robust_eval(p_best[j], 1, problem):
                    p_best[j] = X[j]
                if new_evals[j] < _robust_eval(g_best, 1, problem):
                    g_best = X[j]

            evaluations += pop_size

        return g_best, float(problem(g_best))

def _robust_eval(x, k, problem):
    return np.mean([problem(x) for _ in range(k)])