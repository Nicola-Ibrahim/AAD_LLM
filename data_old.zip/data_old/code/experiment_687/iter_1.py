import numpy as np

class RobustExplorer:
    def __init__(self):
        pass  # Add initialization state here if your algorithm needs it

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        pop_size = 100  # Population size
        mutation_step = 0.2  # Initial mutation step size

        # Always start with a random initial point using vectorization
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = 0

        # Evaluate the initial population
        fitness = np.array([float(problem(x)) for x in population])
        evaluations += pop_size
        best_idx = np.argmin(fitness)
        best_x = population[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Generate new candidates through mutation
            mutations = np.random.normal(0, mutation_step, size=(pop_size, dim))
            candidates = np.clip(population + mutations, lb, ub)

            # Evaluate the new candidates
            candidate_fitness = np.array([float(problem(x)) for x in candidates])
            evaluations += pop_size

            # Update the population with better candidates
            improved_idx = candidate_fitness < fitness
            population[improved_idx] = candidates[improved_idx]
            fitness[improved_idx] = candidate_fitness[improved_idx]

            # Check if a new best solution is found
            new_best_idx = np.argmin(fitness)
            if new_best_idx != best_idx:
                best_x = population[new_best_idx]
                best_y = fitness[new_best_idx]

            # Adapt the mutation step size
            if best_y < fitness[best_idx]:
                mutation_step *= 0.95
            else:
                mutation_step *= 1.05

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)