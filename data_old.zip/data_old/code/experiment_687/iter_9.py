import numpy as np

class AdaptiveNoiseRobustOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        pop_size = 100  # Population size
        mutation_step = 0.2 * np.ones(dim)  # Initial mutation step size for each dimension
        re_evaluations = 5  # Number of re-evaluations per candidate

        # Always start with a random initial point using vectorization
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = 0

        # Evaluate the initial population
        fitness = np.array([np.mean([float(problem(x)) for _ in range(re_evaluations)]) for x in population])
        evaluations += pop_size * re_evaluations
        best_idx = np.argmin(fitness)
        best_x = population[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Generate new candidates through mutation with adaptive step sizes
            mutations = np.random.normal(0, mutation_step, size=(pop_size, dim))
            candidates = np.clip(population + mutations, lb, ub)

            # Evaluate the new candidates with re-evaluation
            candidate_fitness = np.array([np.mean([float(problem(x)) for _ in range(re_evaluations)]) for x in candidates])
            evaluations += pop_size * re_evaluations

            # Update the population with better candidates
            improved_idx = candidate_fitness < fitness
            population[improved_idx] = candidates[improved_idx]
            fitness[improved_idx] = candidate_fitness[improved_idx]

            # Check if a new best solution is found
            new_best_idx = np.argmin(fitness)
            if new_best_idx != best_idx:
                best_x = population[new_best_idx]
                best_y = fitness[new_best_idx]

            # Adapt the mutation step size
            mutation_step[improved_idx] *= 0.95
            mutation_step[~improved_idx] *= 1.05

            # Dynamically adjust re-evaluations based on remaining budget
            remaining_budget = budget - evaluations
            if remaining_budget > 0.8 * budget and re_evaluations < 20:
                re_evaluations += 1
            elif remaining_budget < 0.2 * budget and re_evaluations > 1:
                re_evaluations -= 1

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)