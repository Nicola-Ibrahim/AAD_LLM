import numpy as np

class EnhancedOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))
        pop_size = 200  # Increased population size
        mutation_step = 0.2  # Initial mutation step size
        re_evaluations = 10  # More re-evaluations per candidate to reduce noise impact

        # Always start with a random initial point using vectorization
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = 0

        # Evaluate the initial population
        fitness = np.array([np.mean([float(problem(x)) for _ in range(re_evaluations)]) for x in population])
        evaluations += pop_size * re_evaluations
        best_idx = np.argmin(fitness)
        best_x = population[best_idx]
        best_y = fitness[best_idx]

        while evaluations < budget:
            # Generate new candidates through mutation and crossover
            mutations = np.random.normal(0, mutation_step, size=(pop_size, dim))
            parents = np.random.choice(population, (pop_size, dim), replace=True)
            crossovers = np.random.rand(pop_size, dim) < 0.5
            candidates = np.where(crossovers, parents + mutations, population + mutations)
            candidates = np.clip(candidates, lb, ub)

            # Evaluate the new candidates with re-evaluation
            candidate_fitness = np.array([np.mean([float(problem(x)) for _ in range(re_evaluations)]) for x in candidates])
            evaluations += pop_size * re_evaluations

            # Update the population with better candidates
            improved_idx = candidate_fitness < fitness
            population[improved_idx] = candidates[improved_idx]
            fitness[improved_idx] = candidate_fitness[improved_idx]

            # Check if a new best solution is found
            new_best_idx = np.argmin(fitness)
            if new_best_idx != best_idx:
                best_x = population[new_best_idx]
                best_y = fitness[new_best_idx]

            # Adapt the mutation step size
            if best_y < fitness[best_idx]:
                mutation_step *= 0.95
            else:
                mutation_step *= 1.05

            # Maintain diversity by introducing new random solutions
            if np.all(np.isclose(fitness, fitness[0])):
                population = np.random.uniform(lb, ub, size=(pop_size, dim))
                fitness = np.array([np.mean([float(problem(x)) for _ in range(re_evaluations)]) for x in population])
                evaluations += pop_size * re_evaluations

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)