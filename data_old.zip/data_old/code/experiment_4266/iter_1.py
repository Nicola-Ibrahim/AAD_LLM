import numpy as np

class DifferentialEvolution:
    def __init__(self):
        self.F = 0.5  # Scaling factor for differential variation
        self.CR = 0.9  # Crossover probability

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population randomly
        pop_size = min(int(budget / (2 * dim)), 100)  # Limit population size for efficiency
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        
        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        evaluations = len(fitness)

        best_x = pop[np.argmin(fitness)]  # Best solution so far (in terms of fitness)
        best_y = float(np.min(fitness))   # Corresponding best objective value

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Mutation step
                a, b, c = np.random.choice(range(pop_size), 3, replace=False)
                mutant = pop[a] + self.F * (pop[b] - pop[c])
                
                # Crossover step
                trial = np.where(np.random.rand(dim) < self.CR, mutant, pop[i])
                
                # Evaluate the candidate with noise-reduced strategy
                k_evals = min(int(budget / (10 * dim)), 20)  # Limit re-evaluations for efficiency
                trial_y = np.mean([problem(trial) for _ in range(k_evals)])
                
                # Selection step
                if trial_y < fitness[i]:
                    new_pop.append(trial)
                    fitness[i] = trial_y
                else:
                    new_pop.append(pop[i])
                
                evaluations += 1
                if evaluations >= budget:
                    break
            
            pop = np.array(new_pop)
        
        best_x = pop[np.argmin(fitness)]  # Update the best solution found so far
        best_y = float(np.min(fitness))   # Corresponding best objective value

        return (best_x, best_y)