import numpy as np

class HybridEvolution:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = min(100, budget)  # Start with a small population to save evaluations
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        scores = np.array([float(problem(x)) for x in pop])
        evaluations = pop_size

        best_x = pop[np.argmin(scores)]
        best_y = np.min(scores)

        # Covariance matrix adaptation parameters
        F = 0.5  # Scaling factor
        CR = 0.9  # Crossover rate
        sigma = (ub - lb) / 2  # Initial standard deviation

        while evaluations < budget:
            # Select three random individuals from the population
            r1, r2, r3 = np.random.choice(pop_size, size=3, replace=False)
            mutants = pop[r1] + F * (pop[r2] - pop[r3])
            # Apply binomial crossover mask
            mask = np.random.rand(pop_size, dim) < CR
            trials = np.where(mask, mutants, pop)
            trials = np.clip(trials, lb, ub)

            trial_scores = []
            for x in trials:
                score = 0
                for _ in range(3):  # Re-evaluate each candidate multiple times
                    score += float(problem(x))
                trial_scores.append(score / 3)  # Take the average of re-evaluations

            evaluations += len(trial_scores)

            # Update population with better trials
            mask = np.array(trial_scores) < scores
            pop[mask] = trials[mask]
            scores[mask] = np.array(trial_scores)[mask]

            # Update best solution
            current_best_idx = np.argmin(scores)
            if scores[current_best_idx] < best_y:
                best_x = pop[current_best_idx]
                best_y = scores[current_best_idx]

        return best_x, float(best_y)