import numpy as np

class HybridEvolution:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = min(100, budget)  # Start with a small population to save evaluations
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        scores = np.array([float(problem(x)) for x in pop])
        evaluations = pop_size

        best_x = pop[np.argmin(scores)]
        best_y = np.min(scores)

        # Covariance matrix adaptation parameters
        F = 0.5  # Scaling factor
        CR = 0.9  # Crossover rate
        sigma = (ub - lb) / 2  # Initial standard deviation

        while evaluations < budget:
            mutants = pop[np.random.choice(pop_size, size=3, replace=True)]
            mutants[:, :dim] += F * (mutants[:, dim:] - mutants[:, dim:][np.random.permutation(3)])
            mutants = np.clip(mutants, lb, ub)

            trials = np.where(np.random.rand(pop_size, dim) < CR, mutants, pop)
            trial_scores = np.array([float(problem(x)) for x in trials])
            evaluations += len(trial_scores)

            # Update population with better trials
            mask = trial_scores < scores
            pop[mask] = trials[mask]
            scores[mask] = trial_scores[mask]

            # Update best solution
            current_best_idx = np.argmin(scores)
            if scores[current_best_idx] < best_y:
                best_x = pop[current_best_idx]
                best_y = scores[current_best_idx]

        return best_x, best_y