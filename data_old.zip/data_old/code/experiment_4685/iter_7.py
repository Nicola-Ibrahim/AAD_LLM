import numpy as np

class NoiseResilientOptimizer:
    def __init__(self):
        pass  # No initialization needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize the best solution found so far
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        while evaluations < budget:
            pop_size = min(20 * dim, (budget - evaluations) // dim)  # Population size based on remaining budget
            candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
            
            trial_ys = []
            for x in candidates:
                ys = [float(problem(x + np.random.normal(0, 0.1, size=dim))) for _ in range(5)]
                trial_ys.append(np.median(ys))  # Use median to reduce noise impact
            
            trial_ys = np.array(trial_ys)
            best_idx = np.argmin(trial_ys)
            new_x = candidates[best_idx]
            new_y = float(problem(new_x))
            evaluations += 1
            
            if new_y < best_y:
                best_x, best_y = new_x, new_y
        
        return (best_x, float(best_y))