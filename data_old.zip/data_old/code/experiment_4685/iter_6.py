import numpy as np

class CovarianceMatrixAdaptationEvolutionStrategy:
    def __init__(self):
        self.mean = None
        self.covariance_matrix = None
    
    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb)))
        
        # Initialize mean and covariance matrix for the ES
        self.mean = np.random.uniform(lb, ub, size=dim)
        self.covariance_matrix = np.eye(dim) * 0.1
        
        best_x = self.mean.copy()
        best_y = float(problem(best_x))
        evaluations = 1
        
        while evaluations < budget:
            pop_size = min(20 * dim, (budget - evaluations) // dim)
            candidates = np.random.multivariate_normal(self.mean, self.covariance_matrix, size=pop_size)
            
            # Evaluate each candidate multiple times to compute robust statistics
            trial_ys = []
            for x in candidates:
                ys = [float(problem(x + np.random.normal(0, 0.1, size=dim))) for _ in range(5)]
                trial_ys.append(np.median(ys))
            
            trial_ys = np.array(trial_ys)
            best_idx = np.argmin(trial_ys)
            new_x = candidates[best_idx]
            new_y = float(problem(new_x))
            evaluations += 1
            
            if new_y < best_y:
                best_x, best_y = new_x, new_y
                # Update mean and covariance matrix based on the accepted candidate
                self.mean = (0.9 * self.mean) + (0.1 * new_x)
                self.covariance_matrix = np.cov(candidates.T) * 0.2  # Adjust learning rate for covariance
        
        return (best_x, float(best_y))