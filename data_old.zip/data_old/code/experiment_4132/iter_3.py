import numpy as np

class DifferentialEvolution:
    def __init__(self):
        pass  # No initialization needed for the algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population size
        pop_size = 10 * dim
        mutation_factor = 0.8
        crossover_rate = 0.9

        # Initialize population randomly within the bounds
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        best_x = population[np.argmin([problem(x) for x in population])]
        best_y = float(problem(best_x))
        evaluations = 1

        while evaluations < budget:
            # Generate new candidates through mutation and crossover
            mutants = np.array([population[i] + mutation_factor * (population[j] - population[k])
                                for i in range(pop_size)
                                for j, k in zip(np.random.randint(0, pop_size, 2), np.random.randint(0, pop_size, 2))])
            crossover = np.random.rand(*population.shape) < crossover_rate  # Apply to the entire population shape
            trial_populations = np.where(crossover[:, :dim], mutants, population)  # Ensure dimensions match
            
            # Evaluate the new candidates
            trial_values = [problem(trial_population) for trial_population in trial_populations]
            evaluations += len(trial_values)

            # Update best solution found so far
            updated_indices = np.argmin(trial_values, axis=0)
            new_best_x = trial_populations[updated_indices][0]  # Select the first one in case of ties
            new_best_y = float(min(trial_values))

            if new_best_y < best_y:
                best_x, best_y = new_best_x, new_best_y

            # Replace old population with the trial population
            population = np.vstack((population, trial_populations))  # Storing all trials for next iteration
            population = population[:pop_size]  # Keep only the top pop_size candidates

        return best_x, float(best_y)