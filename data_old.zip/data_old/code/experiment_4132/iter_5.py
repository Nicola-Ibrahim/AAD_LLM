import numpy as np

class DEAlgorithm:
    def __init__(self):
        pass  # No initialization needed for the algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initial population size
        pop_size = 10 * dim
        mutation_factor = 0.8
        crossover_rate = 0.9

        # Initialize population randomly within the bounds
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        best_index = np.argmin(fitness)
        best_x = population[best_index]
        best_y = float(fitness[best_index])
        evaluations = pop_size

        while evaluations < budget:
            # Generate new candidates through mutation and crossover
            for i in range(pop_size):
                j, k = np.random.randint(0, pop_size, 2)
                mutant = population[j] + mutation_factor * (population[k] - population[i])
                trial = np.where(np.random.rand(dim) < crossover_rate, mutant, population[i])
                
                # Evaluate the new candidate
                trial_fitness = problem(trial)
                evaluations += 1

                # Update if the trial is better than current
                if trial_fitness < fitness[i]:
                    population[i] = trial
                    fitness[i] = trial_fitness

            # Check for new best solution
            current_best_index = np.argmin(fitness)
            if fitness[current_best_index] < best_y:
                best_x, best_y = population[current_best_index], float(fitness[current_best_index])

        return best_x, float(best_y)