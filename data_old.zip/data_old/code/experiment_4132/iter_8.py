import numpy as np

class AdaptiveDE:
    def __init__(self):
        pass  # No initialization needed for the algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = 10 * dim
        mutation_factor = 0.5  # Initial mutation factor
        crossover_rate = 0.9
        best_fitness = float('inf')
        evaluations = 0

        # Initialize population randomly within the bounds
        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        evaluations += pop_size
        best_index = np.argmin(fitness)
        best_x = population[best_index]
        best_y = float(fitness[best_index])

        while evaluations < budget:
            new_population = []
            for i in range(pop_size):
                # Select three random individuals different from the target individual
                j, k, l = np.random.choice(range(pop_size), 3, replace=False)
                if j != i and k != i and l != i:
                    mutant = population[j] + mutation_factor * (population[k] - population[l])
                    trial = np.where(np.random.rand(dim) < crossover_rate, mutant, population[i])
                    
                    # Evaluate the new candidate
                    trial_fitness = problem(trial)
                    evaluations += 1

                    if trial_fitness < fitness[i]:
                        new_population.append(trial)
                        fitness[i] = trial_fitness
                    else:
                        new_population.append(population[i])
                else:
                    new_population.append(population[i])
            
            # Update population with the new generation
            population = np.array(new_population)

            # Check for new best solution
            current_best_index = np.argmin(fitness)
            if fitness[current_best_index] < best_y:
                best_x, best_y = population[current_best_index], float(fitness[current_best_index])

            # Adjust mutation factor based on the population's fitness distribution
            mutation_factor *= 0.99  # Example decay rate; adjust as needed

        return best_x, float(best_y)