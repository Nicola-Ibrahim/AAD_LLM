import numpy as np

class DEOptimizer:
    def __init__(self):
        self.F = 0.8  # Scaling factor, typically between 0.5 and 1.0
        self.CR = 0.9  # Crossover rate, typically set between 0.1 and 1.0

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)
        pop_size = min(100, budget // (2 * dim))  # Population size should be much smaller than the evaluation budget
        
        # Initialize population uniformly within bounds
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in pop])  # Evaluate initial population
        evaluations = pop_size

        while evaluations < budget:
            candidates = []
            candidate_fitness = []
            
            for i in range(pop_size):
                r1, r2, r3 = np.random.randint(0, pop_size, 3)
                mutant = pop[r1] + self.F * (pop[r2] - pop[r3])
                mask = np.random.rand(dim) < self.CR
                trial = np.where(mask[:, None], mutant, pop[i])
                trial = np.clip(trial, lb, ub)  # Ensure the trial vector is within bounds
                
                candidates.append(trial)
                candidate_fitness.append(float(problem(trial)))
            
            candidates = np.array(candidates)
            candidate_fitness = np.array(candidate_fitness)
            evaluations += pop_size
            
            # Update population with new candidates if they are better
            improvement = candidate_fitness < fitness
            if any(improvement):
                idx = np.argmax(~improvement)  # Find the index of the worst individual in the current population
                fitness[idx] = candidate_fitness[np.argmax(~improvement)]
                pop[idx] = candidates[idx]
        
        best_index = np.argmin(fitness)
        return (pop[best_index], float(fitness[best_index]))