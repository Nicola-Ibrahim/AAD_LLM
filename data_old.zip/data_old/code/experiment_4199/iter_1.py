import numpy as np

class DE:
    def __init__(self):
        # Initialization parameters for DE (e.g., scaling factor F, crossover rate CR) can be added here if needed.
        self.F = 0.5  # Scaling factor typically in the range [0, 2]
        self.CR = 0.7  # Crossover rate typically set between 0.1 and 1.0

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = min(100, budget // (2 * dim))  # Population size typically set to be much smaller than the evaluation budget
        best_x = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        while evaluations < budget:
            candidates = []
            for i in range(pop_size):
                r1, r2, r3 = np.random.randint(0, pop_size, 3)
                mutant = best_x[r1] + self.F * (best_x[r2] - best_x[r3])
                mask = np.random.rand(dim) < self.CR
                trial = np.where(mask[:, None], mutant, best_x[i])
                trial = np.clip(trial, lb, ub)  # Ensure the trial vector is within bounds
                candidates.append(trial)

            candidates = np.array(candidates)
            candidate_fitness = [float(problem(cand)) for cand in candidates]
            evaluations += pop_size

            improvement = candidate_fitness < [problem(x) for x in best_x]
            if any(improvement):
                idx = np.argmax(improvement)  # Find the index of the worst individual in the current population
                best_x[idx] = candidates[idx]

        best_y = min([float(problem(x)) for x in best_x])  # Find the minimum fitness value among all individuals
        best_x = best_x[np.argmin([problem(x) for x in best_x])]  # Get the corresponding best individual

        return best_x, float(best_y)