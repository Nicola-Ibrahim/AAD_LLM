import numpy as np

class DE:
    def __init__(self):
        self.F = 0.5  # Scaling factor typically in the range [0, 2]
        self.CR = 0.7  # Crossover rate typically set between 0.1 and 1.0
        self.initial_F = 0.5
        self.final_F = 0.9
        self.current_F = self.initial_F
        self.initial_CR = 0.7
        self.final_CR = 0.9
        self.current_CR = self.initial_CR
        self.step = (self.final_F - self.initial_F) / (budget // pop_size)
        self.step_cr = (self.final_CR - self.initial_CR) / (budget // pop_size)

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        pop_size = min(100, budget // (2 * dim))  # Population size typically set to be much smaller than the evaluation budget
        best_x = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        while evaluations < budget:
            candidates = []
            for i in range(pop_size):
                r1, r2, r3 = np.random.randint(0, pop_size, 3)
                mutant = best_x[r1] + self.current_F * (best_x[r2] - best_x[r3])
                mask = np.random.rand(dim) < self.current_CR
                trial = np.where(mask[:, None], mutant, best_x[i])
                trial = np.clip(trial, lb, ub)  # Ensure the trial vector is within bounds
                candidates.append(trial)

            candidates = np.array(candidates)
            candidate_fitness = [float(problem(cand)) for cand in candidates]
            evaluations += pop_size

            improvement = np.array(candidate_fitness) < np.array([problem(x) for x in best_x])
            if any(improvement):
                idx = np.argmax(improvement)  # Find the index of the worst individual in the current population
                best_x[idx] = candidates[idx]

            self.current_F -= self.step / (budget // pop_size)
            self.current_CR -= self.step_cr / (budget // pop_size)

        best_y = min(candidate_fitness)  # Find the minimum fitness value among all individuals
        best_x = best_x[np.argmin(candidate_fitness)]  # Get the corresponding best individual

        return best_x, float(best_y)