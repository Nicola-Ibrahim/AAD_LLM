import numpy as np

class MetaNoisyOptimizationAlgorithm:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initial parameters
        pop_size = 100
        k = 3
        initial_mutation_rate = 0.1

        # Initialize population randomly
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        evaluations = pop_size

        best_x = pop[0]
        best_y = float(problem(best_x))
        evaluations += 1

        mutation_rate = initial_mutation_rate

        while evaluations < budget:
            # Evaluate current population in batches
            batch_evals = []
            for i in range(0, len(pop), budget // (len(pop) * k)):
                batch = pop[i:i + budget // (len(pop) * k)]
                batch_ys = np.array([self._robust_eval(problem, x, self.k) for x in batch])
                evaluations += len(batch) * self.k
                batch_evals.append(batch_ys)

            batch_evals = np.concatenate(batch_evals)
            
            # Select the best candidate from current population
            best_idx = np.argmin(batch_evals)
            new_best_x = pop[best_idx]
            new_best_y = float(problem(new_best_x))
            evaluations += 1

            if new_best_y < best_y:
                best_x, best_y = new_best_x, new_best_y

            # Generate new population
            new_pop = []
            for x in pop:
                # Generate new candidate by mutation
                new_x = np.clip(x + np.random.normal(0, mutation_rate, size=dim), lb, ub)
                evaluations += 1
                new_pop.append(new_x)

            new_pop = np.array(new_pop)
            
            # Evaluate new population in batches
            batch_evals_new = []
            for i in range(0, len(new_pop), budget // (len(new_pop) * k)):
                batch = new_pop[i:i + budget // (len(new_pop) * k)]
                batch_ys = np.array([self._robust_eval(problem, x, self.k) for x in batch])
                evaluations += len(batch) * self.k
                batch_evals_new.append(batch_ys)

            batch_evals_new = np.concatenate(batch_evals_new)
            
            # Combine and sort populations
            combined_evals = np.concatenate((batch_evals, batch_evals_new))
            combined_pop = np.vstack((pop, new_pop))
            sorted_indices = np.argsort(combined_evals)
            
            # Select top half of the population for elitism
            pop = combined_pop[sorted_indices[:self.pop_size]]
            
            # Adapt mutation rate based on improvement
            if new_best_y < best_y:
                mutation_rate *= 0.95
            else:
                mutation_rate = min(mutation_rate * 1.05, self.initial_mutation_rate)

            # Meta-optimizer strategy to adjust parameters
            if evaluations > budget * 0.8:
                pop_size = max(20, int(pop_size * 0.9))
            if evaluations > budget * 0.5 and mutation_rate < initial_mutation_rate / 10:
                k += 1
            if evaluations > budget * 0.3 and np.std(batch_evals) < 0.01:
                mutation_rate *= 1.2

        return best_x, float(best_y)

    def _robust_eval(self, problem, x, k):
        return float(np.mean([problem(x) for _ in range(k)]))