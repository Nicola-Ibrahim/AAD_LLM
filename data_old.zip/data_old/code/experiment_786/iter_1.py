import numpy as np

class NoisyOptimizationAlgorithm:
    def __init__(self):
        self.pop_size = 100  # Population size
        self.k = 3  # Number of evaluations per candidate to average
        self.mutation_rate = 0.1  # Mutation rate for generating new candidates

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population randomly
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evaluations = self.pop_size

        best_x = pop[0]
        best_y = float(problem(best_x))
        evaluations += 1

        while evaluations < budget:
            new_pop = []
            for x in pop:
                # Generate new candidate by mutation
                new_x = np.clip(x + np.random.normal(0, self.mutation_rate, size=dim), lb, ub)
                evaluations += 1
                new_pop.append(new_x)

            new_pop = np.array(new_pop)
            
            # Evaluate candidates in batches
            batch_evals = []
            for i in range(0, len(new_pop), budget // (len(new_pop) * self.k)):
                batch = new_pop[i:i + budget // (len(new_pop) * self.k)]
                batch_ys = np.array([self._robust_eval(x, self.k) for x in batch])
                evaluations += len(batch) * self.k
                batch_evals.append(batch_ys)

            batch_evals = np.concatenate(batch_evals)
            
            # Select the best candidate from new population
            best_idx = np.argmin(batch_evals)
            new_best_x = new_pop[best_idx]
            new_best_y = float(problem(new_best_x))
            evaluations += 1

            if new_best_y < best_y:
                best_x, best_y = new_best_x, new_best_y

            # Update population
            pop = np.vstack((pop, new_pop))
            pop = pop[np.argsort(batch_evals)[:self.pop_size]]

        return best_x, float(best_y)

    def _robust_eval(self, x, k):
        return float(np.mean([problem(x) for _ in range(k)]))