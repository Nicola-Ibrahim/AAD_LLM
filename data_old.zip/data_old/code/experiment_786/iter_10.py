import numpy as np

class EnhancedNoisyOptimizationAlgorithm:
    def __init__(self):
        self.pop_size = 100  # Increased population size for better exploration
        self.k = 5  # More evaluations per candidate to average for robustness
        self.initial_mutation_rate = 0.2  # Higher initial mutation rate for more exploration

    def __call__(self, problem, budget):
        lb = np.asarray(problem.lower_bound, dtype=float)
        ub = np.asarray(problem.upper_bound, dtype=float)
        dim = len(lb)

        # Initialize population randomly
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evaluations = self.pop_size

        best_x = pop[0]
        best_y = float(problem(best_x))
        evaluations += 1

        mutation_rate = self.initial_mutation_rate

        while evaluations < budget:
            # Evaluate current population in batches
            batch_evals = np.array([self._robust_eval(problem, x, self.k) for x in pop])
            evaluations += len(pop) * self.k
            
            # Select the best candidate from current population
            best_idx = np.argmin(batch_evals)
            new_best_x = pop[best_idx]
            new_best_y = float(problem(new_best_x))
            evaluations += 1

            if new_best_y < best_y:
                best_x, best_y = new_best_x, new_best_y

            # Generate new population
            new_pop = []
            for x in pop:
                # Generate new candidate by mutation with adaptive scaling
                scale_factor = np.random.uniform(0.8, 1.2)
                new_x = np.clip(x + np.random.normal(0, scale_factor * mutation_rate, size=dim), lb, ub)
                evaluations += 1
                new_pop.append(new_x)

            new_pop = np.array(new_pop)
            
            # Evaluate new population in batches
            batch_evals_new = np.array([self._robust_eval(problem, x, self.k) for x in new_pop])
            evaluations += len(new_pop) * self.k
            
            # Combine and sort populations
            combined_evals = np.concatenate((batch_evals, batch_evals_new))
            combined_pop = np.vstack((pop, new_pop))
            sorted_indices = np.argsort(combined_evals)
            
            # Select top half of the population for elitism
            pop = combined_pop[sorted_indices[:self.pop_size]]
            
            # Adapt mutation rate based on improvement and diversity
            if new_best_y < best_y:
                mutation_rate *= 0.95
            else:
                mutation_rate = min(mutation_rate * 1.05, self.initial_mutation_rate)
            
            # Adjust mutation rate based on population diversity
            diversity = np.mean(np.std(pop, axis=0))
            if diversity < 0.1:
                mutation_rate *= 1.2
            elif diversity > 0.3:
                mutation_rate *= 0.8

        return best_x, float(best_y)

    def _robust_eval(self, problem, x, k):
        return float(np.mean([problem(x) for _ in range(k)]))