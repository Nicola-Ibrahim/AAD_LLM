import numpy as np

class HybridOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        while evaluations < budget:
            # Global exploration using a genetic algorithm approach
            selection_rate = 0.1
            parents = pop[np.random.choice(population_size, int(selection_rate * population_size), replace=False)]
            children = np.zeros((population_size, dim))
            for i in range(0, population_size, 2):
                parent1, parent2 = parents[i], parents[i + 1]
                child = (parent1 + parent2) / 2.0
                child += np.random.normal(0, 2.0, size=dim)
                children[i] = child
                children[i + 1] = child

            # Refine the best solutions using gradient approximation
            for _ in range(5):
                grad_approx = (problem(best_x + 1e-6 * np.eye(dim)) - problem(best_x - 1e-6 * np.eye(dim))) / (2 * 1e-6)
                best_x += -0.01 * grad_approx

            # Evaluate the new population
            child_fitness = np.array([problem(x) for x in children])
            evaluations += len(child_fitness)

            # Update population with better solutions
            combined_pop = np.vstack((pop, children))
            combined_fitness = np.hstack((fitness, child_fitness))
            idx_sorted = np.argsort(combined_fitness)
            pop = combined_pop[idx_sorted[:population_size]]
            fitness = combined_fitness[idx_sorted[:population_size]]

            # Update best solution if necessary
            new_best_idx = np.argmin(fitness)
            if fitness[new_best_idx] < best_y:
                best_x = pop[new_best_idx]
                best_y = float(fitness[new_best_idx])

        return best_x, best_y