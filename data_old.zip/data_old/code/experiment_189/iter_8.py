import numpy as np

class CustomOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        while evaluations < budget:
            # DE/OL mutation and crossover
            offspring = np.zeros_like(pop)
            for i in range(population_size):
                a, b, c = pop[np.random.permutation(3)]
                mutant = a + 0.5 * (b - c)
                mutant = np.clip(mutant, lb, ub)
                
                # Opposition-based learning
                opposite = 2 * best_x - mutant
                
                offspring[i] = np.clip(0.5 * (mutant + opposite), lb, ub)

            offspring_fitness = np.array([problem(x) for x in offspring])
            
            # Update population with better solutions
            for i in range(population_size):
                if offspring_fitness[i] < fitness[i]:
                    pop[i] = offspring[i]
                    fitness[i] = offspring_fitness[i]

            # Update best solution
            new_best_idx = np.argmin(fitness)
            if fitness[new_best_idx] < best_y:
                best_x = pop[new_best_idx]
                best_y = float(fitness[new_best_idx])
                evaluations += 1

        return best_x, best_y