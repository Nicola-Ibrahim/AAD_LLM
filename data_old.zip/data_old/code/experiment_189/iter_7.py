import numpy as np

class CustomOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        while evaluations < budget:
            # Global exploration using a simple random walk
            exploration_step = 2.0
            exploratory_pop = pop + np.random.normal(0, exploration_step, size=(population_size, dim))
            exploratory_pop = np.clip(exploratory_pop, lb, ub)
            exploratory_fitness = np.array([problem(x) for x in exploratory_pop])
            
            # Update population with better solutions
            new_best_idx = np.argmin(exploratory_fitness)
            if exploratory_fitness[new_best_idx] < best_y:
                best_x = exploratory_pop[new_best_idx]
                best_y = float(exploratory_fitness[new_best_idx])
                evaluations += 1

                # Adaptive step size reduction
                exploration_step *= 0.95
                exploration_step = max(0.01, exploration_step)  # Ensure step size does not become too small

            # Local exploitation using gradient information
            if best_y < np.inf and evaluations > 100:  # Ensure enough evaluations for gradient
                grad = problem.gradient(best_x)
                descent_direction = -grad
                descent_length = 0.5 * np.linalg.norm(grad) / exploration_step
                new_x = best_x + descent_direction * descent_length
                new_x = np.clip(new_x, lb, ub)

                # Evaluate new solution
                new_y = problem(new_x)
                evaluations += 1

                # Update best solution if the new one is better
                if new_y < best_y:
                    best_x = new_x
                    best_y = float(new_y)

        return best_x, best_y