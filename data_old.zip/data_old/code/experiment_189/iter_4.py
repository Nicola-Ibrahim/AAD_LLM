import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import RBF, ConstantKernel as C

class GPRBasedOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        # Initialize Gaussian Process Regressor
        kernel = C(1.0, (1e-3, 1e2)) * RBF([1.0] * dim, (1e-2, 1e1))
        gpr = GaussianProcessRegressor(kernel=kernel, n_restarts_optimizer=9)

        # Fit the GPR model with initial data
        gpr.fit(pop, fitness)

        while evaluations < budget:
            # Predictive sampling using the GPR model
            mean, std_dev = gpr.predict(pop, return_std=True)
            next_point_idx = np.argmin(mean + 2 * std_dev)
            next_point = pop[next_point_idx]
            
            # Evaluate the new point
            next_fitness = problem(next_point)
            evaluations += 1

            # Update population with better solutions
            if next_fitness < best_y:
                best_x = next_point
                best_y = float(next_fitness)

            # Add the new point to the population and retrain GPR
            pop = np.vstack((pop, next_point))
            fitness = np.append(fitness, next_fitness)
            gpr.fit(pop, fitness)

            # Adaptive step size reduction based on estimated noise level
            noise_level = std_dev[0]  # Assuming isotropic noise for simplicity
            exploration_step = max(0.1 * noise_level, 0.01)  # Ensure step size does not become too small

        return best_x, best_y