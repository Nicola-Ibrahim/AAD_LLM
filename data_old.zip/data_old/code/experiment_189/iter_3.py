import numpy as np

class ImprovedOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        while evaluations < budget:
            # Global exploration using a simple random walk
            exploration_step = 2.0
            exploratory_pop = pop + np.random.normal(0, exploration_step, size=(population_size, dim))
            exploratory_pop = np.clip(exploratory_pop, lb, ub)
            exploratory_fitness = np.array([problem(x) for x in exploratory_pop])
            
            # Update population with better solutions
            new_best_idx = np.argmin(exploratory_fitness)
            if exploratory_fitness[new_best_idx] < best_y:
                best_x = exploratory_pop[new_best_idx]
                best_y = float(exploratory_fitness[new_best_idx])
                evaluations += 1

                # Adaptive step size reduction
                exploration_step *= 0.95
                exploration_step = max(0.01, exploration_step)  # Ensure step size does not become too small

            # Fine-grained local exploitation using gradient-based refinement
            if evaluations % 100 == 0 and dim > 1:
                grad_x = np.array([np.gradient(problem, x) for x in pop])
                refine_pop = pop + 0.5 * grad_x
                refine_pop = np.clip(refine_pop, lb, ub)
                refine_fitness = np.array([problem(x) for x in refine_pop])
                
                # Update population with better solutions from gradient refinement
                refine_best_idx = np.argmin(refine_fitness)
                if refine_fitness[refine_best_idx] < best_y:
                    best_x = refine_pop[refine_best_idx]
                    best_y = float(refine_fitness[refine_best_idx])
                    evaluations += 1

        return best_x, best_y