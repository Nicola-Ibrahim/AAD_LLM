import numpy as np

class CustomOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        while evaluations < budget:
            # Global exploration using adaptive mutation
            exploration_step = 2.0
            exploratory_pop = pop + np.random.normal(0, exploration_step, size=(population_size, dim))
            exploratory_pop = np.clip(exploratory_pop, lb, ub)
            
            # Local hill-climbing around the best solution
            neighborhood_size = 5
            neighborhood_indices = np.random.choice(population_size, size=neighborhood_size, replace=False)
            local_best_idx = neighborhood_indices[np.argmin(fitness[neighborhood_indices])]
            local_best_x = pop[local_best_idx]
            
            # Update population with better solutions
            new_best_idx = np.argmin([problem(x) for x in [best_x] + list(exploratory_pop)])
            if new_best_idx == 0:
                best_x = exploratory_pop[new_best_idx]
                best_y = float(problem(best_x))
                evaluations += 1

                # Adaptive step size reduction
                exploration_step *= 0.95
                exploration_step = max(0.01, exploration_step)  # Ensure step size does not become too small

        return best_x, best_y