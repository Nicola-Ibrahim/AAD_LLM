import numpy as np

class CustomOptimizer:
    def __init__(self):
        pass  # Initialization is not needed for this algorithm

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and best solution
        population_size = 100
        pop = np.random.uniform(lb, ub, size=(population_size, dim))
        evaluations = 0

        # Evaluate initial population
        fitness = np.array([problem(x) for x in pop])
        best_idx = np.argmin(fitness)
        best_x = pop[best_idx]
        best_y = float(fitness[best_idx])

        while evaluations < budget:
            # Global exploration using a simple random walk with adaptive step sizes
            exploration_step = 2.0
            exploratory_pop = pop + np.random.normal(0, exploration_step, size=(population_size, dim))
            exploratory_pop = np.clip(exploratory_pop, lb, ub)
            exploratory_fitness = np.array([problem(x) for x in exploratory_pop])
            
            # Update population with better solutions
            new_best_idx = np.argmin(exploratory_fitness)
            if exploratory_fitness[new_best_idx] < best_y:
                best_x = exploratory_pop[new_best_idx]
                best_y = float(exploratory_fitness[new_best_idx])
                evaluations += 1

                # Adaptive step size reduction
                exploration_step *= 0.95
                exploration_step = max(0.01, exploration_step)  # Ensure step size does not become too small

            # Local exploitation using gradient information
            if best_y < np.inf:
                # Approximate gradient using central difference
                epsilon = 1e-4
                gradients = np.zeros((dim,))
                for i in range(dim):
                    orig_val = problem(best_x)
                    best_x[i] += epsilon / 2.0
                    grad_pos = problem(best_x)
                    best_x[i] -= epsilon
                    grad_neg = problem(best_x)
                    gradients[i] = (grad_pos - grad_neg) / epsilon
                    best_x[i] = orig_val

                # Move in the direction of steepest descent
                new_x = best_x - 0.1 * gradients
                new_x = np.clip(new_x, lb, ub)
                new_y = problem(new_x)

                if new_y < best_y:
                    best_x = new_x
                    best_y = float(new_y)
                    evaluations += 1

        return best_x, best_y