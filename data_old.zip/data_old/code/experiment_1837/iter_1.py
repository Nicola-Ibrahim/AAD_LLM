import numpy as np

class NoiseResilientPSO:
    def __init__(self):
        self.population_size = 30
        self.inertia_weight = 0.729844
        self.cognitive_coefficient = 1.496180
        self.social_coefficient = 1.496180
        self.num_evaluations_per_candidate = 5

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        positions = np.random.uniform(lb, ub, size=(self.population_size, dim))
        velocities = np.zeros_like(positions)
        personal_best_positions = np.copy(positions)
        personal_best_values = np.array([float(problem(x)) for x in positions])
        evaluations = self.population_size

        # Initialize global best
        global_best_index = np.argmin(personal_best_values)
        global_best_position = personal_best_positions[global_best_index]
        global_best_value = personal_best_values[global_best_index]

        while evaluations < budget:
            # Evaluate each candidate multiple times and take the average
            for i in range(self.population_size):
                candidate_evaluations = np.array([float(problem(positions[i])) for _ in range(self.num_evaluations_per_candidate)])
                evaluations += self.num_evaluations_per_candidate
                avg_value = np.mean(candidate_evaluations)

                # Update personal best if the new average is better
                if avg_value < personal_best_values[i]:
                    personal_best_positions[i] = positions[i]
                    personal_best_values[i] = avg_value

            # Update global best
            global_best_index = np.argmin(personal_best_values)
            if personal_best_values[global_best_index] < global_best_value:
                global_best_position = personal_best_positions[global_best_index]
                global_best_value = personal_best_values[global_best_index]

            # Update velocities and positions
            r1 = np.random.rand(self.population_size, dim)
            r2 = np.random.rand(self.population_size, dim)
            velocities = (self.inertia_weight * velocities +
                          self.cognitive_coefficient * r1 * (personal_best_positions - positions) +
                          self.social_coefficient * r2 * (global_best_position - positions))
            positions = np.clip(positions + velocities, lb, ub)

        return global_best_position, float(global_best_value)