import numpy as np

class MyOptimizer:
    def __init__(self):
        self.initial_population_size = 50
        self.inertia_weight = 0.729844
        self.cognitive_coefficient = 1.496180
        self.social_coefficient = 1.496180
        self.num_evaluations_per_candidate = 10
        self.local_search_iterations = 5

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        positions = np.random.uniform(lb, ub, size=(self.initial_population_size, dim))
        velocities = np.zeros_like(positions)
        personal_best_positions = np.copy(positions)
        personal_best_values = np.array([np.median([float(problem(x)) for _ in range(self.num_evaluations_per_candidate)]) for x in positions])
        evaluations = self.initial_population_size * self.num_evaluations_per_candidate

        # Initialize global best
        global_best_index = np.argmin(personal_best_values)
        global_best_position = personal_best_positions[global_best_index]
        global_best_value = personal_best_values[global_best_index]

        max_local_search_budget = int(0.2 * budget)
        population_size = self.initial_population_size

        while evaluations < budget:
            # Evaluate each candidate multiple times and take the median
            for i in range(population_size):
                candidate_evaluations = np.array([float(problem(positions[i])) for _ in range(self.num_evaluations_per_candidate)])
                evaluations += self.num_evaluations_per_candidate
                avg_value = np.median(candidate_evaluations)

                # Update personal best if the new average is better
                if avg_value < personal_best_values[i]:
                    personal_best_positions[i] = positions[i]
                    personal_best_values[i] = avg_value

            # Update global best
            global_best_index = np.argmin(personal_best_values)
            if personal_best_values[global_best_index] < global_best_value:
                global_best_position = personal_best_positions[global_best_index]
                global_best_value = personal_best_values[global_best_index]

            # Adaptive coefficients with constraints
            self.cognitive_coefficient = 1.5 + np.random.rand() * 0.5
            self.social_coefficient = 1.5 + np.random.rand() * 0.5

            # Update velocities and positions
            r1 = np.random.rand(population_size, dim)
            r2 = np.random.rand(population_size, dim)
            velocities = (self.inertia_weight * velocities +
                          self.cognitive_coefficient * r1 * (personal_best_positions - positions) +
                          self.social_coefficient * r2 * (global_best_position - positions))
            positions = np.clip(positions + velocities, lb, ub)

            # Local search to refine promising solutions within budget
            if evaluations < max_local_search_budget:
                for i in range(population_size):
                    local_best = personal_best_positions[i]
                    local_value = personal_best_values[i]
                    for _ in range(self.local_search_iterations):
                        perturbation = np.random.normal(0, 0.1 * (ub - lb), dim)
                        candidate = np.clip(local_best + perturbation, lb, ub)
                        candidate_evaluations = np.array([float(problem(candidate)) for _ in range(self.num_evaluations_per_candidate)])
                        evaluations += self.num_evaluations_per_candidate
                        avg_value = np.median(candidate_evaluations)
                        if avg_value < local_value:
                            local_best = candidate
                            local_value = avg_value
                    if local_value < personal_best_values[i]:
                        personal_best_positions[i] = local_best
                        personal_best_values[i] = local_value

            # Adaptive population size adjustment
            if evaluations < 0.5 * budget and population_size < 100:
                population_size += 5
                new_positions = np.random.uniform(lb, ub, size=(population_size - len(positions), dim))
                positions = np.vstack((positions, new_positions))
                velocities = np.vstack((velocities, np.zeros_like(new_positions)))
                personal_best_positions = np.vstack((personal_best_positions, new_positions))
                personal_best_values = np.append(personal_best_values, [np.median([float(problem(x)) for _ in range(self.num_evaluations_per_candidate)]) for x in new_positions])
                evaluations += (population_size - len(positions)) * self.num_evaluations_per_candidate

        return global_best_position, float(global_best_value)