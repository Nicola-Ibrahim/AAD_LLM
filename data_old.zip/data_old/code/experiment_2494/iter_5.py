import numpy as np

class ImprovedGeneticOptimizer:
    def __init__(self):
        self.pop_size = 100  # Population size
        self.mutation_rate = 0.05  # Initial mutation rate
        self.tournament_k = 3  # Tournament selection size
        self.elitism_rate = 0.1  # Elitism rate

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        while evaluations < budget:
            # Selection: Tournament selection
            selected_indices = np.zeros(self.pop_size, dtype=int)
            for i in range(self.pop_size):
                tournament_indices = np.random.choice(self.pop_size, self.tournament_k, replace=False)
                best_in_tournament_index = tournament_indices[np.argmin(fitness[tournament_indices])]
                selected_indices[i] = best_in_tournament_index
            selected_population = population[selected_indices]

            # Crossover: Single-point crossover
            offspring = np.zeros((self.pop_size, dim))
            for i in range(0, self.pop_size, 2):
                parent1 = selected_population[i]
                parent2 = selected_population[i+1] if (i+1) < self.pop_size else parent1
                crossover_point = np.random.randint(1, dim)
                offspring[i] = np.concatenate((parent1[:crossover_point], parent2[crossover_point:]))
                offspring[i+1] = np.concatenate((parent2[:crossover_point], parent1[crossover_point:]))

            # Mutation: Gaussian mutation with adaptive rate
            mutation_mask = np.random.rand(self.pop_size, dim) < self.mutation_rate
            gaussian_noise = np.random.normal(0, 0.5, size=(self.pop_size, dim))
            offspring += mutation_mask * gaussian_noise
            offspring = np.clip(offspring, lb, ub)

            # Evaluate new population
            new_fitness = np.array([problem(x) for x in offspring])
            evaluations += self.pop_size

            # Elitism: Keep some best individuals from the previous generation
            num_elites = int(self.elitism_rate * self.pop_size)
            elites_indices = np.argsort(fitness)[:num_elites]
            elites_population = population[elites_indices]
            elites_fitness = fitness[elites_indices]

            # Combine and sort populations
            combined_population = np.vstack((offspring, elites_population))
            combined_fitness = np.concatenate((new_fitness, elites_fitness))
            sorted_indices = np.argsort(combined_fitness)

            # Update population and best solution
            population = combined_population[sorted_indices]
            fitness = combined_fitness[sorted_indices]

            if fitness[0] < best_y:
                best_x = population[0]
                best_y = float(fitness[0])

        return best_x, best_y  # MUST return tuple: (best_x_ndarray, best_y_float)