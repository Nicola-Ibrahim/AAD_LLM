import numpy as np

class MyOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 100
        mutation_rate = 0.2
        tournament_k = 5

        population = np.random.uniform(lb, ub, size=(pop_size, dim))
        fitness = np.array([float(problem(x)) for x in population])
        evaluations = pop_size

        # Initialize best solution
        best_index = np.argmin(fitness)
        best_x = population[best_index]
        best_y = fitness[best_index]

        while evaluations < budget:
            # Selection: Tournament selection
            selected_indices = np.zeros(pop_size, dtype=int)
            for i in range(pop_size):
                tournament_indices = np.random.choice(pop_size, tournament_k, replace=False)
                selected_indices[i] = tournament_indices[np.argmin(fitness[tournament_indices])]
            selected_population = population[selected_indices]

            # Crossover: Single-point crossover
            offspring = np.zeros((pop_size, dim))
            for i in range(0, pop_size, 2):
                parent1 = selected_population[i]
                parent2 = selected_population[i+1] if (i+1) < pop_size else parent1
                crossover_point = np.random.randint(1, dim)
                offspring[i] = np.concatenate((parent1[:crossover_point], parent2[crossover_point:]))
                offspring[i+1] = np.concatenate((parent2[:crossover_point], parent1[crossover_point:]))

            # Mutation: Gaussian mutation
            mutation_mask = np.random.rand(pop_size, dim) < mutation_rate
            gaussian_noise = np.random.normal(0, 0.5, size=(pop_size, dim))
            offspring += mutation_mask * gaussian_noise
            offspring = np.clip(offspring, lb, ub)

            # Evaluate new population
            new_fitness = np.array([float(problem(x)) for x in offspring])
            evaluations += pop_size

            # Update best solution
            combined_population = np.vstack((population, offspring))
            combined_fitness = np.concatenate((fitness, new_fitness))
            best_index = np.argmin(combined_fitness)
            if combined_fitness[best_index] < best_y:
                best_x = combined_population[best_index]
                best_y = combined_fitness[best_index]

            # Update population
            fitness_argsort = np.argsort(combined_fitness)[:pop_size]
            population = combined_population[fitness_argsort]
            fitness = combined_fitness[fitness_argsort]

        return best_x, float(best_y)