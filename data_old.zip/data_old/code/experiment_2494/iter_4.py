import numpy as np

class ImprovedGeneticOptimizer:
    def __init__(self):
        self.pop_size = 20  # Reduced population size for efficiency
        self.mutation_rate = 0.3  # Increased mutation rate for exploration
        self.tournament_k = 2  # Simplified tournament selection

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([float(problem(x)) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(problem(best_x))
        evaluations += 1

        while evaluations < budget:
            # Selection: Tournament selection
            selected_indices = np.zeros(self.pop_size, dtype=int)
            for i in range(self.pop_size):
                tournament_indices = np.random.choice(self.pop_size, self.tournament_k, replace=False)
                best_in_tournament_index = tournament_indices[np.argmin(fitness[tournament_indices])]
                selected_indices[i] = best_in_tournament_index
            selected_population = population[selected_indices]

            # Crossover: Single-point crossover
            offspring = np.zeros((self.pop_size, dim))
            for i in range(0, self.pop_size, 2):
                parent1 = selected_population[i]
                parent2 = selected_population[i+1] if (i+1) < self.pop_size else parent1
                crossover_point = np.random.randint(1, dim)
                offspring[i] = np.concatenate((parent1[:crossover_point], parent2[crossover_point:]))
                offspring[i+1] = np.concatenate((parent2[:crossover_point], parent1[crossover_point:]))

            # Mutation: Gaussian mutation
            mutation_mask = np.random.rand(self.pop_size, dim) < self.mutation_rate
            gaussian_noise = np.random.normal(0, 0.5, size=(self.pop_size, dim))
            offspring += mutation_mask * gaussian_noise
            offspring = np.clip(offspring, lb, ub)

            # Evaluate new population
            new_fitness = np.array([float(problem(x)) for x in offspring])
            evaluations += self.pop_size

            # Update best solution
            combined_population = np.vstack((population, offspring))
            combined_fitness = np.concatenate((fitness, new_fitness))
            best_index = np.argmin(combined_fitness)
            if combined_fitness[best_index] < best_y:
                best_x = combined_population[best_index]
                best_y = combined_fitness[best_index]

            # Local search step
            for _ in range(5):  # Perform local search 5 times per generation
                candidate_x = np.clip(best_x + np.random.normal(0, 0.1, size=dim), lb, ub)
                candidate_y = float(problem(candidate_x))
                evaluations += 1
                if candidate_y < best_y:
                    best_x = candidate_x
                    best_y = candidate_y

            # Update population
            fitness_argsort = np.argsort(combined_fitness)[:self.pop_size]
            population = combined_population[fitness_argsort]
            fitness = combined_fitness[fitness_argsort]

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)