import numpy as np

class EnhancedGeneticOptimizer:
    def __init__(self):
        self.pop_size = 50  # Population size
        self.mutation_rate = 0.2  # Increased mutation rate for better exploration
        self.tournament_k = 3  # Tournament selection size
        self.relative_improvement_threshold = 1e-6  # Early stopping threshold
        self.num_evals_per_candidate = 10  # More evaluations per candidate for re-evaluation

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Always start with a random initial point using vectorization
        best_x = np.random.uniform(lb, ub, size=dim)
        best_y = float(problem(best_x))
        evaluations = 1

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = self.evaluate_population(problem, population, budget - evaluations)
        evaluations += self.pop_size * self.num_evals_per_candidate

        while evaluations < budget:
            # Selection: Tournament selection based on averaged fitness
            selected_indices = np.zeros(self.pop_size, dtype=int)
            for i in range(self.pop_size):
                tournament_indices = np.random.choice(self.pop_size, self.tournament_k, replace=False)
                best_in_tournament_index = tournament_indices[np.argmin(fitness[tournament_indices])]
                selected_indices[i] = best_in_tournament_index
            selected_population = population[selected_indices]

            # Crossover: Uniform crossover with a higher probability of swapping genes
            offspring = np.zeros((self.pop_size, dim))
            for i in range(0, self.pop_size, 2):
                parent1 = selected_population[i]
                parent2 = selected_population[i+1] if (i+1) < self.pop_size else parent1
                crossover_mask = np.random.rand(dim) < 0.9  # Higher probability of swapping
                offspring[i] = np.where(crossover_mask, parent1, parent2)
                offspring[i+1] = np.where(crossover_mask, parent2, parent1)

            # Mutation: Gaussian mutation with a higher standard deviation for more exploration
            mutation_mask = np.random.rand(self.pop_size, dim) < self.mutation_rate
            gaussian_noise = np.random.normal(0, 1.0, size=(self.pop_size, dim))  # Increased std dev
            offspring += mutation_mask * gaussian_noise
            offspring = np.clip(offspring, lb, ub)

            # Evaluate new population
            new_fitness = self.evaluate_population(problem, offspring, budget - evaluations)
            evaluations += self.pop_size * self.num_evals_per_candidate

            # Update best solution
            combined_population = np.vstack((population, offspring))
            combined_fitness = np.concatenate((fitness, new_fitness))
            best_index = np.argmin(combined_fitness)
            if combined_fitness[best_index] < best_y:
                best_x = combined_population[best_index]
                best_y = combined_fitness[best_index]

            # Update population
            fitness_argsort = np.argsort(combined_fitness)[:self.pop_size]
            population = combined_population[fitness_argsort]
            fitness = combined_fitness[fitness_argsort]

            # Early stopping based on relative improvement
            if best_y <= 0:
                improvement = (best_y - new_fitness.min()) / abs(best_y)
            else:
                improvement = (best_y - new_fitness.min()) / best_y

            if improvement < self.relative_improvement_threshold:
                break

        return best_x, float(best_y)  # MUST return tuple: (best_x_ndarray, best_y_float)

    def evaluate_population(self, problem, population, remaining_budget):
        fitness = np.zeros(len(population))
        for i, x in enumerate(population):
            if remaining_budget > 0:
                candidate_fitnesses = [float(problem(x)) for _ in range(self.num_evals_per_candidate)]
                fitness[i] = np.mean(candidate_fitnesses)  # Use mean of evaluations
                remaining_budget -= self.num_evals_per_candidate
        return fitness