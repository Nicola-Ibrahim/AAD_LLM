import numpy as np

class PSOAlgorithm:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize particles and velocities
        pop_size = 100
        candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        
        # Initialize global best
        gbest = None
        gbest_y = float('inf')

        evaluations = 0

        while evaluations < budget:
            for i in range(pop_size):
                # Calculate inertia, cognitive, and social components
                w = 0.7  # Inertia constant
                c1 = 2  # Cognitive component
                c2 = 2  # Social component
                
                r1 = np.random.rand()
                r2 = np.random.rand()
                
                cognitive_component = c1 * r1 * (gbest - candidates[i])
                social_component = c2 * r2 * (best_y - candidates[i])

                # Update velocities
                velocities[i] = w * velocities[i] + cognitive_component + social_component
                
                # Clip velocities to bounds
                candidates[i] = np.clip(candidates[i] + velocities[i], lb, ub)
                
                # Evaluate candidate
                y = float(problem(candidates[i]))
                evaluations += 1
                
                if y < gbest_y:
                    gbest = candidates[i]
                    gbest_y = y

        return gbest, gbest_y