import numpy as np

class PSOAlgorithm:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize particles and velocities
        pop_size = 100
        candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        
        evaluations = 0
        budget_reevals = int(budget * 0.2)
        reeval_budget = int(budget - budget_reevals)

        while evaluations < reeval_budget:
            for i in range(pop_size):
                # Calculate inertia, cognitive, and social components
                w = 0.7  # Inertia constant
                c1 = 2  # Cognitive component
                c2 = 2  # Social component
                
                r1 = np.random.rand()
                r2 = np.random.rand()
                
                cognitive_component = c1 * r1 * (self.gbest - candidates[i])
                social_component = c2 * r2 * (self.gbest_y - candidates[i])

                # Update velocities
                velocities[i] = w * velocities[i] + cognitive_component + social_component
                
                # Clip velocities to bounds
                candidates[i] = np.clip(candidates[i] + velocities[i], lb, ub)
                
                # Evaluate candidate multiple times and calculate mean/median
                y_means = []
                for _ in range(3):  # Example: Evaluate 3 times and take the median of the results
                    y = float(problem(candidates[i]))
                    evaluations += 1
                    y_means.append(y)

                candidates[i] = np.median(y_means)  # Update candidate to the mean/median result

                if candidates[i] < self.gbest_y:
                    self.gbest = candidates[i]
                    self.gbest_y = candidates[i]

        # Re-evaluation of best solutions
        for _ in range(budget_reevals):
            best_candidates = np.random.uniform(lb, ub, size=(10, dim))
            y_means = []
            for candidate in best_candidates:
                y = float(problem(candidate))
                evaluations += 1
                y_means.append(y)

            self.gbest = np.median(y_means)
            self.gbest_y = np.median(y_means)

        return self.gbest, self.gbest_y