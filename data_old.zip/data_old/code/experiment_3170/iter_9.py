import numpy as np

class MyOptimizer:
    def __init__(self):
        # Initialize global best with a random point in the search space
        self.gbest = np.random.uniform(low=-5.0, high=5.0, size=(10,))
        # Initialize global best value to a large number
        self.gbest_y = float('inf')
    
    def re_evaluate(self, x):
        evaluations = []
        for _ in range(3):  # Re-evaluate the point multiple times
            y = float(self.problem(x))
            evaluations.append(y)
        return np.mean(evaluations), np.median(evaluations)

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize particles and velocities
        pop_size = 100
        candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        
        evaluations = 0

        while evaluations < budget:
            for i in range(pop_size):
                # Calculate inertia, cognitive, and social components
                w = 0.7  # Inertia constant
                c1 = 2  # Cognitive component
                c2 = 2  # Social component
                
                r1 = np.random.rand()
                r2 = np.random.rand()
                
                cognitive_component = c1 * r1 * (self.gbest - candidates[i])
                social_component = c2 * r2 * (self.gbest_y - candidates[i])

                # Update velocities
                velocities[i] = w * velocities[i] + cognitive_component + social_component
                
                # Clip velocities to bounds
                candidates[i] = np.clip(candidates[i] + velocities[i], lb, ub)
                
                # Re-evaluate candidate and get mean and median evaluations
                best_y_mean, best_y_median = self.re_evaluate(candidates[i])
                evaluations += 1

                if best_y_mean < self.gbest_y:
                    self.gbest = candidates[i]
                    self.gbest_y = best_y_mean
        
        return self.gbest, self.gbest_y