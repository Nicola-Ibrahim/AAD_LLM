import numpy as np

class ResilientPSO:
    def __init__(self):
        # Initialize global best with a random point in the search space
        self.gbest = np.random.uniform(low=-5.0, high=5.0, size=(10,))
        # Initialize global best value to a large number
        self.gbest_y = float('inf')

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize particles and velocities
        pop_size = 100
        candidates = np.random.uniform(lb, ub, size=(pop_size, dim))
        velocities = np.zeros((pop_size, dim))
        
        evaluations = 0

        while evaluations < budget:
            for i in range(pop_size):
                # Calculate inertia, cognitive, and social components
                w = 0.7  # Inertia constant
                c1 = 2  # Cognitive component
                c2 = 2  # Social component
                
                r1 = np.random.rand()
                r2 = np.random.rand()
                
                cognitive_component = c1 * r1 * (self.gbest - candidates[i])
                social_component = c2 * r2 * (self.gbest_y - candidates[i])

                # Update velocities
                velocities[i] = w * velocities[i] + cognitive_component + social_component
                
                # Clip velocities to bounds
                candidates[i] = np.clip(candidates[i] + velocities[i], lb, ub)
                
                # Evaluate candidate multiple times and calculate mean fitness
                means = []
                for _ in range(3):  # Re-evaluate 3 times
                    y = float(problem(candidates[i]))
                    evaluations += 1
                    means.append(y)

                # Use mean fitness as the evaluation score
                y = np.mean(means)
                
                if y < self.gbest_y:
                    self.gbest = candidates[i]
                    self.gbest_y = y

        return self.gbest, self.gbest_y