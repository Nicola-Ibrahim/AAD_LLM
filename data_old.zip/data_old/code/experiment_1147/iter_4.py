import numpy as np

class CMAES:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize the CMA-ES parameters
        pop_size = min(10 * dim, budget // 20)  # Maximum 10x dimension or 20% of budget
        sigma = (ub - lb) / np.sqrt(2.0)
        mu = pop_size // 2
        weights = np.ones(mu) / mu
        cumulation_coefficient = 2.0 / (dim + 2.0)
        learning_rate = {
            'mu_eff': None,
            'sigma': min(1.0, (dim + 2.0) / ((4.0 + mu / dim) * mu_eff + 2.0)),
            'c_c': max(0.3, 1.0 - 2.0 * np.sqrt(mu_eff / dim) - mu_eff / dim),
            'c_1': min(1.0, 4.0 * (mu_eff - 2.0 + 1.0 / mu_eff) / (dim * (dim + 2.0))),
            'd_c': max(0.05, np.sqrt(cumulation_coefficient - 2.0 + 2.0 * c_c)) / sigma
        }
        mean = np.random.uniform(lb, ub, size=dim)
        C = np.eye(dim) * sigma ** 2
        B = np.eye(dim)
        D = np.ones(dim)

        # Initialize mu_eff to a reasonable value
        evaluations = pop_size

        while evaluations < budget:
            candidates = mean + np.random.randn(pop_size, dim) @ (C @ B.T)
            candidates = np.clip(candidates, lb, ub)
            candidate_scores = np.array([_robust_eval(x, 3) for x in candidates])
            evaluations += pop_size

            # Update the weights
            rank = np.argsort(candidate_scores).argsort()
            weights_new = weights * (1 - learning_rate['c_c'])
            weights_new[rank[:mu]] += learning_rate['c_c']

            # Update the mean
            new_mean = np.sum(weights_new[:, None] * candidates, axis=0)

            # Update the covariance matrix
            diff = candidates - new_mean
            D = np.diag(np.sqrt(1 / (1.0 - 2.0 * learning_rate['c_1'] + learning_rate['c_1'] ** 2) * (np.sum(weights_new[:, None] * diff ** 2, axis=0)) - np.ones(dim)))
            B = D @ np.linalg.qr(np.random.randn(dim, dim))[0]
            C = B.T @ B * sigma ** 2

            # Update the learning rate
            if evaluations >= pop_size:
                mu_eff = np.sum(weights_new ** 2)
                cumulation_coefficient = max(1.0 - 2.0 / dim, min(cumulation_coefficient + 4.0 * (mu_eff - 2.0) / (dim * (dim + 2.0)) - 2.0, 2.0))
                learning_rate['c_c'] = max(0.3, 1.0 - 2.0 * np.sqrt(mu_eff / dim) - mu_eff / dim)
                learning_rate['c_1'] = min(1.0, 4.0 * (mu_eff - 2.0 + 1.0 / mu_eff) / (dim * (dim + 2.0)))
                learning_rate['d_c'] = max(0.05, np.sqrt(cumulation_coefficient - 2.0 + 2.0 * c_c)) / sigma

            # Update the best solution
            if candidate_scores.min() < float(problem(best_x)):
                best_x = candidates[rank[:1]]
                best_y = _robust_eval(best_x, 3)

        return best_x, best_y

def _robust_eval(x, k):
    return float(np.mean([problem(x) for _ in range(k)]))