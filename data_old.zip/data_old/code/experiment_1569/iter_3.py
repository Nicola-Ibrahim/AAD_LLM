import numpy as np

class NoisyDEOptimizer:
    def __init__(self):
        self.F = 0.8  # Initial mutation factor
        self.CR = 0.9  # Crossover rate
        self.pop_size = 50  # Population size
        self.eval_per_candidate = 10  # Number of evaluations per candidate
        self.patience = 100  # Generations without improvement before restart

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evals_per_candidate = np.zeros(self.pop_size)

        def evaluate_candidates(candidates):
            nonlocal evaluations
            total_evaluations = len(candidates) * self.eval_per_candidate
            if evaluations + total_evaluations > budget:
                raise ValueError("Budget exceeded during evaluation")
            evals = np.array([np.mean([float(problem(candidate)) for _ in range(self.eval_per_candidate)]) for candidate in candidates])
            evaluations += total_evaluations
            return evals

        # Evaluate initial population
        evaluations = 0
        fitnesses = evaluate_candidates(pop)
        best_idx = np.argmin(fitnesses)
        best_x, best_y = pop[best_idx], fitnesses[best_idx]
        no_improvement_count = 0

        while evaluations < budget:
            new_pop = []
            for i in range(self.pop_size):
                # Select three distinct individuals from the population
                idxs = [j for j in range(self.pop_size) if j != i]
                np.random.shuffle(idxs)
                a, b, c = pop[idxs[:3]]

                # Mutation: create a donor vector by adding the scaled difference between two population members to a third member
                donor = a + self.F * (b - c)

                # Crossover: apply binomial crossover with probability CR
                trial = np.where(np.random.rand(dim) < self.CR, donor, pop[i])

                # Ensure the new candidate is within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the trial vector multiple times and take the average
                trial_fitness = evaluate_candidates([trial])[0]

                # Selection: replace the current individual with the trial if it has a better fitness
                if trial_fitness < fitnesses[i]:
                    new_pop.append(trial)
                    fitnesses[i] = trial_fitness
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update best solution found so far
            best_idx = np.argmin(fitnesses)
            current_best_x, current_best_y = pop[best_idx], fitnesses[best_idx]

            if current_best_y < best_y:
                best_x, best_y = current_best_x, current_best_y
                no_improvement_count = 0
            else:
                no_improvement_count += 1

            # Adaptive adjustment of F and CR
            self.F = np.clip(self.F + (np.random.rand() - 0.5) * 0.2, 0.1, 1.9)
            self.CR = np.clip(self.CR + (np.random.rand() - 0.5) * 0.2, 0.4, 0.9)

            # Restart mechanism if no improvement
            if no_improvement_count >= self.patience:
                no_improvement_count = 0
                new_random_candidates = np.random.uniform(lb, ub, size=(self.pop_size // 5, dim))
                pop[-len(new_random_candidates):] = new_random_candidates
                fitnesses[-len(new_random_candidates):] = evaluate_candidates(new_random_candidates)

        return best_x, float(best_y)