import numpy as np

class AdaptiveDEOptimizer:
    def __init__(self):
        self.pop_size = 50  # Population size
        self.eval_per_candidate = 20  # Number of evaluations per candidate
        self.F_min, self.F_max = 0.4, 1.0  # Mutation factor bounds
        self.CR_min, self.CR_max = 0.3, 0.9  # Crossover rate bounds

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evals_per_candidate = np.zeros(self.pop_size)

        def evaluate_candidates(candidates):
            nonlocal evaluations
            total_evaluations = len(candidates) * self.eval_per_candidate
            if evaluations + total_evaluations > budget:
                raise ValueError("Budget exceeded during evaluation")
            evals = np.array([np.mean([float(problem(candidate)) for _ in range(self.eval_per_candidate)]) for candidate in candidates])
            evaluations += total_evaluations
            return evals

        # Evaluate initial population
        evaluations = 0
        fitnesses = evaluate_candidates(pop)
        best_idx = np.argmin(fitnesses)
        best_x, best_y = pop[best_idx], fitnesses[best_idx]

        while evaluations < budget:
            new_pop = []
            F_values = np.random.uniform(self.F_min, self.F_max, size=self.pop_size)
            CR_values = np.random.uniform(self.CR_min, self.CR_max, size=self.pop_size)

            for i in range(self.pop_size):
                # Select three distinct individuals from the population
                idxs = [j for j in range(self.pop_size) if j != i]
                np.random.shuffle(idxs)
                a, b, c = pop[idxs[:3]]

                # Mutation: create a donor vector by adding the scaled difference between two population members to a third member
                F = F_values[i]
                CR = CR_values[i]
                donor = a + F * (b - c)

                # Crossover: apply binomial crossover with probability CR
                trial = np.where(np.random.rand(dim) < CR, donor, pop[i])

                # Ensure the new candidate is within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the trial vector multiple times and take the average
                trial_fitness = evaluate_candidates([trial])[0]

                # Selection: replace the current individual with the trial if it has a better fitness
                if trial_fitness < fitnesses[i]:
                    new_pop.append(trial)
                    fitnesses[i] = trial_fitness
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update best solution found so far and periodically re-evaluate it
            best_idx = np.argmin(fitnesses)
            current_best_x, current_best_y = pop[best_idx], fitnesses[best_idx]

            if current_best_y < best_y:
                best_x, best_y = current_best_x, current_best_y

                # Periodically re-evaluate the best solution
                if evaluations % (self.eval_per_candidate * self.pop_size) == 0:
                    true_best_y = evaluate_candidates([best_x])[0]
                    if true_best_y < best_y:
                        best_y = true_best_y

        return best_x, float(best_y)