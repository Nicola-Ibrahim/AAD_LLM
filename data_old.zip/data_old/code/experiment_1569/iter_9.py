import numpy as np

class NoisyDEOptimizer:
    def __init__(self):
        pass

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop_size = 50
        pop = np.random.uniform(lb, ub, size=(pop_size, dim))
        F = 0.8  # Mutation factor
        CR = 0.9  # Crossover rate
        eval_per_candidate = 10  # Number of evaluations per candidate

        def evaluate_candidates(candidates):
            nonlocal evaluations
            total_evaluations = len(candidates) * eval_per_candidate
            if evaluations + total_evaluations > budget:
                raise ValueError("Budget exceeded during evaluation")
            evals = np.array([np.mean([float(problem(candidate)) for _ in range(eval_per_candidate)]) for candidate in candidates])
            evaluations += total_evaluations
            return evals

        # Evaluate initial population
        evaluations = 0
        fitnesses = evaluate_candidates(pop)
        best_idx = np.argmin(fitnesses)
        best_x, best_y = pop[best_idx], fitnesses[best_idx]

        success_count = 0

        while evaluations < budget:
            new_pop = []
            for i in range(pop_size):
                # Select three distinct individuals from the population
                idxs = [j for j in range(pop_size) if j != i]
                np.random.shuffle(idxs)
                a, b, c = pop[idxs[:3]]

                # Mutation: create a donor vector by adding the scaled difference between two population members to a third member
                donor = a + F * (b - c)

                # Crossover: apply binomial crossover with probability CR
                trial = np.where(np.random.rand(dim) < CR, donor, pop[i])

                # Ensure the new candidate is within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the trial vector multiple times and take the average
                trial_fitness = evaluate_candidates([trial])[0]

                # Selection: replace the current individual with the trial if it has a better fitness
                if trial_fitness < fitnesses[i]:
                    new_pop.append(trial)
                    fitnesses[i] = trial_fitness
                    success_count += 1
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Update best solution found so far
            best_idx = np.argmin(fitnesses)
            current_best_x, current_best_y = pop[best_idx], fitnesses[best_idx]

            if current_best_y < best_y:
                best_x, best_y = current_best_x, current_best_y

            # Adaptive mutation factor and crossover rate
            if success_count > 0.7 * pop_size:
                F = min(F + 0.1, 2)
                CR = max(CR - 0.05, 0.3)
            elif success_count < 0.3 * pop_size:
                F = max(F - 0.1, 0.4)
                CR = min(CR + 0.05, 0.9)

            success_count = 0

        return best_x, float(best_y)