import numpy as np

class EnhancedNoisyDEOptimizer:
    def __init__(self):
        self.pop_size = 100  # Increased population size for better exploration
        self.eval_per_candidate = 20  # Number of evaluations per candidate to reduce noise impact
        self.initial_F = 0.8  # Initial mutation factor
        self.F_range = [0.5, 1.5]  # Range for adaptive F
        self.CR_initial = 0.9  # Initial crossover rate
        self.CR_min = 0.7  # Minimum crossover rate to avoid excessive exploration
        self.CR_max = 1.0  # Maximum crossover rate

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        pop = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        evals_per_candidate = np.zeros(self.pop_size)

        def evaluate_candidates(candidates):
            nonlocal evaluations
            total_evaluations = len(candidates) * self.eval_per_candidate
            if evaluations + total_evaluations > budget:
                raise ValueError("Budget exceeded during evaluation")
            evals = np.array([np.mean([float(problem(candidate)) for _ in range(self.eval_per_candidate)]) for candidate in candidates])
            evaluations += total_evaluations
            return evals

        # Evaluate initial population
        evaluations = 0
        fitnesses = evaluate_candidates(pop)
        best_idx = np.argmin(fitnesses)
        best_x, best_y = pop[best_idx], fitnesses[best_idx]

        while evaluations < budget:
            new_pop = []
            F = self.initial_F + (self.F_range[1] - self.F_range[0]) * np.random.rand()
            CR = self.CR_min + (self.CR_max - self.CR_min) * np.random.rand()

            for i in range(self.pop_size):
                # Select three distinct individuals from the population
                idxs = [j for j in range(self.pop_size) if j != i]
                np.random.shuffle(idxs)
                a, b, c = pop[idxs[:3]]

                # Mutation: create a donor vector by adding the scaled difference between two population members to a third member
                donor = a + F * (b - c)

                # Crossover: apply binomial crossover with probability CR
                trial = np.where(np.random.rand(dim) < CR, donor, pop[i])

                # Ensure the new candidate is within bounds
                trial = np.clip(trial, lb, ub)

                # Evaluate the trial vector multiple times and take the average
                trial_fitness = evaluate_candidates([trial])[0]

                # Selection: replace the current individual with the trial if it has a better fitness
                if trial_fitness < fitnesses[i]:
                    new_pop.append(trial)
                    fitnesses[i] = trial_fitness
                else:
                    new_pop.append(pop[i])

            pop = np.array(new_pop)

            # Elitism: retain the best solution found so far
            current_best_idx = np.argmin(fitnesses)
            current_best_x, current_best_y = pop[current_best_idx], fitnesses[current_best_idx]

            if current_best_y < best_y:
                best_x, best_y = current_best_x, current_best_y

        return best_x, float(best_y)