import numpy as np

class OptimizerADE:
    def __init__(self):
        self.pop_size = 100
        self.F_min = 0.3
        self.F_max = 1.0
        self.Cr = 0.7
        self.success_rate_threshold = 0.2

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        # Initialize adaptive parameters
        F = 0.5
        Cr = self.Cr
        success_count = 0
        total_trials = 0

        while evaluations < budget:
            # Mutation: Select three distinct indices a, b, c != i for each candidate
            idxs = np.arange(self.pop_size)
            np.random.shuffle(idxs)
            a_idx = idxs[:self.pop_size]
            b_idx = idxs[1:self.pop_size + 1] % self.pop_size
            c_idx = idxs[2:self.pop_size + 2] % self.pop_size

            a, b, c = population[a_idx], population[b_idx], population[c_idx]

            # Generate donor vector v
            v = a + F * (b - c)

            # Crossover: Binomial crossover between target vector x_i and donor vector v
            u = np.where(np.random.rand(self.pop_size, dim) < Cr, v, population)

            # Clip the trial vector to ensure it lies within bounds
            u = np.clip(u, lb, ub)

            # Evaluate the trial vector
            f_u = np.array([problem(x) for x in u])
            evaluations += self.pop_size

            # Selection: Replace x_i with u if it improves the fitness
            improved_mask = f_u < fitness
            population[improved_mask] = u[improved_mask]
            fitness[improved_mask] = f_u[improved_mask]
            success_count += np.sum(improved_mask)

            # Update best solution
            best_idx = np.argmin(fitness)
            best_x = population[best_idx]
            best_y = float(np.min(fitness))

            # Adaptive mechanism to adjust F and Cr based on success rate
            total_trials += self.pop_size
            if total_trials >= 10 * self.pop_size:
                success_rate = success_count / total_trials

                if success_rate > self.success_rate_threshold:
                    F = min(F + 0.1, self.F_max)
                else:
                    F = max(F - 0.1, self.F_min)

                success_count = 0
                total_trials = 0

        return best_x, float(best_y)