import numpy as np

class EnhancedADE:
    def __init__(self):
        self.pop_size = 100
        self.F_min = 0.3
        self.F_max = 1.0
        self.Cr = 0.7
        self.success_rate_threshold = 0.2
        self.elitism_ratio = 0.1

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        # Initialize adaptive parameters
        F = 0.5
        Cr = self.Cr
        success_count = 0
        total_trials = 0

        while evaluations < budget:
            # Elitism: Preserve the best solutions
            num_elites = int(self.elitism_ratio * self.pop_size)
            elite_indices = np.argsort(fitness)[:num_elites]
            elites = population[elite_indices]

            # Mutation: Select three distinct indices a, b, c for each individual i != j
            indices = np.random.choice(self.pop_size, size=(self.pop_size - num_elites, 3), replace=True)
            a_idx, b_idx, c_idx = indices[:, 0], indices[:, 1], indices[:, 2]
            a = population[a_idx]
            b = population[b_idx]
            c = population[c_idx]

            # Generate donor vector v
            v = a + F * (b - c)

            # Crossover: Binomial crossover between target vector x_i and donor vector v
            u_mask = np.random.rand(self.pop_size - num_elites, dim) < Cr
            u = np.where(u_mask, v, population[num_elites:])
            
            # Gaussian perturbation around elites
            elite_perturbations = np.random.normal(0, 1.0, size=(num_elites, dim)) * (ub - lb) / 10.0
            u_elites = elites + elite_perturbations
            u_elites = np.clip(u_elites, lb, ub)

            # Combine elites and perturbed elites with the rest of the population
            u_combined = np.vstack((u_elites, u))
            
            # Evaluate the trial vector
            f_u_combined = np.array([problem(x) for x in u_combined])
            evaluations += self.pop_size

            # Selection: Replace x_i with u if it improves the fitness
            improved_mask = f_u_combined < fitness
            population[improved_mask] = u_combined[improved_mask]
            fitness[improved_mask] = f_u_combined[improved_mask]

            success_count += np.sum(improved_mask)

            # Update best solution
            best_idx = np.argmin(fitness)
            best_x = population[best_idx]
            best_y = float(np.min(fitness))

            # Adaptive mechanism to adjust F and Cr based on success rate
            total_trials += self.pop_size
            if total_trials >= 10 * self.pop_size:
                success_rate = success_count / total_trials

                if success_rate > self.success_rate_threshold:
                    F = min(F + 0.1, self.F_max)
                else:
                    F = max(F - 0.1, self.F_min)

                success_count = 0
                total_trials = 0

        return best_x, float(best_y)