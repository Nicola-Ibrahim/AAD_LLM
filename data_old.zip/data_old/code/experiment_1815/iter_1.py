import numpy as np

class AdaptiveDifferentialEvolution:
    def __init__(self):
        self.pop_size = 100
        self.F_min = 0.3
        self.F_max = 1.0
        self.Cr = 0.7
        self.success_rate_threshold = 0.2

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        # Initialize adaptive parameters
        F = 0.5
        Cr = self.Cr
        success_count = 0
        total_trials = 0

        while evaluations < budget:
            for i in range(self.pop_size):
                # Mutation: Select three distinct indices a, b, c != i
                candidates = np.random.choice(self.pop_size, size=3, replace=False)
                a, b, c = population[candidates]

                # Generate donor vector v
                v = a + F * (b - c)

                # Crossover: Binomial crossover between target vector x_i and donor vector v
                u = np.where(np.random.rand(dim) < Cr, v, population[i])

                # Clip the trial vector to ensure it lies within bounds
                u = np.clip(u, lb, ub)

                # Evaluate the trial vector
                f_u = problem(u)
                evaluations += 1

                # Selection: Replace x_i with u if it improves the fitness
                if f_u < fitness[i]:
                    population[i] = u
                    fitness[i] = f_u
                    success_count += 1

            # Update best solution
            best_idx = np.argmin(fitness)
            best_x = population[best_idx]
            best_y = float(np.min(fitness))

            # Adaptive mechanism to adjust F and Cr based on success rate
            total_trials += self.pop_size
            if total_trials >= 10 * self.pop_size:
                success_rate = success_count / total_trials

                if success_rate > self.success_rate_threshold:
                    F = min(F + 0.1, self.F_max)
                else:
                    F = max(F - 0.1, self.F_min)

                success_count = 0
                total_trials = 0

        return best_x, float(best_y)