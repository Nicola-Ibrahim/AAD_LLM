import numpy as np

class OptimizedADE:
    def __init__(self):
        self.pop_size = 100
        self.F_min = 0.3
        self.F_max = 1.0
        self.Cr = 0.7
        self.success_rate_threshold = 0.2
        self.local_search_iterations = 5

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        fitness = np.array([problem(x) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        # Initialize adaptive parameters
        F = 0.5
        Cr = self.Cr
        success_count = 0
        total_trials = 0

        while evaluations < budget:
            # Mutation: Select three distinct indices a, b, c for each individual i != j
            indices = np.random.choice(self.pop_size, size=(self.pop_size, 3), replace=True)
            a_idx, b_idx, c_idx = indices[:, 0], indices[:, 1], indices[:, 2]
            a = population[a_idx]
            b = population[b_idx]
            c = population[c_idx]

            # Generate donor vector v
            v = a + F * (b - c)

            # Crossover: Binomial crossover between target vector x_i and donor vector v
            u_mask = np.random.rand(self.pop_size, dim) < Cr
            u = np.where(u_mask, v, population)
            
            # Clip the trial vector to ensure it lies within bounds
            u = np.clip(u, lb, ub)

            # Evaluate the trial vector
            f_u = np.array([problem(x) for x in u])
            evaluations += self.pop_size

            # Selection: Replace x_i with u if it improves the fitness
            improved_mask = f_u < fitness
            population[improved_mask] = u[improved_mask]
            fitness[improved_mask] = f_u[improved_mask]

            success_count += np.sum(improved_mask)

            # Update best solution
            best_idx = np.argmin(fitness)
            best_x = population[best_idx]
            best_y = float(np.min(fitness))

            # Adaptive mechanism to adjust F and Cr based on success rate
            total_trials += self.pop_size
            if total_trials >= 10 * self.pop_size:
                success_rate = success_count / total_trials

                if success_rate > self.success_rate_threshold:
                    F = min(F + 0.1, self.F_max)
                    Cr = min(Cr + 0.1, 1.0)
                    self.pop_size = min(self.pop_size * 2, 500)  # Increase population size
                else:
                    F = max(F - 0.1, self.F_min)
                    Cr = max(Cr - 0.1, 0.3)
                    self.pop_size = max(self.pop_size // 2, 20)  # Decrease population size

                success_count = 0
                total_trials = 0

            # Local search on the best solution found so far
            if evaluations + self.local_search_iterations * dim < budget:
                local_best_x = np.copy(best_x)
                local_best_y = float(problem(local_best_x))
                evaluations += 1

                for _ in range(self.local_search_iterations):
                    perturbation = np.random.normal(0, 0.1, size=dim)
                    candidate = np.clip(local_best_x + perturbation, lb, ub)
                    candidate_fitness = problem(candidate)
                    evaluations += 1

                    if candidate_fitness < local_best_y:
                        local_best_x = candidate
                        local_best_y = candidate_fitness

                if local_best_y < best_y:
                    best_x = local_best_x
                    best_y = local_best_y

        return best_x, float(best_y)