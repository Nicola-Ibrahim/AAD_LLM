import numpy as np

class EnhancedADE:
    def __init__(self):
        self.pop_size = 100
        self.F_min = 0.3
        self.F_max = 1.0
        self.Cr_min = 0.5
        self.Cr_max = 1.0
        self.success_rate_threshold = 0.2
        self.elite_fraction = 0.1

    def __call__(self, problem, budget):
        lb = np.asarray(getattr(problem, 'lower_bound', -5.0), dtype=float)
        ub = np.asarray(getattr(problem, 'upper_bound', 5.0), dtype=float)
        dim = int(getattr(problem, 'dim', len(lb) if hasattr(lb, '__len__') else 3))

        # Initialize population and mutation factors
        population = np.random.uniform(lb, ub, size=(self.pop_size, dim))
        F_population = np.random.uniform(self.F_min, self.F_max, size=self.pop_size)
        fitness = np.array([problem(x) for x in population])
        evaluations = self.pop_size

        best_x = population[np.argmin(fitness)]
        best_y = float(np.min(fitness))

        # Initialize adaptive parameters
        success_count = 0
        total_trials = 0

        while evaluations < budget:
            # Elitism: Retain the best solutions
            elite_size = int(self.elite_fraction * self.pop_size)
            sorted_indices = np.argsort(fitness)
            elites = population[sorted_indices[:elite_size]]
            F_elites = F_population[sorted_indices[:elite_size]]

            # Mutation: Select three distinct indices a, b, c for each individual i != j
            indices = np.random.choice(self.pop_size, size=(self.pop_size - elite_size, 3), replace=True)
            a_idx, b_idx, c_idx = indices[:, 0], indices[:, 1], indices[:, 2]
            a = population[a_idx]
            b = population[b_idx]
            c = population[c_idx]

            # Generate donor vector v
            F = np.random.normal(F_population[a_idx], 0.1)
            F = np.clip(F, self.F_min, self.F_max)
            v = a + F[:, None] * (b - c)

            # Crossover: Binomial crossover between target vector x_i and donor vector v
            Cr = np.random.uniform(self.Cr_min, self.Cr_max, size=self.pop_size - elite_size)
            u_mask = np.random.rand(self.pop_size - elite_size, dim) < Cr[:, None]
            u = np.where(u_mask, v, population[sorted_indices[elite_size:]])

            # Clip the trial vector to ensure it lies within bounds
            u = np.clip(u, lb, ub)

            # Evaluate the trial vector
            f_u = np.array([problem(x) for x in u])
            evaluations += self.pop_size - elite_size

            # Selection: Replace x_i with u if it improves the fitness
            improved_mask = f_u < fitness[sorted_indices[elite_size:]]
            population[sorted_indices[elite_size:]][improved_mask] = u[improved_mask]
            fitness[sorted_indices[elite_size:]][improved_mask] = f_u[improved_mask]

            # Update best solution
            best_idx = np.argmin(fitness)
            best_x = population[best_idx]
            best_y = float(np.min(fitness))

            # Adaptive mechanism to adjust F and Cr based on success rate
            total_trials += self.pop_size - elite_size
            if total_trials >= 10 * (self.pop_size - elite_size):
                success_rate = success_count / total_trials

                if success_rate > self.success_rate_threshold:
                    F_population[sorted_indices[elite_size:]] = np.clip(F_population[sorted_indices[elite_size:]] + 0.1, self.F_min, self.F_max)
                else:
                    F_population[sorted_indices[elite_size:]] = np.clip(F_population[sorted_indices[elite_size:]] - 0.1, self.F_min, self.F_max)

                success_count = 0
                total_trials = 0

            # Reinsert elites
            population[:elite_size] = elites
            F_population[:elite_size] = F_elites

        return best_x, float(best_y)